# Prospective final R9 four-row performance batch

Prepared only. No source archive was created, no benchmark started, and no process signal was sent. Current ROOT bindings are provisional while the AP attention candidate awaits independent review and adoption. ROOT owns the final source approval, fresh pause identity review and quiet launch authorization.

The runner reuses the retained R8 measurement bodies: exact legacy, exact current, counted legacy, counted current. Each row runs the literal original bench-engine workload for1000 ticks, excluding the original ten warmup ticks and retaining990 AI-phase and timed-tick samples. AI-phase p95 and maximum may increase by at most max(2ms,10%baseline) in each pair. Counted timed ticks strictly above40ms must not increase. Startup remains separate and introduces no new gate. Legacy5293ddb is switched on the same current engine; master referencea3564a6 remains unchanged. All prior R8 rows, failures, preflight refusals and original/updated pause records are hash-bound in the new history map.

The final source input is /tmp/human-ai-r9-final-perf-source. It must be copied only after ROOT approves the complete217-file runtime closure. The eventual runner draft records17 actual core AI/engine bindings separately from that full closure. The measured archive is /tmp/human-ai-r9-final-perf-frozen. The original benchmark bytes and measured loop stay unchanged; the count variant adds only the final over40MS statistics field.

Current read-only pause roots are auxiliary guard1951992, V16 controller1609687, V21 controller1936262 and explicitly owned lab1952084. Their live recorded descendants include V16 runner1609688 and V21 merge2053662. Old V16 merge1904298, ended balance hosts and completed native full-suite hosts are naturally absent. The exact uid, starttime, argv, parent and cwd records are in the initial pause plan. ROOT must refresh them before use. Never reuse a PID whose identity changed or infer ownership of a new descendant.

The original guardian code is preserved. It retains pidfds, independent60-second safety release, parent-exit release and wrapper finally resume. The lab and all registered campaign descendants must resume without termination or restart. Any unknown descendant or lost quiet lease fails closed; a started native row finishes and remains retained. No timeout or favorable retry is added.

After final AP adoption and source approval, ROOT copies and binds the final input, then runs:

    python3 /tmp/human-ai-r9-final-perf-runner.py --draft
    python3 /tmp/human-ai-r9-final-perf-runner.py --freeze-after-root-approval

The second command requires the explicit source authorization and exact manifest. ROOT then binds runner, wrapper, final preregistration and refreshed pause plan hashes in the authorization. Only after explicit quiet approval:

    python3 /tmp/human-ai-r9-final-perf-quiet-wrapper.py --run-after-root-authorization

These are future commands, not instructions that have been executed. The preparation manifest, thin diffs and prospective JSON retain current source and script hashes. The final benchmark is intended to measure genuine new gameplay code, not retry unchanged source until a favorable result appears.
