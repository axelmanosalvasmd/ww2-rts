#!/usr/bin/env python3
"""Explicitly authorized, identity-checked pause window. No benchmark cancellation."""
import argparse, hashlib, importlib.util, json, os, pathlib, select, signal, socket, subprocess, sys, time
HERE=pathlib.Path(__file__).resolve()
RUNNER=pathlib.Path('/tmp/human-ai-r9-final-perf-runner.py')
PREREG=pathlib.Path('/tmp/human-ai-r9-final-perf-predeclared.json')
AUTH=pathlib.Path('/tmp/human-ai-r9-final-perf-authorization.json')
PLAN=pathlib.Path('/tmp/human-ai-r9-final-perf-pause-plan.json')
JOURNAL=pathlib.Path('/tmp/human-ai-r9-final-perf-pause-journal.jsonl')
LEASE=pathlib.Path('/tmp/human-ai-r9-final-perf-quiet-lease.json')
ROOTS=[1951992, 1609687, 1936262, 1952084]
FIELDS=['pid','startTime','uid','argv','cwd']
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def identity(pid):
 p=pathlib.Path(f'/proc/{pid}');s=(p/'stat').read_text().split(') ',1)[1].split()
 return {'pid':pid,'startTime':s[19],'uid':p.stat().st_uid,'argv':[x.decode() for x in (p/'cmdline').read_bytes().split(b'\0')[:-1]],'cwd':str((p/'cwd').resolve()),'ppid':int(s[1]),'state':s[0]}
def same(a,b):return all(a[k]==b[k] for k in FIELDS)
def verified_fd(expected):
 if not same(identity(expected['pid']),expected):raise RuntimeError('Identity mismatch before pidfd')
 fd=os.pidfd_open(expected['pid'])
 try:
  if not same(identity(expected['pid']),expected):raise RuntimeError('Identity mismatch after pidfd')
  return fd
 except BaseException:os.close(fd);raise
def tasks(pid):
 result={}
 for p in pathlib.Path(f'/proc/{pid}/task').iterdir():
  try:result[int(p.name)]=(p/'stat').read_text().split(') ',1)[1].split()[0]
  except FileNotFoundError:pass
 return result
def send(sock,value):sock.sendall(json.dumps(value).encode())
def receive(sock):
 data=sock.recv(262144)
 if not data:raise EOFError('guardian control closed')
 return json.loads(data)
def guardian(fd,journal,lease,deadline_seconds):
 sock=socket.socket(fileno=fd);held={};reason='error';deadline=time.monotonic()+deadline_seconds
 handle=open(journal,'x',buffering=1)
 def log(kind,**data):handle.write(json.dumps({'time':time.time(),'kind':kind,**data})+'\n');handle.flush();os.fsync(handle.fileno())
 def write_lease(active,reason):
  target=pathlib.Path(lease);tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps({'active':active,'guardianPID':os.getpid(),'reason':reason,'updatedAt':time.time(),'journal':journal}));os.replace(tmp,target)
 try:
  log('ready',pid=os.getpid(),deadlineSeconds=deadline_seconds);write_lease(False,'registering');send(sock,{'ready':True,'pid':os.getpid()})
  while True:
   remaining=deadline-time.monotonic()
   if remaining<=0:reason='safety deadline';break
   if not select.select([sock],[],[],remaining)[0]:reason='safety deadline';break
   raw=sock.recv(262144)
   if not raw:reason='parent pipe EOF';break
   msg=json.loads(raw);op=msg['op']
   if op=='register':
    expected=msg['identity'];pid=expected['pid']
    if pid in held:raise RuntimeError('Duplicate registration')
    if expected['state'] in ['T','t']:raise RuntimeError('Refuse already stopped process')
    held[pid]=(verified_fd(expected),expected);log('registered',identity=expected);send(sock,{'registered':pid})
   elif op=='stop':
    pid=msg['pid'];pfd,expected=held[pid]
    current=identity(pid)
    if not same(current,expected) or current['state'] in ['T','t']:raise RuntimeError('Identity or stop ownership changed')
    signal.pidfd_send_signal(pfd,signal.SIGSTOP);log('stopRequested',pid=pid);send(sock,{'stopRequested':pid})
   elif op=='stopped':log('stopped',pid=msg['pid'],tasks=msg['tasks']);send(sock,{'ok':True})
   elif op=='quiet':write_lease(True,'all authorized tasks stopped');log('quiet');send(sock,{'ok':True})
   elif op=='release':reason='parent finally';break
   else:raise RuntimeError('Unknown guardian operation')
 except BaseException as error:
  try:log('guardianError',error=repr(error))
  except OSError:pass
  reason='guardian error: '+repr(error)
 finally:
  try:write_lease(False,reason)
  except OSError:pass
  def safe_log(kind,**data):
   try:log(kind,**data)
   except OSError:pass
  # A pidfd refers to the registered process, never a reused numeric PID.
  for pid,(pfd,expected) in reversed(list(held.items())):
   try:signal.pidfd_send_signal(pfd,signal.SIGCONT);safe_log('continued',pid=pid,identity=expected)
   except ProcessLookupError:safe_log('naturallyExited',pid=pid)
   except BaseException as error:safe_log('resumeError',pid=pid,error=repr(error))
   finally:os.close(pfd)
  safe_log('released',reason=reason)
  try:send(sock,{'released':True,'reason':reason})
  except OSError:pass
  sock.close();handle.close()
def start_guardian(journal,lease,seconds=60):
 if pathlib.Path(journal).exists() or pathlib.Path(lease).exists():raise RuntimeError('Preserve existing guardian evidence')
 parent,child=socket.socketpair(socket.AF_UNIX,socket.SOCK_SEQPACKET)
 proc=subprocess.Popen([sys.executable,str(HERE),'--guardian',str(child.fileno()),str(journal),str(lease),str(seconds)],pass_fds=(child.fileno(),),start_new_session=True,stdin=subprocess.DEVNULL)
 child.close();parent.settimeout(5)
 try:
  ready=receive(parent)
  if not ready.get('ready'):raise RuntimeError('Guardian not ready')
  return parent,proc
 except BaseException:parent.close();proc.wait();raise
def request(sock,msg):send(sock,msg);reply=receive(sock);return reply
def stop_one(sock,expected):
 if identity(expected['pid'])['state'] in ['T','t']:raise RuntimeError('Do not resume a process stopped before this window')
 fd=verified_fd(expected)
 try:
  if request(sock,{'op':'register','identity':expected}).get('registered')!=expected['pid']:raise RuntimeError('No registration acknowledgement')
  if not same(identity(expected['pid']),expected):raise RuntimeError('Identity changed after registration')
  if request(sock,{'op':'stop','pid':expected['pid']}).get('stopRequested')!=expected['pid']:raise RuntimeError('Guardian did not request STOP')
  deadline=time.monotonic()+3
  while True:
   states=tasks(expected['pid'])
   if states and all(s in ['T','t'] for s in states.values()):break
   if time.monotonic()>=deadline:raise RuntimeError('Tasks did not stop')
   time.sleep(.01)
  request(sock,{'op':'stopped','pid':expected['pid'],'tasks':states})
 finally:os.close(fd)
def all_processes():
 result={}
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:result[int(p.name)]=identity(int(p.name))
  except (OSError,ValueError,UnicodeError):pass
 return result
def descendants(records,roots):
 found=set(roots)
 while True:
  extra={pid for pid,row in records.items() if row['ppid'] in found}-found
  if not extra:return found
  found|=extra
def check_authorization():
 auth=json.loads(AUTH.read_text())
 checks={'wrapperSHA256':sha(HERE),'runnerSHA256':sha(RUNNER),'predeclaredSHA256':sha(PREREG),'pausePlanSHA256':sha(PLAN)}
 if not all(auth.get(k)==v for k,v in checks.items()) or auth.get('pauseAuthorized') is not True or auth.get('quietAuthorized') is not True or auth.get('sourceAuthorized') is not True:raise RuntimeError('Exact root authorization missing')
 return auth
def release(sock,proc,registered):
 try:
  try:send(sock,{'op':'release'})
  except OSError:pass
 finally:
  sock.close()
  # Independently resume in the wrapper too, even if the guardian crashed.
  resume_errors=[]
  for expected in registered.values():
   try:
    fd=verified_fd(expected)
    try:signal.pidfd_send_signal(fd,signal.SIGCONT)
    finally:os.close(fd)
   except (FileNotFoundError,ProcessLookupError):pass
   except BaseException as error:resume_errors.append(repr(error))
  proc.wait() # EOF is sufficient even if the release message failed.
 for expected in registered.values():
  try:
   current=identity(expected['pid'])
   if same(current,expected) and any(s in ['T','t'] for s in tasks(expected['pid']).values()):raise RuntimeError('Registered process remains stopped after guardian exit')
  except FileNotFoundError:pass
def run():
 check_authorization()
 plan=json.loads(PLAN.read_text());expected={r['pid']:r for r in plan['recordedProcesses']}
 if any(pid not in expected for pid in ROOTS):raise RuntimeError('Missing root identities')
 registered={};sock=None;guard=None;runner=None
 try:
  # All original identities must still match or be naturally absent. No PID substitution.
  live=all_processes()
  for pid,row in expected.items():
   if pid in live and not same(live[pid],row):raise RuntimeError('An original PID identity changed')
  for pid in descendants(live,[p for p in ROOTS if p in live]):
   if pid not in expected or not same(live[pid],expected[pid]):raise RuntimeError('Unknown descendant before pause; refresh review instead of guessing ownership')
  sock,guard=start_guardian(JOURNAL,LEASE)
  for pid in ROOTS:
   if pid in live:registered[pid]=expected[pid];stop_one(sock,expected[pid])
  while True:
   live=all_processes();owned=descendants(live,[p for p in ROOTS if p in live]);pending=owned-set(registered)
   if not pending:break
   # Parent-first fixed point. Unknown children are refused and all registered jobs resumed.
   progress=False
   for pid in sorted(pending):
    row=live[pid]
    if pid not in expected or not same(row,expected[pid]):raise RuntimeError('Unknown descendant during pause')
    if row['ppid'] not in registered:continue
    registered[pid]=row;stop_one(sock,row);progress=True
   if not progress:raise RuntimeError('Could not stop complete owned tree')
  for pid in registered:
   if any(s not in ['T','t'] for s in tasks(pid).values()):raise RuntimeError('A registered task is no longer stopped')
  request(sock,{'op':'quiet'})
  env={**os.environ,'HUMAN_AI_QUIET_LEASE':str(LEASE)}
  runner=subprocess.Popen([sys.executable,str(RUNNER),'--run-after-root-freeze'],env=env)
  code=runner.wait()
  if code:raise RuntimeError(f'Benchmark runner failed: {code}')
 finally:
  # If interrupted, resume campaigns immediately. The started native row is never killed.
  if sock is not None:release(sock,guard,registered)
  if runner is not None and runner.poll() is None:runner.wait()
def dry_run():
 plan=json.loads(PLAN.read_text());live=all_processes();rows=[]
 for expected in plan['recordedProcesses']:
  row=live.get(expected['pid']);rows.append({'pid':expected['pid'],'alive':row is not None,'identityMatches':row is None or same(row,expected)})
 print(json.dumps({'signalsSent':False,'identities':rows,'pidfdAvailable':hasattr(os,'pidfd_open') and hasattr(signal,'pidfd_send_signal'),'runnerSHA256':sha(RUNNER),'wrapperSHA256':sha(HERE)},indent=2))
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='--guardian':guardian(int(sys.argv[2]),sys.argv[3],sys.argv[4],float(sys.argv[5]))
 elif sys.argv[1:]==['--dry-run']:dry_run()
 elif sys.argv[1:]==['--run-after-root-authorization']:
  def interrupted(signum,frame):raise KeyboardInterrupt(f'signal {signum}')
  signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted);run()
 else:print('Prepared only. Use --dry-run for read-only checks. Explicit root authorization required to run.')
