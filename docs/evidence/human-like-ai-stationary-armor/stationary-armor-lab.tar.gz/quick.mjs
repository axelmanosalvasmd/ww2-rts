import {readFile,writeFile} from 'node:fs/promises';
import {createAIcase} from './captured-lab.mjs';
const [sim,ai,perception,hands,view]=await Promise.all(['sim','ai','ai-perception','ai-hands','ai-view'].map(n=>import(`./runtime/shared/${n}.js`)));
const scene=JSON.parse(await readFile('/tmp/ai-lab-response-current/episodes/hard-1-native-weapon-240.json')).authoredScene;
const r=createAIcase({sim,ai,perception,hands,view},{scenario:'guard',level:'hard',seed:1,seconds:30,collectPolicy:true},scene).advance(600);
await writeFile('/tmp/ai-lab-stationary-armor-fallback/native-positive.json',JSON.stringify(r));
console.log(JSON.stringify({commands:r.commands,rows:r.policies.manual.rows.map(r=>({creation:r.creation,decision:r.decision,answer:r.answer})),audit:r.policies.manual.audit},null,2));
