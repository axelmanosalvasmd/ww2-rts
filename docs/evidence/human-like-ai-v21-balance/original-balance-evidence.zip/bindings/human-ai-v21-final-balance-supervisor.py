#!/usr/bin/env python3
"""Predeclared V21 final balance supervision. No automatic retries or outer timeout."""
import argparse, datetime, hashlib, json, os, pathlib, statistics, subprocess, time, importlib.util
_schema_spec = importlib.util.spec_from_file_location("source_schema", "/tmp/human-ai-v21-final-balance-source-schema.py")
source_schema = importlib.util.module_from_spec(_schema_spec)
_schema_spec.loader.exec_module(source_schema)
PROTOCOL = pathlib.Path('/tmp/human-ai-prospective-v21-final-balance.json')

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, value):
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(path)

def verify(protocol):
    common = protocol['commonArchive']
    if not protocol.get('readyToLaunch') or not common.get('beforeManifestSHA256'):
        raise ValueError('V21 final protocol is unbound. ROOT source freeze and manifest binding are required.')
    if sha(common['beforeManifest']) != common['beforeManifestSHA256']:
        raise ValueError('Root before-manifest hash changed')
    manifest = json.loads(pathlib.Path(common['beforeManifest']).read_text())
    source = pathlib.Path(common['path'])
    checked = source_schema.check_archive(source, manifest, common['beforeManifest'])
    checked['checkedAtUTC'] = utc()
    return checked

def identity(pid):
    base = pathlib.Path('/proc') / str(pid)
    try:
        stat = (base / 'stat').read_text().rsplit(')', 1)[1].split()
        tasks = []
        for path in sorted((base / 'task').iterdir()):
            status = path.joinpath('status').read_text()
            allowed = next(line.split(':', 1)[1].strip() for line in status.splitlines() if line.startswith('Cpus_allowed_list:'))
            tasks.append({'tid': int(path.name), 'allowedCPUs': allowed})
        return {'pid': pid, 'startTicks': int(stat[19]), 'argv': (base / 'cmdline').read_bytes().replace(b'\0', b' ').decode(), 'cwd': os.readlink(base / 'cwd'), 'tasks': tasks}
    except (OSError, StopIteration):
        return None

def reduce_rows(rows, job, complete):
    numbers = [row['match'] for row in rows]
    if len(set(numbers)) != len(numbers):
        raise ValueError('Duplicate rows')
    for row in rows:
        i = row['match'] - 1
        if not 0 <= i < job['matches'] or row['seed'] != job['expectedSeeds'][i]:
            raise ValueError('Unexpected match or seed')
        if abs(row['seconds'] - row['ticks'] / 20) > .001 or row['seconds'] > job['maxSeconds'] + .001:
            raise ValueError('Invalid duration')
    if complete and sorted(numbers) != list(range(1, job['matches'] + 1)):
        raise ValueError('Missing final rows')
    wins = [row for row in rows if row['winner'] is not None and row['winner'] >= 0]
    ended = sum(row['winner'] is not None for row in rows)
    faction = {f: sum(row['winnerFaction'] == f for row in wins) for f in ['USA', 'Germany', 'USSR']}
    fractions = {f: n / len(wins) if wins else None for f, n in faction.items()}
    seat = [sum(row['winnerSeat'] == i for row in wins) for i in [0, 1]] if job['seats'] else None
    times = [row['seconds'] for row in rows]
    rounded = lambda value: None if value is None else int(value * 1000 + .5) / 1000
    summary = {'rows': len(rows), 'expectedRows': job['matches'], 'ended': ended, 'draws': ended - len(wins), 'timeouts': len(rows) - ended,
               'winsByFaction': faction, 'decisiveFractions': fractions, 'winsBySeat': seat,
               'medianSeconds': rounded(statistics.median(times)) if times else None,
               'medianEndedSeconds': rounded(statistics.median([row['seconds'] for row in rows if row['winner'] is not None])) if ended else None,
               'allFinish': complete and ended == job['matches']}
    if complete:
        gate = job['gate']
        summary['gatePass'] = summary['allFinish'] and (all(v is not None and gate['fractionMin'] <= v <= gate['fractionMax'] for v in fractions.values()) if 'fractionMin' in gate else seat[0] >= gate['hardMinWins'] if 'hardMinWins' in gate else True)
    return summary

def read_checkpoint(job):
    path = pathlib.Path(job['argv'][job['argv'].index('--checkpoint') + 1])
    return json.loads(path.read_text()) if path.exists() else None

def validate_sources(saved, protocol):
    root = pathlib.Path(protocol['commonArchive']['path'])
    manifest = json.loads(pathlib.Path(protocol['commonArchive']['beforeManifest']).read_text())['files']
    for path, digest in saved['sourceSHA256'].items():
        relative = str(pathlib.Path(path).relative_to(root))
        if source_schema.content_digest(root, {'files': manifest}, relative) != digest:
            raise ValueError('Runner source outside exact common manifest: ' + path)

def audit_final(job, protocol):
    lines = pathlib.Path(job['log']).read_text().splitlines()
    results = [json.loads(line[7:]) for line in lines if line.startswith('RESULT ')]
    if len(results) != 1:
        raise ValueError('Expected exactly one final RESULT')
    report = results[0]
    checkpoint = read_checkpoint(job)
    if checkpoint is None or report['results'] != checkpoint['results'] or report['sourceSHA256'] != checkpoint['sourceSHA256']:
        raise ValueError('Final RESULT/checkpoint identity mismatch')
    validate_sources(checkpoint, protocol)
    reduced = reduce_rows(report['results'], job, True)
    for key in ['ended', 'draws', 'timeouts', 'winsByFaction', 'winsBySeat', 'medianSeconds', 'medianEndedSeconds']:
        if report[key] != reduced[key]:
            raise ValueError('Independent reducer mismatch: ' + key)
    if report['maxSeconds'] != job['maxSeconds']:
        raise ValueError('Runner duration cap mismatch')
    save(pathlib.Path(job['json']), report)
    return {'independentReduction': reduced, 'runnerSourceFiles': len(report['sourceSHA256']),
            'reportSHA256': sha(job['json']), 'checkpointSHA256': sha(job['argv'][job['argv'].index('--checkpoint') + 1]),
            'logSHA256': sha(job['log']), 'runnerElapsedSeconds': report['elapsedSeconds']}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify-only', action='store_true')
    parser.add_argument('--launch-after-root-clearance', action='store_true')
    args = parser.parse_args()
    protocol = json.loads(PROTOCOL.read_text())
    check = verify(protocol)
    if check['mismatches']:
        raise ValueError('Frozen common archive drift: ' + str(check['mismatches']))
    if args.verify_only:
        print(json.dumps({'source': check, 'order': protocol['scheduling']['defaultAfterAllGatesClear']['order'], 'affinity': [0, 2, 8], 'workers': 3, 'campaignsLaunched': 0}, indent=2))
        return
    if not args.launch_after_root_clearance:
        parser.error('Launch requires explicit root clearance')
    out = pathlib.Path(protocol['supervisor']['output'])
    out.mkdir(exist_ok=False)
    save(out / 'protocol.json', protocol)
    state = {'startedAtUTC': utc(), 'protocolSHA256': sha(PROTOCOL), 'supervisorSHA256': sha(__file__),
             'sourceBefore': check, 'outerTimeout': None, 'jobs': {}, 'sourceChanges': []}
    save(out / 'supervision.json', state)
    for name in protocol['scheduling']['defaultAfterAllGatesClear']['order']:
        job = protocol['jobs'][name]
        before = verify(protocol)
        if before['mismatches']:
            state['sourceChanges'].append(before)
            break
        started = time.monotonic()
        entry = {'argv': job['argv'], 'startedAtUTC': utc(), 'sourceBefore': before, 'status': 'running', 'identities': []}
        state['jobs'][name] = entry
        with pathlib.Path(job['log']).open('x') as log:
            child = subprocess.Popen(job['argv'], cwd=protocol['commonArchive']['path'], stdout=log, stderr=subprocess.STDOUT)
            entry['pid'] = child.pid
            entry['identities'].append(identity(child.pid))
            save(out / 'supervision.json', state)
            last_source_check = started
            captured_threads = False
            while child.poll() is None:
                time.sleep(5)
                if not captured_threads:
                    ident = identity(child.pid)
                    if ident:
                        entry['identities'].append(ident)
                        captured_threads = len(ident['tasks']) > 1
                try:
                    checkpoint = read_checkpoint(job)
                    if checkpoint:
                        validate_sources(checkpoint, protocol)
                        entry['progress'] = reduce_rows(checkpoint['results'], job, False)
                except Exception as error:
                    entry.setdefault('auditErrors', []).append({'atUTC': utc(), 'error': str(error)})
                if time.monotonic() - last_source_check >= 60:
                    checking = verify(protocol)
                    if checking['mismatches']:
                        state['sourceChanges'].append(checking)
                    last_source_check = time.monotonic()
                save(out / 'supervision.json', state)
            entry['exitCode'] = child.returncode
        entry['finishedAtUTC'] = utc()
        entry['wallSeconds'] = round(time.monotonic() - started, 3)
        entry['sourceAfter'] = verify(protocol)
        if entry['sourceAfter']['mismatches']:
            state['sourceChanges'].append(entry['sourceAfter'])
        entry['status'] = 'finished' if child.returncode == 0 else 'runner failed'
        if child.returncode == 0:
            try:
                entry['audit'] = audit_final(job, protocol)
            except Exception as error:
                entry['status'] = 'audit failed'
                entry['auditFailure'] = str(error)
        save(out / 'supervision.json', state)
        if state['sourceChanges']:
            break
    state['finishedAtUTC'] = utc()
    state['sourceAfter'] = verify(protocol)
    state['completedJobs'] = list(state['jobs'])
    save(out / 'supervision.json', state)
    print(json.dumps(state, indent=2), flush=True)

if __name__ == '__main__':
    main()
