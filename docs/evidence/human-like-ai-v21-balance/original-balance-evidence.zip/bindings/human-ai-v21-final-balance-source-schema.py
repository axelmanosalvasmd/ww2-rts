"""Validate the full-suite metadata manifest without following external dependency links."""
import hashlib,json,os,pathlib,re,stat

def sha(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def canonical(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def entry(path):
 if path.is_symlink():
  target=os.readlink(path);return {'kind':'symlink','target':target,'sha256':hashlib.sha256(os.fsencode(target)).hexdigest()}
 if path.is_file():return {'kind':'file','sha256':sha(path),'bytes':path.stat().st_size}
 raise ValueError('Missing or unsupported source member: '+str(path))

def schema(files):
 if not isinstance(files,dict) or not files:raise ValueError('Manifest requires nonempty metadata files map')
 for name,m in files.items():
  path=pathlib.PurePosixPath(name)
  if not name or path.is_absolute() or '..' in path.parts or name=='node_modules' or name.startswith('node_modules/'):
   raise ValueError('Invalid source member path: '+name)
  if not isinstance(m,dict) or not re.fullmatch('[0-9a-f]{64}',str(m.get('sha256',''))):raise ValueError('Invalid member metadata: '+name)
  if m.get('kind')=='file':
   if set(m)!={'kind','sha256','bytes'} or type(m['bytes']) is not int or m['bytes']<0:raise ValueError('Invalid file metadata: '+name)
  elif m.get('kind')=='symlink':
   if set(m)!={'kind','sha256','target'} or not isinstance(m['target'],str) or not m['target'] or pathlib.Path(m['target']).is_absolute():raise ValueError('Invalid symlink metadata: '+name)
   if hashlib.sha256(os.fsencode(m['target'])).hexdigest()!=m['sha256']:raise ValueError('Symlink target identity digest mismatch: '+name)
  else:raise ValueError('Unknown metadata kind: '+name)

def check_archive(source,manifest,manifest_path=None):
 source=pathlib.Path(source);files=manifest['files'];schema(files);errors=[];actual={};directories=[];declared_links={}
 if not source.is_dir() or source.is_symlink():return {'files':len(files),'mismatches':['source root must be an ordinary directory']}
 for current,dirs,names in os.walk(source,followlinks=False):
  current=pathlib.Path(current);directories.append(current)
  for name in list(dirs):
   path=current/name
   if path==source/'node_modules':dirs.remove(name);continue
   if path.is_symlink():actual[str(path.relative_to(source))]=entry(path);dirs.remove(name)
  for name in names:
   path=current/name
   if path!=source/'node_modules':actual[str(path.relative_to(source))]=entry(path)
 for name in sorted(set(files)|set(actual)):
  if files.get(name)!=actual.get(name):errors.append('metadata or file set differs: '+name)
 for name,m in files.items():
  path=source/name
  if m['kind']=='symlink':
   try:
    target=path.resolve(strict=True);rel=str(target.relative_to(source.resolve()))
    if target.is_file():
     if rel not in files or files[rel]['kind']!='file':errors.append('source symlink target is not a captured regular file: '+name)
     declared_links[name]={'kind':'file','path':rel}
    elif target.is_dir():
     prefix=rel.rstrip('/')+'/'
     captured=[member for member in files if member.startswith(prefix)]
     if not captured:errors.append('source directory symlink target has no captured subtree: '+name)
     subtree=[]
     for current,dirs,names in os.walk(target,followlinks=False):
      current=pathlib.Path(current)
      for child in list(dirs):
       item=current/child
       if item.is_symlink():subtree.append(str(item.relative_to(source)));dirs.remove(child)
      subtree.extend(str((current/child).relative_to(source)) for child in names)
     if not subtree or {member:entry(source/member) for member in subtree}!={member:files[member] for member in captured}:errors.append('source directory symlink target subtree is incomplete: '+name)
     declared_links[name]={'kind':'directory','path':rel,'members':sorted(subtree)}
    else:errors.append('source symlink target is unsupported: '+name)
   except (OSError,ValueError,RuntimeError):errors.append('source symlink target missing or outside archive: '+name)
  elif path.exists() and not path.is_symlink() and stat.S_IMODE(path.stat().st_mode)&0o222:errors.append('source file writable: '+name)
 for path in directories:
  if stat.S_IMODE(path.stat().st_mode)&0o222:errors.append('source directory writable: '+str(path.relative_to(source)))
 if manifest.get('sourceLinkTargets')!=declared_links:errors.append('full-suite source link target declarations differ')
 dependency=source/'node_modules';expected=manifest.get('dependencyLink')
 if not isinstance(expected,str) or not dependency.is_symlink() or os.readlink(dependency)!=expected:errors.append('node_modules dependency symlink identity differs')
 if manifest_path is not None and stat.S_IMODE(pathlib.Path(manifest_path).stat().st_mode)&0o222:errors.append('source manifest writable')
 digest=canonical(files)
 if manifest.get('fileManifestDigest')!=digest:errors.append('full-suite canonical metadata digest differs')
 if manifest.get('archive')!=str(source):errors.append('manifest common archive path differs')
 if manifest.get('bytes')!=sum(m.get('bytes',0) for m in files.values()):errors.append('manifest total source bytes differ')
 return {'files':len(files),'mismatches':errors,'fileManifestDigest':digest,'sourceSymlinks':sum(m['kind']=='symlink' for m in files.values()),'readOnlySourceChecked':True,'externalDependencyContentsCertified':False}

def content_digest(source,manifest,name):
 m=manifest['files'][name]
 if m['kind']=='file':return m['sha256']
 target=(pathlib.Path(source)/name).resolve(strict=True);rel=str(target.relative_to(pathlib.Path(source).resolve()))
 if not target.is_file() or rel not in manifest['files']:raise ValueError('Runner import target not a captured regular file: '+name)
 m=manifest['files'][rel]
 if m['kind']!='file':raise ValueError('Runner import target not a captured file: '+name)
 return m['sha256']
