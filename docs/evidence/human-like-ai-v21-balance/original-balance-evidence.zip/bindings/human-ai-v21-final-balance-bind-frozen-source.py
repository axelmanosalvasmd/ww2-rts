"""Bind the proposed protocol after ROOT freeze. Never creates a runtime archive or launches a campaign."""
import argparse,datetime,hashlib,json,pathlib,importlib.util
_spec=importlib.util.spec_from_file_location("schema","/tmp/human-ai-v21-final-balance-source-schema.py");schema=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(schema)
p=argparse.ArgumentParser();p.add_argument('--bind-after-root-freeze',action='store_true');p.add_argument('--manifest',required=True);a=p.parse_args()
if not a.bind_after_root_freeze:p.error('Explicit ROOT freeze is required before binding')
protocol=pathlib.Path('/tmp/human-ai-prospective-v21-final-balance.json');d=json.loads(protocol.read_text())
if d.get('readyToLaunch'):raise SystemExit('Protocol already bound; no automatic rebinding')
mfile=pathlib.Path(a.manifest);m=json.loads(mfile.read_text());source=pathlib.Path('/tmp/human-ai-v21-final-full-source')
for name in d['sourcePreview']['requiredRuntimePaths']:
 if m['files'].get(name,{}).get('kind')!='file':raise SystemExit('Final runtime source must be a captured regular file: '+name)
checked=schema.check_archive(source,m,mfile)
if checked['mismatches']:raise SystemExit('Common metadata archive verification failed: '+str(checked['mismatches']))
d['commonArchive'].update(beforeManifest=str(mfile.resolve()),beforeManifestSHA256=hashlib.sha256(mfile.read_bytes()).hexdigest(),files=len(m['files']),bytes=sum(v.get('bytes',0) for v in m['files'].values()),fileManifestDigest=hashlib.sha256(json.dumps(m['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),coreSHA256={n:m['files'][n]['sha256'] for n in d['sourcePreview']['corePaths']},bindingStatus='Exact common source verified after root freeze',boundAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
d['readyToLaunch']=True;protocol.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'boundProtocol':str(protocol),'sha256':hashlib.sha256(protocol.read_bytes()).hexdigest(),'sourceFilesVerified':len(m['files']),'campaignsLaunched':0},indent=2))
