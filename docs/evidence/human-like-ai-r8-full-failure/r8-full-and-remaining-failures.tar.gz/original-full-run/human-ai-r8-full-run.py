#!/usr/bin/env python3
"""Prospective R8 suite runner. Preparation never freezes or launches a suite."""
import argparse
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path('/home/judiazm/.t3/worktrees/ww2-rts/ai-human-commander')
BASE = pathlib.Path('/tmp')
SCRIPT = pathlib.Path(__file__).resolve()
PREFIX = 'human-ai-r8-new-full'
PATHS = {name: BASE / f'{PREFIX}-{name}{suffix}' for name, suffix in {
    'prospective': '.json', 'predeclared': '.json', 'before': '.json', 'after': '.json',
    'checks': '.jsonl', 'test': '.log', 'test-exit': '.txt', 'launch': '.json',
    'completion': '.json', 'verification': '.json', 'controller': '.log', 'background-launch': '.json'
}.items()}
ARCHIVE = BASE / f'{PREFIX}-source'
EXACT_METADATA = {'CHANGELOG.md', 'DESIGN.md', 'docs/human-like-ai-spec.md'}
ORIGINAL = BASE / 'human-ai-v21-final-full-predeclared.json'


def metadata(name):
    return name in EXACT_METADATA or name.startswith('docs/evidence/')


def digest(value):
    return hashlib.sha256(value).hexdigest()


def file_digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            h.update(block)
    return h.hexdigest()


def canonical(value):
    return digest(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def names():
    return sorted(set(os.fsdecode(git('ls-files', '--cached', '--others', '--exclude-standard', '-z')).split('\0')) - {''})


def entry(path):
    if path.is_symlink():
        target = os.readlink(path)
        return {'kind': 'symlink', 'target': target, 'sha256': digest(os.fsencode(target))}
    if path.is_file():
        return {'kind': 'file', 'bytes': path.stat().st_size, 'sha256': file_digest(path)}
    raise RuntimeError(f'Missing or unsupported source member: {path}')


def snapshot(include_metadata=False):
    selected = names()
    if not include_metadata:
        selected = [name for name in selected if not metadata(name)]
    return {'capturedAtUnix': time.time(), 'head': git('rev-parse', 'HEAD').decode().strip(),
            'files': {name: entry(ROOT / name) for name in selected}}


def changes(before, after):
    return [name for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)]


def registration():
    source = (ROOT / 'test.js').read_text()
    block = re.search(r'for \(const file of \[(.*?)\]\) \{\s*execFileSync\(process.execPath, \[file\], \{(.*?)\}\);', source, re.S)
    if not block or not re.search(r'\btimeout:\s*180000\b', block[2]):
        raise RuntimeError('Original child registration/180000ms timeout changed')
    children = re.findall(r"['\"](test[^'\"]+\.(?:js|mjs))['\"]", block[1])
    direct = re.findall(r"await import\(['\"]\./(test[^'\"]+\.(?:js|mjs))['\"]\)", source)
    if not children or len(set(children)) != len(children):
        raise RuntimeError('Missing or duplicate registered child')
    historical = json.loads(ORIGINAL.read_text())['registration']
    if set(historical['children']) - set(children) or set(historical['directImports']) - set(direct):
        raise RuntimeError('An original V21 native child or direct import was dropped')
    covered = set(children + direct + ['test.js'])
    ai = sorted(path.name for path in ROOT.glob('test-engine-ai*.js'))
    think = sorted(path.name for pattern in ['test*.js', 'test*.mjs'] for path in ROOT.glob(pattern)
                   if re.search(r'\bthink\s*\(', path.read_text()))
    missing = set(ai + think + ['test-world-observation.js']) - covered
    if missing:
        raise RuntimeError(f'Required AI/think/world-observation coverage missing: {sorted(missing)}')
    if any(not (ROOT / name).is_file() for name in children + direct):
        raise RuntimeError('A registered native test is missing')
    additional = re.findall(r"execFileSync\(process.execPath, \[['\"]([^'\"]+)['\"]\], \{[^}]*?timeout:\s*(\d+)", source)
    return {'children': children, 'childCount': len(children), 'directImports': direct,
            'allAITests': ai, 'thinkPatternTests': think, 'focusedChildTimeoutMS': 180000,
            'additionalNativeProcesses': [{'file': f, 'timeoutMS': int(t)} for f, t in additional],
            'testJSSHA256': file_digest(ROOT / 'test.js'),
            'assertCallCountDiagnostic': len(re.findall(r'\bassert(?:\.[A-Za-z]+)?\s*\(', source))}


def runtime(full=True):
    node = shutil.which('node')
    if not node:
        raise RuntimeError('Node executable missing')
    result = {'nodeExecutable': os.path.realpath(node),
              'packageSHA256': file_digest(ROOT / 'package.json'),
              'lockfileSHA256': file_digest(ROOT / 'package-lock.json'),
              'installedPackageMetadata': {name: file_digest(ROOT / 'node_modules' / name / 'package.json')
                                           for name in ['three', 'ws']}}
    if full:
        result.update({'nodeVersion': subprocess.check_output(['node', '--version'], text=True).strip(),
                       'nodeExecutableSHA256': file_digest(pathlib.Path(result['nodeExecutable'])),
                       'pythonVersion': sys.version})
    return result


def archive_snapshot(include_metadata=True):
    files = {}
    for current, dirs, leaves in os.walk(ARCHIVE, followlinks=False):
        directory = pathlib.Path(current)
        for name in list(dirs):
            path = directory / name
            if path == ARCHIVE / 'node_modules':
                dirs.remove(name)
            elif not include_metadata and str(path.relative_to(ARCHIVE)) == 'docs/evidence':
                dirs.remove(name)
            elif path.is_symlink():
                relative = str(path.relative_to(ARCHIVE))
                if include_metadata or not metadata(relative):
                    files[relative] = entry(path)
                dirs.remove(name)
        for name in leaves:
            path = directory / name
            relative = str(path.relative_to(ARCHIVE))
            if path != ARCHIVE / 'node_modules' and (include_metadata or not metadata(relative)):
                files[relative] = entry(path)
    return dict(sorted(files.items()))


def archive_permissions():
    writable = []
    for current, _, leaves in os.walk(ARCHIVE, followlinks=False):
        directory = pathlib.Path(current)
        if directory.stat().st_mode & 0o222:
            writable.append(str(directory.relative_to(ARCHIVE)) or '.')
        for name in leaves:
            path = directory / name
            if not path.is_symlink() and path.stat().st_mode & 0o222:
                writable.append(str(path.relative_to(ARCHIVE)))
    link = ARCHIVE / 'node_modules'
    return {'readOnly': not writable, 'writable': writable,
            'dependencyLinkMatches': link.is_symlink() and os.readlink(link) == str(ROOT / 'node_modules')}


def create_archive(captured):
    if ARCHIVE.exists():
        raise RuntimeError(f'Archive already exists, retain it: {ARCHIVE}')
    stage = pathlib.Path(str(ARCHIVE) + '.partial')
    stage.mkdir()
    links = {}
    for name, value in captured['files'].items():
        original, copied = ROOT / name, stage / name
        copied.parent.mkdir(parents=True, exist_ok=True)
        if value['kind'] == 'symlink':
            target = original.resolve(strict=True)
            if pathlib.Path(value['target']).is_absolute() or not target.is_relative_to(ROOT):
                raise RuntimeError(f'External/absolute source link requires review: {name}')
            if target.is_file() and str(target.relative_to(ROOT)) not in captured['files']:
                raise RuntimeError(f'Source link file target not captured: {name}')
            if target.is_dir():
                for f in target.rglob('*'):
                    if f.is_file() and str(f.relative_to(ROOT)) not in captured['files']:
                        raise RuntimeError(f'Source link directory member not captured: {name}, {f}')
            copied.symlink_to(value['target'])
            links[name] = str(target.relative_to(ROOT))
        else:
            shutil.copyfile(original, copied)
            if not metadata(name) and entry(copied) != value:
                raise RuntimeError(f'Source changed during archive copy: {name}')
    (stage / 'node_modules').symlink_to(ROOT / 'node_modules', target_is_directory=True)
    for current, _, leaves in os.walk(stage, followlinks=False):
        for name in leaves:
            path = pathlib.Path(current) / name
            if not path.is_symlink():
                path.chmod(0o444)
    for current, _, _ in os.walk(stage, topdown=False, followlinks=False):
        pathlib.Path(current).chmod(0o555)
    stage.rename(ARCHIVE)
    archive = archive_snapshot()
    expected = {n: v for n, v in captured['files'].items() if not metadata(n)}
    actual = {n: v for n, v in archive.items() if not metadata(n)}
    if actual != expected or not archive_permissions()['readOnly']:
        raise RuntimeError('Archive source bytes or permissions mismatch')
    return archive, links


def base_protocol():
    return {'schema': 'ww2-r8-prospective-native-full-suite-v1', 'status': 'PREPARED NOT LAUNCHED',
            'root': str(ROOT), 'command': ['taskset', '-c', '4', 'node', 'test.js'],
            'nativeLiteralCommand': 'node test.js', 'outerTimeout': None, 'sourcePollSeconds': 15,
            'supervisorCPU': 1, 'nativeCPU': 4,
            'metadataExceptions': {'exactFiles': sorted(EXACT_METADATA), 'prefixes': ['docs/evidence/']},
            'sourcePolicy': 'Every tracked and new Git-visible source/test/tool/other document stays locked. Added/deleted/changed nonexception files and HEAD changes fail source integrity. Metadata exceptions may change while the unchanged suite runs.',
            'failurePolicy': 'Retain every source-check failure. Never signal or terminate the native suite for a source-check failure; let it finish naturally and record its separate actual exit. No outer timeout.',
            'archivePolicy': 'Only after explicit ROOT launch. Complete Git-visible source snapshot copied readonly with internal source links validated and node_modules as its sole external dependency link. Archive metadata stays sealed even when ROOT documentation updates.',
            'coveragePolicy': 'Preserve all original V21 native children/direct imports, all current AI and think tests, world observation, original180000ms native child timeout, all assertions and additional test.js subprocess timeouts.',
            'registrationAtPreparation': registration(), 'runtimeAtPreparation': runtime(),
            'historicalReference': {'path': str(ORIGINAL), 'sha256': file_digest(ORIGINAL)},
            'scriptSHA256': file_digest(SCRIPT), 'outputs': {k: str(v) for k, v in PATHS.items()},
            'archive': str(ARCHIVE), 'preparedAtUnix': time.time(),
            'launchRequirements': ['explicit ROOT authorization string', 'expected current test.js SHA256', 'expected current registered child count']}


def prepare():
    protocol = base_protocol()
    write_new(PATHS['prospective'], protocol)
    print(json.dumps(protocol, indent=2))


def check_during(before, predeclared):
    actual = snapshot()
    archive = archive_snapshot(include_metadata=False)
    expected_runtime = {k: v for k, v in predeclared['runtime'].items()
                        if k not in ['nodeVersion', 'nodeExecutableSHA256', 'pythonVersion']}
    perms = archive_permissions()
    result = {'atUnix': time.time(), 'headMatches': actual['head'] == before['head'],
              'sourceFiles': len(actual['files']), 'sourceDigest': canonical(actual['files']),
              'sourceChanged': changes(before['lockedFiles'], actual['files']),
              'archiveChanged': changes({n: v for n, v in before['archiveFiles'].items() if not metadata(n)}, archive),
              'runtimeMatches': runtime(full=False) == expected_runtime,
              'registrationMatches': registration() == predeclared['registration'],
              'supervisorMatches': file_digest(SCRIPT) == predeclared['scriptSHA256'],
              **perms}
    result['valid'] = bool(result['headMatches'] and not result['sourceChanged'] and not result['archiveChanged']
                           and result['runtimeMatches'] and result['registrationMatches']
                           and result['supervisorMatches'] and result['readOnly'] and result['dependencyLinkMatches'])
    return result


def run(args):
    if not args.root_authorization or not args.expected_test_sha or args.expected_child_count is None:
        raise RuntimeError('Explicit ROOT authorization and exact expected test hash/count required')
    for key, path in PATHS.items():
        if key not in ['prospective', 'controller', 'background-launch'] and path.exists():
            raise RuntimeError(f'Existing R8-new output, retain it: {path}')
    if not PATHS['prospective'].exists():
        raise RuntimeError('Prospective protocol not prepared')
    prospective = json.loads(PATHS['prospective'].read_text())
    if prospective['scriptSHA256'] != file_digest(SCRIPT):
        raise RuntimeError('Runner changed after prospective preparation')
    tests = registration()
    if tests['testJSSHA256'] != args.expected_test_sha or tests['childCount'] != args.expected_child_count:
        raise RuntimeError('ROOT-approved exact test hash/count mismatch')
    os.sched_setaffinity(0, {1})
    full = snapshot(include_metadata=True)
    archived, links = create_archive(full)
    before = {'capturedAtUnix': full['capturedAtUnix'], 'head': full['head'],
              'lockedFiles': {n: v for n, v in full['files'].items() if not metadata(n)},
              'metadataAtCapture': {n: v for n, v in full['files'].items() if metadata(n)},
              'archiveFiles': archived, 'sourceLinks': links, 'archive': str(ARCHIVE),
              'dependencyLink': str(ROOT / 'node_modules')}
    write_new(PATHS['before'], before)
    protocol = {**prospective, 'status': 'ROOT AUTHORIZED SOURCE CAPTURED',
                'rootAuthorization': args.root_authorization, 'registration': tests, 'runtime': runtime(),
                'beforeSHA256': file_digest(PATHS['before']),
                'prospectiveSHA256': file_digest(PATHS['prospective']), 'frozenAtUnix': time.time()}
    write_new(PATHS['predeclared'], protocol)
    first = check_during(before, protocol)
    if not first['valid']:
        raise RuntimeError(f'Prelaunch source invalid, no suite launched: {first}')
    all_checks = [first]
    with PATHS['checks'].open('x') as checks, PATHS['test'].open('xb') as log:
        checks.write(json.dumps(first) + '\n'); checks.flush()
        child = subprocess.Popen(protocol['command'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=True)
        launched = {'startedAtUnix': time.time(), 'pid': child.pid, 'command': protocol['command'],
                    'cwd': str(ROOT), 'supervisorPID': os.getpid(), 'nativeCPU': 4,
                    'outerTimeout': None, 'predeclaredSHA256': file_digest(PATHS['predeclared'])}
        write_new(PATHS['launch'], launched)
        print('NATIVE_FULL_SUITE_PID', child.pid, flush=True)
        while child.poll() is None:
            # Bounded observation waits allow natural completion to be recorded promptly.
            for _ in range(15):
                if child.poll() is not None:
                    break
                time.sleep(1)
            try:
                current = check_during(before, protocol)
            except Exception as error:
                current = {'atUnix': time.time(), 'valid': False, 'error': f'{type(error).__name__}: {error}'}
            all_checks.append(current); checks.write(json.dumps(current) + '\n'); checks.flush()
        completed = {'exitCode': child.returncode, 'finishedAtUnix': time.time(),
                     'naturalCompletion': True, 'nativePID': child.pid, 'nativeLogBytes': PATHS['test'].stat().st_size}
        write_new(PATHS['completion'], completed)
        with PATHS['test-exit'].open('x') as sentinel:
            sentinel.write(f'EXIT_CODE={child.returncode}\n')
    after = snapshot(include_metadata=True)
    write_new(PATHS['after'], after)
    source_changed = changes(before['lockedFiles'], {n: v for n, v in after['files'].items() if not metadata(n)})
    metadata_changed = changes(before['metadataAtCapture'], {n: v for n, v in after['files'].items() if metadata(n)})
    invalid = [c for c in all_checks if not c.get('valid')]
    final_runtime_matches = runtime() == protocol['runtime']
    integrity = (file_digest(SCRIPT) == protocol['scriptSHA256']
                 and file_digest(PATHS['prospective']) == protocol['prospectiveSHA256']
                 and file_digest(PATHS['before']) == protocol['beforeSHA256']
                 and file_digest(PATHS['predeclared']) == launched['predeclaredSHA256'])
    archive_changed = changes(before['archiveFiles'], archive_snapshot())
    summary = {'nativeExitCode': child.returncode, 'nativeNaturalCompletion': True,
               'sourceFilesBefore': len(before['lockedFiles']),
               'sourceFilesAfter': len(after['files']) - sum(metadata(n) for n in after['files']),
               'sourceHashesIdentical': not source_changed, 'sourceChanged': source_changed,
               'allowedMetadataChanged': metadata_changed, 'headIdentical': before['head'] == after['head'],
               'archiveChanged': archive_changed, 'duringChecks': len(all_checks), 'invalidChecks': invalid,
               'runtimeBeforeAfterMatches': final_runtime_matches, 'runnerProtocolIntegrity': integrity,
               'registration': tests, 'metadataExceptions': protocol['metadataExceptions'],
               'artifactSHA256': {k: file_digest(PATHS[k]) for k in ['before', 'after', 'prospective', 'predeclared',
                                   'checks', 'test', 'test-exit', 'launch', 'completion']},
               'passes': child.returncode == 0 and not source_changed and not archive_changed and not invalid
                         and before['head'] == after['head'] and final_runtime_matches and integrity,
               'startedAtUnix': launched['startedAtUnix'], 'finishedAtUnix': completed['finishedAtUnix']}
    write_new(PATHS['verification'], summary)
    print(json.dumps(summary, indent=2))
    return 0 if summary['passes'] else 1


def detached(args):
    if not args.root_authorization or not args.expected_test_sha or args.expected_child_count is None:
        raise RuntimeError('Explicit ROOT authorization and expected hash/count required')
    for key in ['controller', 'background-launch']:
        if PATHS[key].exists():
            raise RuntimeError(f'Existing R8-new detached receipt, retain it: {PATHS[key]}')
    command = [sys.executable, str(SCRIPT), '--launch-authorized', '--root-authorization', args.root_authorization,
               '--expected-test-sha', args.expected_test_sha, '--expected-child-count', str(args.expected_child_count)]
    with PATHS['controller'].open('xb') as output:
        process = subprocess.Popen(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    record = {'startedAtUnix': time.time(), 'supervisorPID': process.pid, 'command': command,
              'outerTimeout': None, 'controllerLog': str(PATHS['controller'])}
    write_new(PATHS['background-launch'], record)
    print(json.dumps(record, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--prepare', action='store_true')
    action.add_argument('--launch-authorized', action='store_true')
    action.add_argument('--launch-detached-authorized', action='store_true')
    parser.add_argument('--root-authorization')
    parser.add_argument('--expected-test-sha')
    parser.add_argument('--expected-child-count', type=int)
    args = parser.parse_args()
    if args.prepare:
        prepare(); return 0
    if args.launch_detached_authorized:
        detached(args); return 0
    return run(args)


if __name__ == '__main__':
    sys.exit(main())
