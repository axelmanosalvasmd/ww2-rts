import {createAIcase} from './captured-lab.mjs';
const [sim,ai,perception,hands,view]=await Promise.all(['sim','ai','ai-perception','ai-hands','ai-view'].map(n=>import(`./source/shared/${n}.js`)));
const scene={units:[{owner:0,type:'rifle',x:78,z:79,holdFire:true,cooldown:60},{owner:0,type:'rifle',x:82,z:79,holdFire:true,cooldown:60},{owner:1,type:'mg',x:96,z:79,holdFire:true}],points:[{x:80,z:80,owner:0}],camera:{x:80,z:79,yaw:0},resources:[{mp:20,mun:200},{mp:0}],cues:[{kind:'hit',tick:160,unitId:7,damage:65}]};
const r=createAIcase({sim,ai,perception,hands,view},{scenario:'guard',level:'hard',seed:1,seconds:30,collectPolicy:true},scene).advance(600);
console.log(JSON.stringify({manual:r.policies.manual,alerts:r.policies.alerts},null,2));
