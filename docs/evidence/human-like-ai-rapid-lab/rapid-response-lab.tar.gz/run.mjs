import {mkdir,writeFile,readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createAIcase} from './captured-lab.mjs';
import {createAIcase as originalCase} from './source/tools/ai-lab-runner.mjs';
const [sim,ai,perception,hands,view]=await Promise.all(['sim','ai','ai-perception','ai-hands','ai-view'].map(n=>import(`./source/shared/${n}.js`)));
const engine={sim,ai,perception,hands,view},directory='/tmp/ai-lab-response-current/episodes';await mkdir(directory);
const results=[],isolation=[];
function sceneFor(kind,tick){
 const units=[{owner:0,type:'rifle',x:78,z:79,holdFire:true,cooldown:60},{owner:0,type:'rifle',x:82,z:79,holdFire:true,cooldown:60}];
 if(kind==='offscreen-hurt')units.push({owner:0,type:'rifle',x:180,z:180,holdFire:true,holdPos:true,autoRetreat:false,cooldown:60});
 units.push({owner:1,type:kind==='late-contact'||kind==='native-weapon'?'medium':'mg',x:kind==='late-contact'?184:96,z:kind==='late-contact'?184:79,holdFire:true});
 const victim=kind==='offscreen-hurt'?9:7,enemy=7+units.length-1;
 const cue=kind==='late-contact'?{kind:'contact',tick,unitId:enemy,x:96,z:79}:kind==='native-weapon'?{kind:'weapon-release',tick,unitId:enemy}:{kind:'hit',tick,unitId:victim,damage:65};
 return{units,points:[{x:80,z:80,owner:0}],camera:{x:80,z:79,yaw:0},resources:[{mp:20,mun:200},{mp:0}],cues:[cue]};
}
const digestRow=(r,key,kind,tick)=>{
 const m=r.policies.manual,a=r.policies.alerts;
 const rows=m.rows.map(row=>({creation:row.creation,decision:row.decision,reason:row.reason,manualUnits:row.manualUnits,coverage:row.coverage,answer:row.answer,
  firstSeconds:row.answer?.firstActionTick!=null?(row.answer.firstActionTick-row.creation.tick)/20:null,acceptedSeconds:row.answer?.acceptedCommandTick!=null?(row.answer.acceptedCommandTick-row.creation.tick)/20:null}));
 const ts=r.inputs.filter(i=>i.countsAPM!==false).map(i=>i.tick),gaps=ts.slice(1).map((t,i)=>(t-ts[i])/20);
 return {key,level:r.options.level,seed:r.options.seed,kind,authoredCueTick:tick,actualTicks:r.completedTicks,inputs:ts.length,cameraInputs:r.inputs.filter(i=>i.kind.startsWith('camera')).length,accepted:r.commands.filter(c=>c.accepted).length,
  rejected:r.commands.filter(c=>!c.accepted).map(c=>({tick:c.tick,t:c.command.t,reason:c.rejection})),physicalIntervals:gaps,
  manual:{evaluable:m.evaluable,creationEvents:m.creationEvents,requiredEvents:m.requiredEvents,monitoringEvents:m.monitoringEvents,unknownEvents:m.unknownEvents,firstCompletedAction:m.firstCompletedAction,acceptedCommand:m.acceptedCommand,audit:m.audit,rows},alerts:a};
};
for(const level of ['easy','normal','hard'])for(const seed of [1,2,3])for(const kind of ['onscreen-hurt','offscreen-hurt','late-contact','native-weapon'])for(const tick of kind==='native-weapon'?[240]:[160,240,400]){
 const scene=sceneFor(kind,tick),options={scenario:'guard',level,seed,seconds:30,collectPolicy:true};
 const lab=createAIcase(engine,options,scene),r=lab.advance(600),key=`${level}-${seed}-${kind}-${tick}`;
 assert.ok(r.policies.manual);assert.equal(r.policies.alerts.recorded,true,'Alert scoring must retain live provenance before serializing');
 r.authoredScene=scene;r.authorEnd=lab.authorView();r.measurementNotice='Author-controlled relocation and HP hits are explicit stimuli. weapon-release changes opponent holdFire; subsequent HP loss and shots come from actual simulation. This is an episode diagnostic, not campaign acceptance.';
 await writeFile(`${directory}/${key}.json`,JSON.stringify(r));results.push(digestRow(r,key,kind,tick));
 if(kind==='onscreen-hurt'&&tick===160){
  const plain=originalCase(engine,{...options,collectPolicy:false},scene),native=plain.advance(600);
  for(const field of ['events','inputStarts','inputs','commands','responses'])assert.deepEqual(r[field],native[field],`${key} ${field} observer isolation`);
  assert.deepEqual(lab.authorView(),plain.authorView());isolation.push({key,status:'PASS',fullNativeAndFinalState:true});
 }
 process.stderr.write(`${key} required${r.policies.manual.requiredEvents} censored${r.policies.manual.firstCompletedAction.censored}\n`);
}
const rich=JSON.parse(await readFile('/tmp/ai-lab-hard-throughput/scenes/two-front-budget.json','utf8'));
for(const seed of [1,2,3]){const options={scenario:'contact-threat',level:'hard',seed,seconds:60,collectPolicy:true},lab=createAIcase(engine,options,rich),r=lab.advance(1200),key=`hard-${seed}-rich-60s`;
 r.authoredScene=rich;r.authorEnd=lab.authorView();await writeFile(`${directory}/${key}.json`,JSON.stringify(r));results.push(digestRow(r,key,'rich',null));
 const plain=originalCase(engine,{...options,collectPolicy:false},rich),native=plain.advance(1200);for(const field of ['events','inputStarts','inputs','commands','responses'])assert.deepEqual(r[field],native[field]);assert.deepEqual(lab.authorView(),plain.authorView());isolation.push({key,status:'PASS',fullNativeAndFinalState:true});}
await writeFile('/tmp/ai-lab-response-current/summary.json',JSON.stringify({diagnosticOnly:true,episodes:results.length,isolation,results},null,2));
console.log(JSON.stringify({status:'PASS',episodes:results.length,isolationPairs:isolation.length,allNativeStreamsRetained:true,policies:['screen-manual-v3','public-danger-alert-v1']}));
