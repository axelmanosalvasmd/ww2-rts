import { UNITS } from './sim.js';
// Use actual observations and intended actors to order useful work within the current visit.
export function prioritizeVisit(intents, inspections, view, concern, answered, slot, tick) {
  const ids = cmd => cmd.ids ?? cmd.orders?.map(row => row[0]) ?? [];
  const near = (a, b, range) => Math.hypot(a.x - b.x, a.z - b.z) <= range;
  const point = cmd => cmd.orders?.length ? { x: cmd.orders.reduce((n, row) => n + row[1], 0) / cmd.orders.length,
    z: cmd.orders.reduce((n, row) => n + row[2], 0) / cmd.orders.length } : Number.isFinite(cmd.x) ? cmd : null;
  const movement = cmd => ['move', 'amove'].includes(cmd.t);
  const ready = unit => unit.owner === slot && view.screenIds.has(unit.id) && !UNITS[unit.type]?.structure && !unit.air && !unit.retreating
    && !unit.path.length && !unit.orders.length && !unit.targetId && !unit.attackId && !unit.amove
    && !unit.dig && !unit.build && !unit.nade && !unit.entrench && unit.enter < 0 && unit.fireAt < 0;
  const stimuli = (view.events ?? []).filter(event => ['screen-contact', 'screen-damage', 'base'].includes(event.kind)
    && !answered?.has(event.id) && event.tick <= tick && tick - event.tick <= 240);
  const serves = (cmd, event) => {
    const actors = ids(cmd).map(id => view.units.get(id)).filter(unit => unit?.owner === slot
      && unit.hp > 0 && view.screenIds.has(unit.id));
    const at = point(cmd);
    if (['buy', 'build', 'dig', 'entrench', 'recover', 'assist'].includes(cmd.t)) return false;
    let focus = event;
    if (event.kind === 'screen-contact') {
      const hostile = view.units.get(event.targetId);
      if (!hostile || hostile.hp <= 0 || !view.screenIds.has(hostile.id)
        || view.players[hostile.owner]?.team === view.players[slot].team) return false;
      focus = hostile;
      if (cmd.t !== 'support' && !actors.some(unit => ready(unit) && near(unit, hostile, 45))) return false;
    } else if (event.kind === 'screen-damage') {
      const damaged = view.units.get(event.unitId);
      if (!damaged || damaged.owner !== slot || damaged.hp <= 0 || !view.screenIds.has(damaged.id)) return false;
      focus = damaged;
      if (cmd.t !== 'support' && !actors.some(unit => unit.id === damaged.id)) return false;
    } else if (cmd.t !== 'support' && !actors.some(unit => near(unit, event, 48))) return false;
    if (cmd.t === 'support') return at && near(at, focus, 24);
    if (movement(cmd)) return at && near(at, focus, 24);
    if (cmd.t === 'attack') {
      const target = view.units.get(cmd.target);
      return target && target.hp > 0 && view.screenIds.has(target.id) && near(target, focus, 24)
        && actors.some(unit => near(unit, target, UNITS[unit.type]?.w?.range ?? 0));
    }
    if (cmd.t === 'ability' && at)
      return near(at, focus, 24) && actors.some(unit => near(unit, at, UNITS[unit.type]?.ab?.range ?? 0));
    return ['ability', 'retreat', 'cover', 'stop'].includes(cmd.t) && (!at || near(at, focus, 24));
  };
  const relevance = cmd => {
    const relevant = stimuli.filter(event => serves(cmd, event));
    const attended = relevant.find(event => event.id === concern?.eventId);
    if (attended) return { attended: 1, creation: attended.tick };
    if (concern?.kind === 'idle' && ids(cmd).includes(concern.unitId))
      return { attended: 1, creation: concern.since ?? tick };
    const at = point(cmd);
    if (concern?.kind === 'expansion' && movement(cmd) && at && near(at, concern, 24))
      return { attended: 1, creation: concern.since ?? tick };
    return { attended: 0, creation: Math.max(-1, ...relevant.map(event => event.tick)) };
  };
  const scores = new Map(intents.map(cmd => [cmd, relevance(cmd)]));
  intents.sort((a, b) => Number(b.t === 'retreat') - Number(a.t === 'retreat')
    || scores.get(b).attended - scores.get(a).attended || scores.get(b).creation - scores.get(a).creation);
  const useful = intents.filter(cmd => scores.get(cmd).creation >= 0);
  const readyActors = new Set(useful.flatMap(ids));
  return { intents, inspections: inspections.filter(cmd => !useful.length || ids(cmd).some(id => readyActors.has(id))) };
}
