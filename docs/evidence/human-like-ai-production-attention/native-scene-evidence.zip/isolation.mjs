import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createAIcase as original} from './original-lab-runner.mjs';
import {createAIcase as instrumented} from './instrumented-lab-runner.mjs';
const [sim,ai,perception,hands,view]=await Promise.all(['sim','ai','ai-perception','ai-hands','ai-view'].map(n=>import(`./source/shared/${n}.js`)));
const engine={sim,ai,perception,hands,view},random=Math.random;
await mkdir('/tmp/ai-lab-hard-throughput/scenes',{recursive:true});
for(const name of ['idle-budget','two-front-budget','late-hurt-budget','low-budget-guard']){
 const prior=JSON.parse(await readFile(`/tmp/ai-lab-hard-throughput/${name}.json`,'utf8'));
 const lab=original(engine,prior.options,prior.authoredScene),report=lab.advance(1200);
 const diagnosticLab=instrumented(engine,prior.options,prior.authoredScene),diagnostic=diagnosticLab.advance(1200);
 for(const key of ['events','inputStarts','inputs','commands','responses']){ assert.deepEqual(report[key],diagnostic[key],`${name} complete in-memory ${key} cannot change due to diagnostic copies`); assert.deepEqual(JSON.parse(JSON.stringify(report[key])),prior[key],`${name} stored ${key} agrees with native bytes`); }
 assert.deepEqual(lab.authorView(),diagnosticLab.authorView()); assert.deepEqual(lab.authorView(),prior.authorEnd);assert.equal(Math.random,random);
 await writeFile(`/tmp/ai-lab-hard-throughput/scenes/${name}.json`,JSON.stringify(prior.authoredScene,null,2));
}
console.log(JSON.stringify({status:'PASS',scenes:4,secondsEach:60,allNativeEventsStartsInputsCommandsResponsesAndFinalAuthorStateIdentical:true,MathRandomBindingRestored:true,diagnosticFieldsNeverFeedController:true}));
