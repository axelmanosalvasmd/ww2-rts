import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {createAIcase} from './instrumented-lab-runner.mjs';
const engines=[];
for(const dir of ['source','candidate']){const [sim,ai,perception,hands,view]=await Promise.all(['sim','ai','ai-perception','ai-hands','ai-view'].map(n=>import(`./${dir}/shared/${n}.js`)));engines.push({sim,ai,perception,hands,view});}
const guard={units:Array.from({length:4},(_,i)=>({owner:0,type:'rifle',x:76+(i%3)*5,z:77+Math.floor(i/3)*4,holdFire:true,autoRetreat:false,cooldown:60})),points:[{x:81,z:79,owner:0}],camera:{x:80,z:79,yaw:0},resources:[{mp:0,fuel:0,mun:200},{mp:0}],cues:[{kind:'hit',tick:160,unitId:8,damage:65}]};
guard.units.push({owner:1,type:'mg',x:103,z:79,holdFire:true,autoRetreat:false});
const cases=[['initial-empty-home',guard],['affordable-production',{...structuredClone(guard),resources:[{mp:10000,fuel:1000,mun:200},{mp:0}]}],['home-squad-deployment',{...structuredClone(guard),camera:{x:41,z:41,yaw:0},points:[{x:81,z:79,owner:-1}],units:guard.units.map(u=>u.owner===0?{...u,x:u.x-36,z:u.z-38}:u)}]];
const summaries=[];
for(const [name,scene] of cases){
 const rows=engines.map(engine=>createAIcase(engine,{scenario:'guard',level:'hard',seed:42,seconds:15},scene).advance(300));
 for(const [index,r] of rows.entries())await writeFile(`/tmp/ai-lab-hard-throughput/control-${name}-${index?'candidate':'baseline'}.json`,JSON.stringify(r));
 if(name==='home-squad-deployment')assert.ok(rows[0].commands.some(c=>c.accepted&&['move','amove'].includes(c.command.t)),'home comparison has actual useful deployment');
 if(name!=='initial-empty-home'){assert.deepEqual(rows[1].inputs,rows[0].inputs,`${name} native inputs unchanged`);assert.deepEqual(rows[1].commands,rows[0].commands,`${name} native commands unchanged`);}
 else{assert.ok(rows[0].inputs.some(i=>i.kind.startsWith('camera')&&i.concern==='production'&&i.tick<160));assert.ok(!rows[1].inputs.some(i=>i.kind.startsWith('camera')&&i.concern==='production'&&i.tick<160),'no unaffordable home camera visit');assert.ok(rows[1].commands.some(c=>c.accepted&&c.command.t==='retreat'&&c.tick>=160),'real native retreat remains useful');}
 summaries.push({name,baseline:{inputs:rows[0].inputs.length,cameras:rows[0].inputs.filter(i=>i.kind.startsWith('camera')).map(i=>({tick:i.tick,concern:i.concern})),responses:rows[0].responses.filter(r=>r.creationTick>=160),commands:rows[0].commands.map(c=>({tick:c.tick,t:c.command.t,accepted:c.accepted,ids:c.command.ids}))},candidate:{inputs:rows[1].inputs.length,cameras:rows[1].inputs.filter(i=>i.kind.startsWith('camera')).map(i=>({tick:i.tick,concern:i.concern})),responses:rows[1].responses.filter(r=>r.creationTick>=160),commands:rows[1].commands.map(c=>({tick:c.tick,t:c.command.t,accepted:c.accepted,ids:c.command.ids}))}});
}
await writeFile('/tmp/ai-lab-hard-throughput/controls-summary.json',JSON.stringify({status:'PASS',summaries},null,2));console.log(JSON.stringify({status:'PASS',nativePairs:3,positiveHomeVisitSuppression:true,affordableAndDeploymentInputsCommandsIdentical:true}));
