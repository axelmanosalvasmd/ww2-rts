import {writeFile} from 'node:fs/promises';
import {createAIcase} from './instrumented-lab-runner.mjs';
const names=['sim','ai','ai-perception','ai-hands','ai-view'];
const [sim,ai,perception,hands,view]=await Promise.all(names.map(name=>import(`./candidate/shared/${name}.js`)));
const engine={sim,ai,perception,hands,view};
const rifle=(x,z,extra={})=>({owner:0,type:'rifle',x,z,...extra});
const points=[{x:110,z:82,owner:-1},{x:136,z:114,owner:-1},{x:78,z:130,owner:-1}];
const quiet={units:[rifle(72,75),rifle(77,77),rifle(83,81),rifle(88,85),{owner:1,type:'rifle',x:184,z:184,holdFire:true}],points,camera:{x:85,z:85,yaw:0},resources:[{mp:900,fuel:300,mun:120},{mp:0}]};
const twoFront={units:[rifle(69,75),rifle(74,78),rifle(82,84),rifle(114,110),rifle(119,112),rifle(126,116),{owner:1,type:'mg',x:98,z:80,holdFire:true},{owner:1,type:'mg',x:150,z:114,holdFire:true}],points,camera:{x:95,z:91,yaw:0},resources:[{mp:900,fuel:300,mun:120},{mp:0}]};
const scenes=[['idle-budget',quiet],['two-front-budget',twoFront],['late-hurt-budget',{...structuredClone(twoFront),cues:[]}],['low-budget-guard',{units:[rifle(78,79,{holdFire:true,cooldown:20}),rifle(82,79,{holdFire:true,cooldown:20}),rifle(80,82,{holdFire:true,cooldown:20}),rifle(84,82,{holdFire:true,cooldown:20}),{owner:1,type:'mg',x:96,z:79,holdFire:true}],points:[{x:80,z:80,owner:0}],camera:{x:80,z:79,yaw:0},resources:[{mp:20,fuel:10,mun:0},{mp:0}],cues:[]}]];
const summary=[];
for(const [name,scene] of scenes){
 const options={scenario:name==='low-budget-guard'?'guard':'contact-threat',level:'hard',seed:42,seconds:60};
 if(name==='late-hurt-budget'||name==='low-budget-guard'){
  const init=createAIcase(engine,options,scene);const own=init.authorView().units.filter(u=>u.owner===0);
  scene.cues=[{kind:'hit',tick:600,unitId:own[name==='late-hurt-budget'?4:0].id,damage:30}];
 }
 const lab=createAIcase(engine,options,scene),start=lab.authorView(),report=lab.advance(1200),end=lab.authorView();
 report.authoredScene=scene;report.authorStart=start;report.authorEnd=end;
 await writeFile(`/tmp/ai-lab-hard-throughput/candidate-${name}.json`,JSON.stringify(report));
 const accepted=report.commands.filter(r=>r.accepted),buys=accepted.filter(r=>r.command.t==='buy'),nonbuys=accepted.filter(r=>r.command.t!=='buy');
 const idleFrames=report.frames.filter(f=>!f.active&&f.queued===0&&f.tick>f.planning.openingUntil);
 const states={};for(const frame of idleFrames){const p=frame.planning,kind=frame.tick<p.noWorkUntil?'no-work-backoff':frame.tick<p.deliberateUntil?'deliberation':'hands-empty-ready';states[kind]=(states[kind]??0)+.1;}
 const camera=report.inputs.filter(r=>r.kind.startsWith('camera'));
 const concerned={};for(const f of report.frames){const k=f.concern?.kind??'none';concerned[k]=(concerned[k]??0)+.1;}
 summary.push({name,seconds:report.completedTicks/20,inputs:report.inputs.length,cameraInputs:camera.length,accepted:accepted.length,rejected:report.commands.filter(r=>!r.accepted).map(r=>({tick:r.tick,command:r.command,reason:r.rejection})),buys:buys.map(r=>({tick:r.tick,unit:r.command.unit})),nonbuys:nonbuys.map(r=>({tick:r.tick,t:r.command.t,ids:r.command.ids??r.command.orders?.map(x=>x[0]),concern:r.context?.concern})),mpStart:start.resources[0].mp,mpEnd:end.resources[0].mp,concernSeconds:concerned,handsEmptyAfterOpeningSeconds:states,firstOrderTick:nonbuys[0]?.tick??null,firstBuyTick:buys[0]?.tick??null});
}
await writeFile('/tmp/ai-lab-hard-throughput/candidate-summary.json',JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary,null,2));
