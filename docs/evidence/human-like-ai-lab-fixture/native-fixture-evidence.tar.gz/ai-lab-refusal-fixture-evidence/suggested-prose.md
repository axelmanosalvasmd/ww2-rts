# Suggested CHANGELOG bullet

- The AI lab checks a genuine refused paid order beside a wall. Its privacy witness uses reachable trench cover, and its scene-edit check follows the unit's actual simulated position.

# Suggested DESIGN paragraph

The lab refusal proof uses a watched concrete wall without a seen or recent threat direction. The commander pays for selection and Take Cover; native coverSpot finds no improving destination and returns noCover. Recorded gesture starts, full motor time and the refused receipt remain required. The camera-tier privacy witness instead gives the watched guard a free trench, requiring an accepted operation before inspecting the distant enemy. Caller-edit isolation compares the current simulated position before and after the external graph edit, allowing normal automatic movement.

# Suggested spec verification addition

The V19 failure remains recorded. The corrected lab fixture preserves the native refusal requirement with a real paid wall-cover attempt, keeps all fog/camera counterfactuals and strengthens pre-inspection activity to an accepted native operation. ROOT's adopted test exits 0 in 2.8377 seconds. The diagnostic trace and focused test qualify their recorded sources; they do not replace a fresh full-suite result or population acceptance.
