import {runAiLab} from '/home/judiazm/.t3/worktrees/ww2-rts/ai-human-commander/tools/ai-lab-node.mjs';
import {writeFile} from 'node:fs/promises';
const root='/home/judiazm/.t3/worktrees/ww2-rts/ai-human-commander';
const rows=Array.from({length:96},()=>Array(96).fill('.'));rows[40][41]='K';
const scene={rows:rows.map(row=>row.join('')),units:[{owner:0,type:'mg',x:78,z:79,holdFire:true},{owner:1,type:'mg',x:168,z:168,holdFire:true}],points:[{x:80,z:80,owner:0}],camera:{x:80,z:79,yaw:0},resources:[{mp:0,fuel:0,mun:0},{mp:0,fuel:0,mun:0}]};
const report=await runAiLab({root,level:'hard',seed:42,seconds:8,scenario:'guard',scene});
await writeFile('/tmp/ai-lab-refusal-fixture/native.json',JSON.stringify({scene,report}));
console.log(report.commands.map(row=>({tick:row.tick,accepted:row.accepted,rejection:row.rejection,command:row.command}))); console.log('inputs',report.inputs.map(row=>[row.tick,row.kind,row.motorTicks,row.command]));
