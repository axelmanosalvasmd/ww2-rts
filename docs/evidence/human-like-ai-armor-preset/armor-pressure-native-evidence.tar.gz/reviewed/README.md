# Built-in armor-pressure proposal

The proposed preset makes the ordinary weak-fire armor problem available from the existing sandbox scene selector. It adds no UI layout or styling. The dynamic scenario list already supplies the selector. Choose armor-pressure, seed 1, a difficulty and advance 30 simulated seconds.

The map, owned objective, camera and 20 MP treasury match the recorded ordinary native scene. Both rifles retain native firing and ability cooldown defaults. The medium initially holds fire, then an authored weapon-release cue issues its ordinary stance command at tick 240. No HP is subtracted, cooldown changed or hurt event fabricated. Actual projectile simulation produces the heavy public hit at 244. All orders still use the default human commander, timed hands and authoritative command validation.

The new cue kind is also supported for custom authored cases. It identifies an existing actual unit and changes only holdFire through command(). Existing hit/hurt-cue behavior and validation remain intact. This tool-owned opponent scheduling is labeled in authorEdits and never counted as an AI physical input.

The full existing test-ai-lab.js suite passes, preserving every previous assertion. Added assertions verify the real projectile hit, ordinary native firing, actual accepted retreat, paid selection/R motors and causal floor. Incremental browser stepping compares complete events, input starts, inputs and commands with the CLI trace. Final PASS elapsed 3126.5ms on the bounded local run.

All three difficulties run the preset through the real CLI for 30 seconds at seed 1. Native hit 244 is the same. First physical/accepted retreat ticks are Easy 268/272, Normal 259/262 and Hard 252/255. Both motor endpoints remain recorded. These individual diagnostic values do not establish reaction gate acceptance or alter existing limits. Whole JSON and standalone HTML reports remain under each difficulty directory.

Runtime AI source stays bc677b3d7b2771941e6242f9c598084f04710dad944bdc54db24ef93ac354457. The exact patch is integration.patch, SHA 6db8b6d6ec7255cb6c1cf927f75c849e650af824aca1decd8c3b176d5547fa4e. It changes only tools/ai-lab-runner.mjs, tools/ai-lab.mjs, docs/ai-lab.md and the existing test-ai-lab.js. source-manifest.json binds each base/candidate file. No ROOT files were edited.

After adoption:

```sh
node tools/ai-lab.mjs --serve
node tools/ai-lab.mjs --scenario armor-pressure --level hard --seed 1 --seconds 30 --out /tmp/ai-armor-pressure
```

In the browser, open http://127.0.0.1:3048/tools/ai-lab.html, select armor-pressure, set seed 1 and advance the scene. A developer can use the same current tool with --root pointing at the preserved older AI source to inspect the original omission. No scene JSON is required.

Before adoption, use the scratch CLI:

```sh
node /tmp/ai-lab-armor-preset/candidate/tools/ai-lab.mjs --scenario armor-pressure --level hard --seed 1 --seconds 30 --out /tmp/ai-armor-pressure
node /tmp/ai-lab-armor-preset/candidate/test-ai-lab.js
```

CLI bounds remain 1 through 60 simulated seconds; interactive bounds remain 600 seconds and 48 authored units. No full matches, campaigns or full repository suite were launched.
