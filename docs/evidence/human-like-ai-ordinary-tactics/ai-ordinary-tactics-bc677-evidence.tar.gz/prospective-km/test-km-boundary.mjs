import assert from 'node:assert/strict';
import { readFileSync,writeFileSync,readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { kaplanMeier as candidate } from './tools/ai-humanity.mjs';
import { publicAlertKM as alert } from './tools/ai-public-alert-response.mjs';
import { exactHalfBoundary,KM_MEDIAN_BOUNDARY_VERSION } from './tools/km-median-boundary.mjs';
const root='/home/judiazm/.t3/worktrees/ww2-rts/ai-human-commander';
const {kaplanMeier:baseline}=await import(`${root}/tools/ai-humanity.mjs`),{publicAlertKM:oldAlert}=await import(`${root}/tools/ai-public-alert-response.mjs`);
const dir='/tmp/ai-ordinary-tactics-bc677', cases=[];let controls=0;
const sample=(seconds,observed=true)=>({seconds,observed});
for(const [label,rows,median] of[
 ['even exact half',[sample(1),sample(2),sample(3),sample(4)],2],
 ['mixed censors',[sample(0,false),sample(1),sample(2),sample(2,false),sample(3),sample(4,false)],3],
 ['completion before tied censor',[sample(1),sample(1,false),sample(2),sample(3,false)],2],
 ['all censored',[sample(1,false),sample(2,false)],null],
 ['all completed',[sample(1),sample(1),sample(1)],1],
 ['empty',[],null]]){
 for(const fn of[candidate,alert]){const scored=fn(rows);assert.equal(scored.medianSeconds,median,label);assert.deepEqual(fn([...rows].reverse()),scored,label+' permutation');controls+=2;}
}
const big=2**51;
for(const [risk,observed,expected] of[[big+1,big/2,false],[big-1,big/2,true],[big,big/2,true]]){
 const numeric=1-observed/risk;assert.equal(exactHalfBoundary()(numeric,risk,observed),expected,'exact neighboring rational crossing');controls++;
}
// Exact products are evaluated only at the ambiguous candidate, then extended without rescanning.
const again=exactHalfBoundary();assert.equal(again(.5, big+1,big/2),false);assert.equal(again(.5,big/2+1,1),true);controls+=2;
const full=[];
for(const name of readdirSync(dir).filter(n=>/^(assault|support|safehold|twofront)-(easy|normal|hard)-[123]\.json$/.test(n))){const raw=JSON.parse(readFileSync(`${dir}/${name}`));full.push(raw);}
assert.equal(full.length,36);
const diagnostic=JSON.parse(readFileSync(`${dir}/diagnostic-timing.json`));
const expand=curve=>curve.flatMap(row=>[...Array.from({length:row.observed},()=>sample(row.seconds)),...Array.from({length:row.censored},()=>sample(row.seconds,false))]);
for(const original of diagnostic.table){const row={level:original.level};for(const key of['manual','acceptedCommand','alert']){if(!original[key])continue;const rows=expand(original[key].curve),old=baseline(rows),now=candidate(rows),oa=oldAlert(rows),na=alert(rows);assert.deepEqual(now.curve,old.curve,'original displayed curve unchanged');assert.deepEqual(na.curve,oa.curve,'public unrounded curve unchanged');assert.deepEqual(rows,expand(original[key].curve));assert.deepEqual(candidate([...rows].reverse()),now);assert.deepEqual(alert([...rows].reverse()),na);row[key]={samples:rows,beforeMedian:old.medianSeconds,afterMedian:now.medianSeconds,beforePublicMedian:oa.medianSeconds,afterPublicMedian:na.medianSeconds,curve:now.curve,publicCurve:na.curve};controls+=5;}cases.push(row);}
const nativeRows=[];
for(const level of ['easy','normal','hard']) {
 const episodes=full.filter(raw=>raw.level===level),first=[],accepted=[];
 for(const episode of episodes) for(const row of episode.manualScore.rows.filter(row=>row.decision==='required')) {
  const input=row.answer?.firstActionTick??null,command=row.answer?.acceptedCommandTick??null;
  if(command!==null) assert.ok(input!==null && command>=input,'actual accepted command never precedes its physical input');
  const end=episode.seconds*20;
  first.push(sample(((input??end)-row.creation.tick)/20,input!==null));
  accepted.push(sample(((command??end)-row.creation.tick)/20,command!==null));
  nativeRows.push({scene:episode.sceneName,level,seed:episode.seed,creation:row.creation,answer:row.answer});
 }
 const expected=cases.find(row=>row.level===level);
 assert.deepEqual(candidate(first),candidate(expected.manual.samples),'full native first-input samples match retained diagnostic curves');
 assert.deepEqual(candidate(accepted),candidate(expected.acceptedCommand.samples),'full native command samples match retained diagnostic curves');
 assert.ok(candidate(accepted).medianSeconds>=candidate(first).medianSeconds,'actual native KM medians respect per-event command ordering');controls+=3;
}
const easy=cases.find(c=>c.level==='easy');assert.equal(easy.manual.beforeMedian,4.15);assert.equal(easy.manual.afterMedian,1.65);assert.ok(easy.acceptedCommand.afterMedian>=easy.manual.afterMedian);controls+=3;
const hist=readFileSync(`${dir}/diagnostic-timing.json`);const start=performance.now();const large=Array.from({length:100000},(_,i)=>sample(i));const l=candidate(large);assert.equal(l.medianSeconds,49999);controls++;
writeFileSync('/tmp/human-ai-km-exact-half-proof.json',JSON.stringify({version:KM_MEDIAN_BOUNDARY_VERSION,diagnosticOnly:true,controls,cases,nativeRows,large:{samples:large.length,median:l.medianSeconds,ms:performance.now()-start},historicalDiagnosticSHA256:createHash('sha256').update(hist).digest('hex'),historicalDiagnosticUnchanged:true},null,2)+'\n');
console.log('PASS',controls,KM_MEDIAN_BOUNDARY_VERSION);
