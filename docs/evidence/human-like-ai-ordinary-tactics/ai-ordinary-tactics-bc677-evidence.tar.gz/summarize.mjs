import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {kaplanMeier} from '/home/judiazm/.t3/worktrees/ww2-rts/ai-human-commander/tools/ai-humanity.mjs';
const dir='/tmp/ai-ordinary-tactics-bc677';
const files=(await readdir(dir)).filter(f=>/^(assault|support|twofront|safehold)-(easy|normal|hard)-[123]\.json$/.test(f));
assert.equal(files.length,36);
const cases=await Promise.all(files.map(async file=>JSON.parse(await readFile(`${dir}/${file}`))));
const table=[];
for(const level of ['easy','normal','hard']){
 const own=cases.filter(r=>r.level===level),first=[],accepted=[],alerts=[];
 for(const r of own){
  for(const row of r.manualScore.rows.filter(row=>row.decision==='required')){
   const elapsed=t=>({seconds:((t??r.report.completedTicks)-row.creation.tick)/20,observed:t!=null});
   first.push(elapsed(row.answer?.firstActionTick));accepted.push(elapsed(row.answer?.acceptedCommandTick));
  }
  alerts.push(...r.alertScore.samples);
 }
 table.push({level,episodes:own.length,manual:kaplanMeier(first),acceptedCommand:kaplanMeier(accepted),alert:kaplanMeier(alerts),manualEventlessEpisodes:own.filter(r=>r.manualScore.requiredEvents===0).length,alertEventlessEpisodes:own.filter(r=>r.alertScore.requiredEvents===0).length});
}
for(const r of cases){
 assert.equal(r.report.completedTicks,r.sceneName==='twofront'?1200:600);
 assert.equal(r.manualScore.unknownEvents,0);assert.equal(r.alertScore.evaluable,true);
 for(const id of r.report.fixture.ownIds)assert.ok(r.authoritativeEnd.units.some(u=>u.id===id&&u.hp>0));
 if(r.sceneName==='safehold'){
  const guard=r.authoritativeEnd.units.find(u=>u.id===7);assert.deepEqual([guard.x,guard.z,guard.hp],[77,81,75]);
  assert.ok(r.authoritativeEnd.units.find(u=>u.id===8).hp<100);
  assert.equal(r.authorFrames.at(-1).points[0].owner,0);
 }
 if(r.sceneName==='twofront'){
  assert.ok(r.authorFrames.at(-1).points.every(p=>p.owner===0&&!p.contested));
  assert.ok(r.log.commands.some(c=>c.accepted&&c.command.t==='buy'));
 }
}
const hashes=Object.fromEntries(await Promise.all(files.map(async file=>[file,createHash('sha256').update(await readFile(`${dir}/${file}`)).digest('hex')])));
await writeFile(`${dir}/diagnostic-timing.json`,JSON.stringify({diagnosticOnly:true,originalLimitsUnchanged:true,caseCount:36,table},null,2));
await writeFile(`${dir}/raw-manifest.json`,JSON.stringify(hashes,null,2));
console.log(JSON.stringify(table.map(r=>({level:r.level,episodes:r.episodes,manual:{n:r.manual.samples,censored:r.manual.censored,median:r.manual.medianSeconds},accepted:{n:r.acceptedCommand.samples,censored:r.acceptedCommand.censored,median:r.acceptedCommand.medianSeconds},alerts:{n:r.alert.samples,censored:r.alert.censored,median:r.alert.medianSeconds},manualEventless:r.manualEventlessEpisodes,alertEventless:r.alertEventlessEpisodes})),null,2));
