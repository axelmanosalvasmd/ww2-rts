import assert from 'node:assert/strict';
import {writeFile,readFile}from'node:fs/promises';
import{createHash}from'node:crypto';
import * as sim from './source/shared/sim.js';
import * as ai from './source/shared/ai.js';
import * as perception from './source/shared/ai-perception.js';
import * as hands from './source/shared/ai-hands.js';
import * as view from './source/shared/ai-view.js';
import {bindings}from'./source/client/keys.js';
import {createAIcase}from'./source/tools/ai-lab-runner.mjs';
import {createManualCapture}from'./source/tools/ai-manual-response-capture-v3.mjs';
import * as alert from './source/tools/ai-public-alert-response.mjs';
import {kaplanMeier}from'./source/tools/ai-humanity.mjs';
const dir='/tmp/ai-ordinary-tactics-bc677',root='/home/judiazm/.t3/worktrees/ww2-rts/ai-human-commander';
const troop=(type,x,z,owner=0,extra={})=>({owner,type,x,z,holdFire:false,...extra});
const rows=Array(96).fill('.'.repeat(96));rows[40]=rows[40].slice(0,38)+'T'+rows[40].slice(39);
const scenes={
 assault:{seconds:30,scene:{units:[troop('rifle',74,78),troop('rifle',77,81),troop('rifle',73,84),troop('mg',70,81),troop('rifle',107,80,1),troop('mg',109,84,1)],points:[{x:110,z:80,owner:-1}],camera:{x:88,z:81},resources:[{mp:0,fuel:0,mun:200},{mp:0,fuel:0,mun:0}]}},
 support:{seconds:30,scene:{units:[troop('rifle',79,78),troop('rifle',80,82),troop('mg',76,80),troop('mg',105,77,1),troop('mg',105,81,1),troop('rifle',105,84,1)],camera:{x:89,z:80},resources:[{mp:650,fuel:0,mun:200},{mp:0,fuel:0,mun:0}]}},
 twofront:{seconds:60,initialOrders:[{owner:0,command:{t:'amove',orders:[[7,96,70],[8,96,72],[9,96,68]],together:true}},{owner:1,command:{t:'amove',orders:[[14,148,139]],together:true}}],scene:{units:[troop('rifle',70,70),troop('rifle',73,72),troop('rifle',72,68),troop('rifle',42,41),troop('rifle',45,41),troop('mg',151,139),troop('mg',98,70,1),troop('rifle',160,117,1)],points:[{x:109,z:70,owner:1},{x:151,z:139,owner:0}],camera:{x:80,z:70},resources:[{mp:650,fuel:0,mun:200},{mp:0,fuel:0,mun:0}]}},
 safehold:{seconds:30,scene:{rows,units:[troop('mg',77,81,0,{holdPos:true}),troop('rifle',112,81,1)],points:[{x:77,z:81,owner:0}],camera:{x:92,z:80},resources:[{mp:0,fuel:0,mun:200},{mp:0,fuel:0,mun:0}]}}
};
const files=['shared/ai.js','shared/ai-commander.js','shared/ai-attention.js','shared/ai-hands.js','shared/ai-perception.js','shared/sim.js','tools/ai-manual-response-policy-v3.mjs','tools/ai-manual-response-capture-v3.mjs','tools/ai-public-alert-response.mjs','tools/ai-lab-runner.mjs'];
const hashes=async()=>Object.fromEntries(await Promise.all(files.map(async f=>[f,createHash('sha256').update(await readFile(`${root}/${f}`)).digest('hex')])));const before=await hashes();assert.equal(before['shared/ai.js'],'bc677b3d7b2771941e6242f9c598084f04710dad944bdc54db24ef93ac354457');
export async function run(name,level,seed,measured=true){
 const {scene,seconds,initialOrders=[]}=scenes[name],log={events:[],inputs:[],commands:[],physicalInputsRecorded:true},authorOrders=[],publicDiagnostics=[],authorFrames=[];let capture,alerts,lastGame;
 const engineSim={...sim,step(game){if(game.tick===0)for(const row of initialOrders){const receipt=sim.command(game,row.owner,row.command);authorOrders.push({tick:0,authoredBeforeRun:true,owner:row.owner,command:structuredClone(row.command),accepted:receipt===undefined,rejection:receipt??null});assert.equal(receipt,undefined,'initial authored native order is legal');}return sim.step(game);}};
 const engineAI={...ai,think(game,slot,opts){lastGame=game;if(measured&&!capture){capture=createManualCapture({slot,log,memory:opts.memory,rules:{...sim,bindings},perceive:perception.perceive,observer:{measureRaw:()=>null,onMeasurements:()=>{}}});alerts=alert.createPublicAlertCapture({slot,log,memory:opts.memory,startedTick:0});}
 ai.think(game,slot,{...opts,...(measured?{perceptionMeasurements:alerts.wrapMeasurements(capture.perceptionMeasurements)}:{}),inputLog:input=>{opts.inputLog(input);log.inputs.push(structuredClone(input));if(measured){capture.input(log.inputs.at(-1),log.inputs.length-1);alerts.input(log.inputs.at(-1),log.inputs.length-1);}},submit:command=>{const p=game.players[slot],before={mp:p.mp,mun:p.mun,fuel:p.fuel},result=opts.submit(command);log.commands.push({tick:game.tick,command:structuredClone(command),accepted:result===undefined,rejection:result??null,resourcesBefore:before,resourcesAfter:{mp:p.mp,mun:p.mun,fuel:p.fuel}});return result;}});
 for(const event of opts.memory.human.events??[])if(!log.events.some(row=>row.id===event.id))log.events.push(structuredClone(event));if(measured){capture.afterThink(game.tick);alerts.afterThink(game.tick);}
 if(game.tick%10===0){const h=opts.memory.human;publicDiagnostics.push({tick:game.tick,concern:structuredClone(h.concern),operation:structuredClone(opts.memory.mind?.operation),pendingInspection:structuredClone(h.pendingInspection),noWorkUntil:h.noWorkUntil,emptyCombatVisits:structuredClone(h.emptyCombatVisits),production:structuredClone(h.production),queue:h.hands.queue.map(j=>({command:structuredClone(j.command),queuedTick:j.queuedTick,context:structuredClone(j.context)}))});authorFrames.push({tick:game.tick,authoritativeProofOnly:true,points:game.points.map(p=>({x:p.x,z:p.z,owner:p.owner,contested:p.contested})),units:[...game.units.values()].map(u=>({id:u.id,type:u.type,owner:u.owner,x:u.x,z:u.z,hp:u.hp,targetId:u.targetId,path:u.path.length,retreating:u.retreating,orders:u.orders.length,amove:structuredClone(u.amove),dig:!!u.dig,holdPos:u.holdPos,cd:u.cd})),resources:game.players.map(p=>({mp:p.mp,mun:p.mun,fuel:p.fuel}))});}
 }};
 const c=createAIcase({sim:engineSim,ai:engineAI,perception,hands,view},{scenario:name==='safehold'?'hold':'contact-threat',level,seed,seconds},scene);c.advance(1);let report;for(let left=Math.round(seconds*20)-1;left>0;left-=Math.min(left,200))report=c.advance(Math.min(left,200));
 let manualScore,alertScore;if(measured){alerts.finish(lastGame.tick);manualScore=capture.policy.scoreManualResponses(log,lastGame.tick/20,kaplanMeier);alertScore=alert.scorePublicAlerts(log);}
 return{sceneName:name,level,seed,seconds:report.completedTicks/20,report,authoritativeEnd:c.authorView(),authorOrders,publicDiagnostics,authorFrames,...(measured?{log,manualScore,alertScore}:{})};
}
