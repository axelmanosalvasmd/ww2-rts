import pathlib,tarfile,gzip,hashlib,json
p=pathlib.Path('/tmp/ai-ordinary-tactics-bc677');dest=pathlib.Path('/tmp/ai-ordinary-tactics-bc677-evidence.tar.gz')
with dest.open('wb') as out,gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for f in sorted(p.rglob('*')):
  if not f.is_file():continue
  info=tar.gettarinfo(str(f),arcname=str(f.relative_to(p)));info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644
  with f.open('rb') as data:tar.addfile(info,data)
manifest=json.loads((p/'file-manifest.json').read_text());expected={e['path']:e for e in manifest['entries']};mb=(p/'file-manifest.json').read_bytes();expected['file-manifest.json']={'bytes':len(mb),'sha256':hashlib.sha256(mb).hexdigest()}
with tarfile.open(dest,'r:gz') as tar:
 members={m.name:m for m in tar.getmembers() if m.isfile()};assert set(members)==set(expected)
 for name,want in expected.items():
  data=tar.extractfile(members[name]).read();assert len(data)==want['bytes'];assert hashlib.sha256(data).hexdigest()==want['sha256']
report={'archive':str(dest),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'manifestSHA256':expected['file-manifest.json']['sha256'],'memberCount':len(expected),'memberByteHashReadback':True,'originalRawFileCount':36,'observerControlCount':4,'originalRawHashesVerified':True,'historyUnmodified':True}
pathlib.Path('/tmp/ai-ordinary-tactics-bc677-evidence-archive.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
