import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {run} from './episode-library.mjs';
const dir='/tmp/ai-ordinary-tactics-bc677';
await mkdir(`${dir}/observer-controls`,{recursive:true});
const rows=[];
for(const name of ['assault','support','twofront','safehold']){
 const original=JSON.parse(await readFile(`${dir}/${name}-hard-1.json`));
 const plain=await run(name,'hard',1,false);
 const keys=['report','authoritativeEnd','authorOrders','publicDiagnostics','authorFrames'];
 const project=r=>Object.fromEntries(keys.map(k=>[k,r[k]]));
 // JSON comparison matches the retained raw representation of Map diagnostics.
 assert.deepEqual(JSON.parse(JSON.stringify(project(plain))),project(original));
 const bytes=JSON.stringify(plain);
 await writeFile(`${dir}/observer-controls/${name}-hard-1-capture-off.json`,bytes);
 rows.push({scene:name,level:'hard',seed:1,completedTicks:plain.report.completedTicks,nativeEquality:true,comparedKeys:keys,bytes:Buffer.byteLength(bytes),sha256:createHash('sha256').update(bytes).digest('hex'),originalControlStatus:'Original capture-off native assertion passed during first stage. This separately retained exact seeded control was reproduced later, without replacing its capture-on file.'});
}
await writeFile(`${dir}/observer-controls/receipts.json`,JSON.stringify(rows,null,2));
console.log('PASS four native capture-off controls equal unchanged historical capture-on traces');
