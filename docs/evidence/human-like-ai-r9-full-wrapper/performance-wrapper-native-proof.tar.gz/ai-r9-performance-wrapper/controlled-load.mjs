import { spawn } from 'node:child_process';
const load=spawn('taskset',['-c','4','nice','-n','10',process.execPath,'-e',"const end=Date.now()+75000;let n=0;while(Date.now()<end)n=Math.imul(n+1,1664525);console.log(n);"],{stdio:'ignore'});
const test=spawn('taskset',['-c','4','nice','-n','19','/usr/bin/time','-v',process.execPath,'test-corpse-performance.mjs'],{cwd:process.argv[2],stdio:'inherit'});
const started=Date.now();
const code=await new Promise(r=>test.once('exit',(c,s)=>r({code:c,signal:s})));
await new Promise(r=>load.exitCode===null?load.once('exit',r):r());
console.log(JSON.stringify({controlledLoadSeconds:75,elapsedSeconds:(Date.now()-started)/1000,...code}));
process.exitCode=code.code??1;
