from pathlib import Path
import subprocess,time,json,hashlib
base=Path('/tmp/ai-r8-diagonal-pan'); results=[]
for name in ['test-engine-ai-hands.js','test-engine-ai-response.js','test-engine-ai-public-alert.js','test-engine-ai-diagonal-pan.js']:
 t=time.monotonic()
 with (base/(name+'.log')).open('w') as out:
  run=subprocess.run(['taskset','-c','3','nice','-n','19','node',str(base/'source'/name)],stdout=out,stderr=subprocess.STDOUT)
 results.append({'test':name,'exitCode':run.returncode,'elapsedMs':round((time.monotonic()-t)*1000,3),'logSHA256':hashlib.sha256((base/(name+'.log')).read_bytes()).hexdigest()})
 print(json.dumps(results[-1]),flush=True)
(base/'checks.json').write_text(json.dumps({'diagnosticOnly':True,'checks':results},indent=2)+'\n')
raise SystemExit(any(r['exitCode'] for r in results))
