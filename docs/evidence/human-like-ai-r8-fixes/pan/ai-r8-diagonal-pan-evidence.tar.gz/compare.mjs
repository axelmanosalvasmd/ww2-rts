import { scenes, nativePan } from './source/test-engine-ai-diagonal-pan.js';
import * as baseline from '/tmp/human-ai-v21-final-full-source/shared/ai-hands.js';
import * as candidate from './source/shared/ai-hands.js';
import { writeFile } from 'node:fs/promises';
const baselineResults = scenes.map(scene => nativePan(baseline, scene, false));
const prospectiveResults = scenes.map(scene => nativePan(candidate, scene));
await writeFile(new URL('./comparison-native.json', import.meta.url), JSON.stringify({ diagnosticOnly: true,
  scenesPredeclaredIn: 'source/test-engine-ai-diagonal-pan.js', seed: 27, durationSecondsPerScene: 8,
  baselineSource: '/tmp/human-ai-v21-final-full-source', baseline: baselineResults, prospective: prospectiveResults }, null, 2));
console.log(JSON.stringify({ scenes: scenes.length, baselineDiagonal: baselineResults[1].final,
  candidateDiagonal: prospectiveResults[1].final, baselineInputs: baselineResults[1].inputs.length,
  candidateInputs: prospectiveResults[1].inputs.length, checks: 'PASS' }));
