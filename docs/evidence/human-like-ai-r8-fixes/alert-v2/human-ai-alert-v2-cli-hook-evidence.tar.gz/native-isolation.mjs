import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { runMatch, aggregate } from './tools/ai-humanity.mjs';
const digest=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const detach=value=>JSON.parse(JSON.stringify(value,(_key,v)=>typeof v==='function'?undefined:v instanceof Map?[...v]:v instanceof Set?[...v]:v));
const results=[];
for(const policy of [null,'public-danger-alert-v1','public-danger-alert-v2']) {
 let proof;
 const match=await runMatch({seconds:9,map:'default',logs:true,...(policy?{alertPolicy:policy}:{}),
  nativeIsolationCapture:(game,logs,rng)=>{const nativeLogs=logs.map(log=>{const {alertMeasurements,alertMeasurementsV2,...native}=log;return native;});proof={game:detach(game),logs:detach(nativeLogs),rng};}},
  {mode:'conquest',level:'normal',seed:27});
 results.push({policy,match,proof});
}
const checks=[],failures=[];
for(const result of results.slice(1))try{assert.deepEqual(result.proof,results[0].proof);checks.push(`${result.policy} full game/native log/next RNG equality`);}catch(error){failures.push({policy:result.policy,message:error.message});}
const mixed=aggregate([results[1].match,results[2].match])['conquest/normal'].publicAlertResponse;
try{assert.equal(mixed.policy,'mixed');assert.equal(mixed.gate,'unknown');assert.equal(mixed.coverageComplete,false);assert.equal(mixed.originalV1.policy,'public-danger-alert-v1');checks.push('mixed primary policy remains unknown with retained v1');}catch(error){failures.push({name:'mixed policy',message:error.message});}
for(const policies of [['public-danger-alert-v1','future-policy'],['future-policy'],[null]]){const forged=policies.map(policy=>({...results[1].match,seats:results[1].match.seats.map(seat=>({...seat,metrics:{...seat.metrics,publicAlertResponse:{policy,recorded:true,evaluable:true,requiredEvents:1,samples:[{seconds:2,observed:true}]}}}))}));try{const pooled=aggregate(forged)['conquest/normal'].publicAlertResponse;assert.equal(pooled.gate,'unknown');assert.equal(pooled.coverageComplete,false);checks.push(`unknown or mixed named policies stay unknown: ${JSON.stringify(policies)}`);}catch(error){failures.push({name:'unknown policy pool',policies,message:error.message});}}
const proof={schema:'ww2-alert-v2-native-collector-isolation-v1',declaration:{seconds:9,mode:'conquest',level:'normal',seed:27,map:'default'},
 checks,failures,results:results.map(result=>({policy:result.policy,gameSHA256:digest(result.proof.game),nativeLogsSHA256:digest(result.proof.logs),rng:result.proof.rng,
  inputs:result.proof.logs.reduce((n,log)=>n+log.inputs.length,0),commands:result.proof.logs.reduce((n,log)=>n+log.commands.length,0)})),mixed,status:failures.length?'FAIL':'PASS'};
await writeFile(new URL('./native-isolation-proof.json',import.meta.url),JSON.stringify(proof,null,2)+'\n');
console.log(JSON.stringify(proof));process.exitCode=failures.length?1:0;
