import subprocess,json,time,hashlib,pathlib
base=pathlib.Path('/tmp/human-ai-alert-v2-cli-hook')
args=['--mode','conquest','--level','normal','--seeds','27-27','--seconds','9','--workers','1','--logs']
cases=[('off','ai-humanity.mjs',[]),('v1','ai-humanity.mjs',['--alert-policy','public-danger-alert-v1']),('v2','ai-humanity.mjs',['--alert-policy','public-danger-alert-v2']),('original-v1','ai-humanity-original-smoke.mjs',['--alert-policy','public-danger-alert-v1']),('legacy-v1','ai-humanity.mjs',['--legacy','--alert-policy','public-danger-alert-v1']),('legacy-v2','ai-humanity.mjs',['--legacy','--alert-policy','public-danger-alert-v2']),('unknown-policy','ai-humanity.mjs',['--alert-policy','public-danger-alert-v999'])]
records=[]
for name,script,extra in cases:
 cmd=['node',str(pathlib.Path('/tmp/human-ai-alert-v2-cli-original/tools/ai-humanity.mjs') if name=='original-v1' else base/'tools'/script),*args,*extra,'--out',str(base/(name+'.json'))]
 started=time.monotonic()
 try:
  proc=subprocess.run(cmd,cwd=base,capture_output=True,text=True,timeout=60)
  result={'name':name,'command':cmd,'exitCode':proc.returncode,'seconds':time.monotonic()-started,'stdout':proc.stdout,'stderr':proc.stderr}
 except subprocess.TimeoutExpired as e:
  result={'name':name,'command':cmd,'exitCode':None,'seconds':time.monotonic()-started,'stdout':str(e.stdout or ''),'stderr':str(e.stderr or ''),'failure':'timeout'}
 (base/(name+'.process.json')).write_text(json.dumps(result,indent=2)+'\n');records.append(result)
 print(name,result['exitCode'],round(result['seconds'],3),flush=True)
(base/'cli-processes.json').write_text(json.dumps(records,indent=2)+'\n')
