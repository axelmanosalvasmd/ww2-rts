from pathlib import Path
import json,hashlib
base=Path('/tmp/human-ai-alert-v2-cli-hook')
reports={name:json.loads((base/(name+'.json')).read_text()) for name in ['off','v1','v2','original-v1']}
checks=[];failures=[]
def check(name,call):
 try:call();checks.append(name)
 except Exception as e:failures.append({'name':name,'message':str(e)})
def eq(a,b):assert a==b
def clean_log(log):return {k:v for k,v in log.items() if k not in ['alertMeasurements','alertMeasurementsV2']}
def clean_metrics(metrics):return {k:v for k,v in metrics.items() if k!='publicAlertResponse'}
for name in ['v1','v2','original-v1']:
 for slot in range(3):
  check(name+' seat'+str(slot)+' native input/command/public/perception/gameplay log equality',lambda name=name,slot=slot:eq(clean_log(reports[name]['results'][0]['logs'][slot]),clean_log(reports['off']['results'][0]['logs'][slot])))
  check(name+' seat'+str(slot)+' nonalert metric equality',lambda name=name,slot=slot:eq(clean_metrics(reports[name]['results'][0]['seats'][slot]['metrics']),reports['off']['results'][0]['seats'][slot]['metrics']))
for slot in range(3):
 native=reports['v2']['results'][0]['logs'][slot]['commands'];captured=reports['v2']['results'][0]['logs'][slot]['alertMeasurementsV2']['commands']
 check('seat'+str(slot)+' actual submit receipt descriptors and acceptance match native commands',lambda native=native,captured=captured:eq([{k:row[k] for k in ['tick','command','accepted']} for row in captured],[{k:row[k] for k in ['tick','command','accepted']} for row in native]))
check('v1 full metrics preserve unmodified collector',lambda:eq(reports['v1']['results'][0]['seats'],reports['original-v1']['results'][0]['seats']))
check('v1 full native stream preserves unmodified collector',lambda:eq(reports['v1']['results'][0]['logs'],reports['original-v1']['results'][0]['logs']))
check('v2 source checkpoint binds actual adapter module',lambda:eq(next(iter(reports['v2']['sourceCheckpoints'].values()))['files']['tools/ai-public-alert-response-v2.mjs'],hashlib.sha256((base/'tools/ai-public-alert-response-v2.mjs').read_bytes()).hexdigest()))
check('v1 source checkpoint entry list unchanged',lambda:eq(list(next(iter(reports['v1']['sourceCheckpoints'].values()))['files']),list(next(iter(reports['original-v1']['sourceCheckpoints'].values()))['files'])))
check('v1 definitions unchanged',lambda:eq(reports['v1']['definitions'],reports['original-v1']['definitions']))
for slot in range(3):
 v1=reports['v1']['results'][0]['seats'][slot]['metrics']['publicAlertResponse'];v2=reports['v2']['results'][0]['seats'][slot]['metrics']['publicAlertResponse']
 check('seat'+str(slot)+' both named live policies',lambda v1=v1,v2=v2:eq([v1['policy'],v2['policy'],v2['originalV1']['policy']],['public-danger-alert-v1','public-danger-alert-v2','public-danger-alert-v1']))
 check('seat'+str(slot)+' retained originalV1 exact equality',lambda v1=v1,v2=v2:eq(v2['originalV1'],v1))
 check('seat'+str(slot)+' v2 live provenance',lambda v2=v2:eq([v2['recorded'],v2['evaluable'],v2['requiredEvents']],[True,True,0]))
pool1=reports['v1']['summary']['conquest/normal']['publicAlertResponse'];pool2=reports['v2']['summary']['conquest/normal']['publicAlertResponse']
check('v2 pool and retained v1 labels',lambda:eq([pool2['policy'],pool2['originalV1']['policy']],['public-danger-alert-v2','public-danger-alert-v1']))
check('pooled retained originalV1 exact equality',lambda:eq(pool2['originalV1'],pool1))
check('all native eventless seats retain unknown gate',lambda:eq([pool1['gate'],pool2['gate'],pool2['originalV1']['gate'],pool2['eventlessSeats']],['unknown','unknown','unknown',3]))
check('original timing range unchanged',lambda:eq(pool2['limitSeconds'],pool1['limitSeconds']))
check('no-policy default has no selected policy',lambda:eq('alertPolicy' in reports['off']['configuration'],False))
for name in ['legacy-v1','legacy-v2','unknown-policy']:
 p=json.loads((base/(name+'.process.json')).read_text())
 check(name+' denial',lambda p=p:eq([p['exitCode'],'current commander' in p['stderr']],[1,True]))
 check(name+' no match report',lambda name=name:eq((base/(name+'.json')).exists(),False))
commands=sum(len(log['commands']) for log in reports['off']['results'][0]['logs']);inputs=sum(len(log['inputs']) for log in reports['off']['results'][0]['logs'])
check('native commands and inputs are nonempty',lambda:eq(commands>0 and inputs>0,True))
output={'schema':'ww2-alert-v2-cli-smoke-proof-v1','declaration':{'mode':'conquest','level':'normal','seed':27,'seconds':9,'map':'default','workers':1,'cpu':3,'nice':19},'checks':checks,'failures':failures,'nativeInputs':inputs,'nativeCommands':commands,'seats':3,'status':'FAIL' if failures else 'PASS','policies':[pool1,pool2]}
(base/'cli-proof.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({'status':output['status'],'checks':len(checks),'failures':failures,'nativeInputs':inputs,'nativeCommands':commands},indent=2))
raise SystemExit(bool(failures))
