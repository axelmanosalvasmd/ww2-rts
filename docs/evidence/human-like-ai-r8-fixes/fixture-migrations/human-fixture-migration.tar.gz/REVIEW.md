# R8 full-human fixture migration

Current native Easy183 failure is a vacuous scenario after stricter purpose: five202 screen contacts all have idleOwnUnits=[], local actors already marching/assigned, and passive held-fire opponents deliver no damage. The test does pay some event-linked selection/aim inputs, but none ends in an accepted linked useful command. Baseline raw and actual failure are retained, not removed or called a gameplay defect.

The narrow candidate authors camera-local idle contact for every original difficulty/seed/horizon. It picks an observer inside the actual camera, then uses native stop and holdFire stance commands to pause only current camera-local own rifles before the existing passive group enters sight. These are scenario setup commands outside the tested AI input timeline, as the original enemy relocation already is. It does not invent an AI event, ACK, input, threshold or damage receipt. It adds a positive assertion that the resulting actual screen contact has a genuine idle opportunity.

Queued planning verification now retains detached public w/h/tick/flags/height/smokes, in addition to prior units/players/screenIds/events. This is the minimal actual LOS view used by the stricter predicate. The frame container is frozen. No authoritative terrain or private scene is retained, and no predicate assertion is bypassed.

Focused original Easy183/2400tick scene PASS: actual202 contacts idleOwnUnits=[1,2]; native accepted useful dive243 (2.05s), later actual linked ability290. Focused original Hard911/300tick handover started600 PASS: actual linked native dive832. All existing source/purpose/floor/locality/opening/APM assertions in those scenarios remain intact. Test logic for complete determinism, detail privacy and original horizons is unchanged. These two bounded scene passes do not certify a new full-suite or campaign.

Paths: test-only candidate test-engine-ai-human.js; /tmp/human-ai-r8-human-fixture.patch; exact production/baseline/candidate hashes source-hashes.json. ROOT remains untouched. Baseline and candidate raw JSON/logs retained.
