import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {createGame,command,step} from './shared/sim.js';
import {viewFor} from './shared/ai-view.js';
import {perceive} from './shared/ai-perception.js';
import {plan} from './shared/ai.js';
import * as before from './shared/ai-hands-before.js';
import * as after from './shared/ai-hands.js';
function scene(api,selection){
 const original=Math.random;Math.random=()=>.5;
 const g=createGame({w:80,h:80,rows:Array(80).fill('.'.repeat(80)),spawns:[{x:5,y:5},{x:70,y:70}],points:[]},['AI','enemy'],false,[0,1],[0,1],{weather:false});Math.random=original;g.units.clear();g.players[0].mp=5000;
 const own=[];for(let i=0;i<3;i++){assert.equal(command(g,0,{t:'buy',unit:'rifle'}),undefined);const u=[...g.units.values()].at(-1);Object.assign(u,{x:75+i*6,z:80,auto:false,autoRetreat:false,holdFire:true});own.push(u);}
 g.tick=240;g.players[0].mp=0;const inputs=[],receipts=[],camera={x:80,z:80,yaw:0,distance:60};
 const hands=api.createHands({slot:0,seed:27,level:'hard',camera,log:i=>inputs.push(structuredClone(i))}),state={camera,hands};
 const observe=()=>perceive(viewFor(g,0,{}),0,state);
 let view=observe();
 const advance=()=>{view=observe();api.advanceHands(hands,g.tick,view,cmd=>{const result=command(g,0,cmd);receipts.push({tick:g.tick,cmd:structuredClone(cmd),result:result??'accepted'});return result;});step(g);};
 const selected=selection==='subset'?own[0]:own[2];
 assert.ok(api.queueInspection(hands,[selected.id],view,{concernKind:'combat'}));
 for(let i=0;i<1200&&hands.selected[0]!==selected.id;i++)advance();
 assert.deepEqual(hands.selected,[selected.id],'selection comes from actual physical inspection');
 if(selection==='exact'){
  view=observe();assert.ok(api.enqueueDecision(hands,{t:'stance',ids:own.slice(0,2).map(u=>u.id),key:'holdFire',on:false},view,{concernKind:'combat'}));
  for(let i=0;i<1200&&!receipts.length;i++)advance();assert.deepEqual(new Set(hands.selected),new Set(own.slice(0,2).map(u=>u.id)));
 }
 view=observe();const prior=structuredClone(inputs);own.slice(0,2).forEach(u=>{u.hp=30;});step(g);view=observe();const events=view.newEvents.filter(e=>e.kind==='screen-damage');if(events.length!==2)console.error(JSON.stringify({selection,ids:own.map(u=>u.id),screen:[...view.screenIds],events:view.newEvents,seen:[...state.screenMemory].map(([id,u])=>({id,hp:u.hp})),unitRows:[...view.units.values()].map(u=>({id:u.id,x:u.x,z:u.z,hp:u.hp,hpSource:u.hpSource,screenSeen:u.screenSeen}))}));assert.equal(events.length,2);
 const proposals=[],mem={human:{persona:{pressure:1,opening:['rifle','mg','rifle'],economy:'barracks'},startedTick:0,buys:0},seen:new Map(),node:new Map()};
 plan(view,0,{human:true,level:'hard',seed:27,concern:{id:'local-damage',kind:'combat',x:78,z:80}},mem,cmd=>{proposals.push(structuredClone(cmd));return undefined;});
 const retreat=proposals.find(cmd=>cmd.t==='retreat');assert.ok(retreat,'actual planner responds to observed hurt with group retreat');assert.deepEqual(new Set(retreat.ids),new Set(own.slice(0,2).map(u=>u.id)));
 const created=g.tick;assert.ok(api.enqueueDecision(hands,retreat,view,{concernKind:'combat',event:events[0],eventTick:created,reactionStartTick:created,responseEvents:events,responseActorIds:retreat.ids}));
 for(let i=0;i<1200&&!receipts.some(r=>r.cmd.t==='retreat');i++)advance();
 const receipt=receipts.find(r=>r.cmd.t==='retreat');assert.ok(receipt&&receipt.result==='accepted');assert.ok(own.slice(0,2).every(u=>u.retreating),'same actual two actors enter native retreat');assert.equal(own[2].retreating,false);
 const causal=inputs.filter(i=>i.tick>=created&&i.responseEvents?.some(e=>e.id===events[0].id));assert.ok(causal.length&&causal[0].tick-created>=4,'unchanged causal floor');
 const selectionInputs=causal.filter(i=>i.kind.startsWith('select-'));
 return {selection,created,firstTick:causal[0].tick,firstLatency:(causal[0].tick-created)/20,acceptedTick:receipt.tick,acceptedLatency:(receipt.tick-created)/20,prior,selectionInputs,causal,receipt};
}
const rows=[];for(const selection of ['subset','outside','exact']){
 const b=scene(before,selection),a=scene(after,selection);assert.deepEqual(a.prior,b.prior,'native prior selection timeline identical');assert.deepEqual(a.receipt.cmd,b.receipt.cmd,'same actual native group command');
 if(selection==='subset'){assert.equal(b.selectionInputs[0]?.kind,'select-box');assert.equal(a.selectionInputs[0]?.kind,'select-add-click');assert.equal(a.selectionInputs[0]?.input.shift,true);assert.ok(a.firstLatency<b.firstLatency);assert.ok(a.acceptedLatency<b.acceptedLatency);}
 else {assert.deepEqual(a,b,'unrelated/exact actual selection retains complete native timeline');}
 rows.push({selection,before:b,after:a});
}
writeFileSync(process.argv[2],JSON.stringify({schema:'r8-one-companion-selection-v1',rows},null,2)+'\n');console.log(rows.map(r=>`${r.selection}: first${r.before.firstLatency}->${r.after.firstLatency}, accepted${r.before.acceptedLatency}->${r.after.acceptedLatency}`).join('\n'));
