# Portable selection reuse regression

Proposed repository file: test-engine-ai-selection-reuse.js. Production sim, view, perception, hands and planner imports are relative to that repository. The test writes no files and requires no scratch path, archive, tools or external baseline. It loads a source-derived baseline in memory that removes only the new persistent-subset selection route. Every current reaction/motor/hit-test/group/locality/capacity helper and constant stays unchanged.

The original three native scenes are preserved: paid single desired actor selection, paid unrelated selection, and paid complete two-actor selection. They use native purchases, physical inspection/group input, genuine delivered injured-actor events, production-plan retreat, actual selection input and native command receipts. Both intended actors retreat and the third does not. Native prior timelines and final recipient sets stay identical. It additionally verifies the complete paid motor duration and exactly one physical selection input in both baseline and reused route.

One focused portable conversion run passed onCPU3 nice19. The test imports the actual candidate runtime. The control derives only the old selection strategy from that same current source, avoiding a second stale runtime tree. It asserts the legal Shift plus left click and the same complete native group outcome. There are no new scene variants, full matches or scoring changes.

Run after source/test adoption:

```
node test-engine-ai-selection-reuse.js
```

Earlier native raw proof, protocol, source hashes, source patch and all initial diagnostic logs are preserved. native-initial-reconstructed.mjs reconstructs the exact initial failed fixture from its explicit edits and original command transcript; it is marked reconstructed, not an independently captured initial checkpoint. That failure was the expected missing selected-HUD damage baseline, not a runtime defect. Subsequent diagnostic logs are likewise retained. No failed proof is presented as a pass.

ROOT source writes, registration, full checks and adoption remain parent-owned.
