import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {createGame,command,step} from './shared/sim.js';
import {viewFor} from './shared/ai-view.js';
import {runCommander as beforeCommander} from './shared/ai-commander-before.js';
import {runCommander as afterCommander} from './shared/ai-commander.js';
function scene(run,mode){
 const save=Math.random;Math.random=()=>.5;
 const g=createGame({w:80,h:80,rows:Array(80).fill('.'.repeat(80)),spawns:[{x:20,y:40},{x:75,y:40}],points:[]},['AI','enemy'],false,[0,1],[0,1],{weather:false});Math.random=save;g.units.clear();
 const buy=(owner,type,x,z)=>{g.players[owner].mp=5000;g.players[owner].mun=1000;assert.equal(command(g,owner,{t:'buy',unit:type}),undefined);const u=[...g.units.values()].at(-1);Object.assign(u,{x,z,holdFire:true,auto:false,autoRetreat:false});return u;};
 const own=buy(0,'rifle',80,80),foe=buy(1,'rifle',100,80),memory={human:{startedTick:0,camera:{x:87,z:80,yaw:0,distance:60}}},inputs=[],receipts=[];
 let observation,proposed=false,damage;
 for(let tick=0;tick<500;tick++){
  if(g.tick===100)own.hp*=.6;
  if(!observation||g.tick%2===0)observation=viewFor(g,0,{});
  run(observation,0,{tick:g.tick,level:'normal',seed:27,inputLog:i=>inputs.push(structuredClone(i))},memory,cmd=>{
   if(mode==='refuse')g.players[0].mp=0;
   const result=command(g,0,cmd);receipts.push({tick:g.tick,cmd:structuredClone(cmd),result:result??'accepted'});return result;
  },(_v,_s,_o,_m,send)=>{
   if(g.tick<100||proposed)return;
   send({t:'support',kind:'dive',x:100,z:mode==='miss'?90:80,dir:0});
  });
  damage??=memory.human.events.find(e=>e.kind==='screen-damage'&&e.unitId===own.id&&e.tick===100);
  if(receipts.length)break;step(g);
 }
 if(!damage||receipts.length!==1)console.error(JSON.stringify({mode,tick:g.tick,events:memory.human.events,receipts,inputs,concern:memory.human.concern,queue:memory.human.hands.queue}));
 assert.ok(damage&&receipts.length===1,'actual delivered damage and one real physical issuing input');
 const issued=inputs.find(i=>i.command?.t==='support');assert.ok(issued);if(mode!=='miss'||run===beforeCommander)assert.ok(issued.responseEvents.some(e=>e.id===damage.id),mode);
 assert.ok(issued.tick-damage.tick>=4);const answered=memory.human.answeredEvents?.has(damage.id)??false;
 return {mode,event:structuredClone(damage),receipt:receipts[0],issued,answered};
}
const rows=[];
for(const mode of ['valid','miss','refuse']){
 const before=scene(beforeCommander,mode),after=scene(afterCommander,mode);
 assert.deepEqual(after.receipt,before.receipt,'same ordinary command and native receipt before/after');
 if(mode!=='miss')assert.deepEqual(after.issued,before.issued,'same physical inputs and original response descriptors');
 else assert.ok(!after.issued.responseEvents?.some(e=>e.id===after.event.id),'unhelpful decision does not acquire a causal response link');
 assert.equal(after.answered,mode==='valid');
 if(mode==='miss')assert.equal(before.answered,true,'baseline acknowledges the accepted footprint miss');
 if(mode==='refuse')assert.equal(before.answered,false,'baseline already prevents refused-command acknowledgement');
 rows.push({mode,before,after});
}
writeFileSync(process.argv[2],JSON.stringify({schema:'r8-physical-support-v1',rows},null,2)+'\n');console.log('3 physical commander scenes PASS');
