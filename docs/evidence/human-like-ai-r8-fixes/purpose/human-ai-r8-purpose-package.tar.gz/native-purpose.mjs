import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import * as sim from './shared/sim.js';
import {viewFor} from './shared/ai-view.js';
import {perceive} from './shared/ai-perception.js';
import {commandServesObservedEvent as oldPurpose} from './shared/ai-priority-before.js';
import {commandServesObservedEvent as newPurpose} from './shared/ai-priority.js';
const rows=[];
function scene(type='rifle', ownType='mg', ownX=75) {
 const save=Math.random;Math.random=()=>.5;
 const g=sim.createGame({w:80,h:80,rows:Array(80).fill('.'.repeat(80)),spawns:[{x:5,y:5},{x:70,y:70}],points:[]},['AI','enemy'],false,[0,1],[0,1],{weather:false});Math.random=save;g.units.clear();
 function buy(owner,type,x,z){g.players[owner].mp=5000;g.players[owner].mun=1000;assert.equal(sim.command(g,owner,{t:'buy',unit:type}),undefined);const u=[...g.units.values()].at(-1);Object.assign(u,{x,z,auto:false,autoRetreat:false,holdFire:true});return u;}
 const own=buy(0,ownType,ownX,80),foe=buy(1,type,100,80),state={camera:{x:87,z:80,yaw:0,distance:60},hands:{selected:[own.id]}};
 for(let i=0;i<8;i++)sim.step(g);
 const view=perceive(viewFor(g,0,{}),0,state),event=view.newEvents.find(e=>e.kind==='screen-contact'&&e.targetId===foe.id);
 assert.ok(event&&view.screenIds.has(own.id)&&view.screenIds.has(foe.id),'native delivered scene generates actual contact');
 return {g,own,foe,state,view,event,buy};
}
function proof(label,f,cmd,expected,{native=true}={}){
 if(cmd.t==='ability')cmd.ids=[f.own.id];
 const before=oldPurpose(cmd,f.event,f.view,0),after=newPurpose(cmd,f.event,f.view,0);
 const result=native?sim.command(f.g,0,cmd):'public scene predicate control';
 rows.push({label,event:structuredClone(f.event),own:pick(f.view.units.get(f.own.id)),foe:pick(f.view.units.get(f.foe.id)),cmd,before,after,result:result??'accepted'});
 if(after!==expected)console.error(JSON.stringify(rows.at(-1)));
 assert.equal(after,expected,label);
 return result;
}
function pick(u){return Object.fromEntries(['id','type','owner','x','z','hp','hpSource','targetId','attackId','cd','cdKnown','flags','firstStillAt','holdFire','retreating'].map(k=>[k,u[k]]));}
for(const [label,cmd,expected]of[
 ['valid dive',{t:'support',kind:'dive',x:100,z:80,dir:0},true],
 ['dive misses by10m',{t:'support',kind:'dive',x:110,z:80,dir:0},false],
 ['artillery side miss8m',{t:'support',kind:'artillery',x:100,z:88,dir:0},false],
 ['valid strafe infantry',{t:'support',kind:'strafe',x:100,z:80,dir:Math.PI/2},true],
])assert.equal(proof(label,scene(),cmd,expected),undefined);
assert.equal(proof('strafe ineffective native armor',scene('tank'),{t:'support',kind:'strafe',x:100,z:80,dir:0},false),undefined);
{
 const f=scene('tank'); const friend=f.buy(0,'rifle',100,80);f.view=perceive(viewFor(f.g,0,{}),0,f.state);
 const hp=friend.hp;assert.equal(proof('dive contains current friendly',f,{t:'support',kind:'dive',x:100,z:80,dir:0},false),undefined);
 for(let i=0;i<sim.SUPPORT.dive.delay*20+3;i++)sim.step(f.g);
 rows.push({label:'actual native friendly damage',beforeHP:hp,afterHP:friend.hp});assert.ok(friend.hp<hp);
}
function abilityScene(ownType='mg',enemyType='rifle'){
 const f=scene(enemyType,ownType,80);
 for(let i=0;i<100;i++)sim.step(f.g);
 f.own.holdFire=false;assert.equal(sim.command(f.g,0,{t:'attack',ids:[f.own.id],target:f.foe.id}),undefined);sim.step(f.g);
 f.view=perceive(viewFor(f.g,0,{}),0,f.state);f.own.hp*=.6;sim.step(f.g);
 f.view=perceive(viewFor(f.g,0,{}),0,f.state);f.event=f.view.newEvents.find(e=>e.kind==='screen-damage'&&e.unitId===f.own.id);
 assert.ok(f.event,'genuine delivered damaged actor cue');assert.equal(f.view.units.get(f.own.id).hpSource,'selected-hud');assert.equal(f.view.units.get(f.own.id).targetId,f.foe.id);
 return f;
}
assert.equal(proof('ready selected HUD MG native suppress',abilityScene(),{t:'ability',ids:[1]},true),undefined);
for(const [label,alter]of[
 ['MG selected HUD absent',u=>{u.hpSource='world-bar';}],
 ['MG cooldown unknown',u=>{u.cdKnown=false;u.cd=Infinity;}],
 ['MG cooldown active',u=>{u.cd=5;}],
 ['MG moving',u=>{u.path=[{x:82,z:80}];}],
 ['MG setting up',u=>{u.firstStillAt=5.1;}],
 ['MG retreating',u=>{u.retreating=true;}],
 ['MG holding fire without attack',u=>{u.holdFire=true;u.attackId=0;}],
]){const f=abilityScene();alter(f.view.units.get(f.own.id));proof(label,f,{t:'ability',ids:[f.own.id]},false,{native:false});}
{const f=abilityScene();f.view.units.get(f.foe.id).retreating=true;proof('MG foe already retreating',f,{t:'ability',ids:[f.own.id]},false,{native:false});}
{const f=scene();f.state.camera.x=5;f.view=perceive(viewFor(f.g,0,{}),0,f.state);proof('offcamera hostile cannot justify strike',f,{t:'support',kind:'dive',x:100,z:80,dir:0},false,{native:false});}
assert.equal(proof('MG suppress native armor ineffective',abilityScene('mg','tank'),{t:'ability',ids:[1]},false),undefined);
assert.equal(proof('ready AP native armor',abilityScene('at','tank'),{t:'ability',ids:[1]},true),undefined);
assert.equal(proof('AP against native infantry ineffective',abilityScene('at','rifle'),{t:'ability',ids:[1]},false),undefined);
{const f=scene(),cmd={t:'support',kind:'dive',x:100,z:80,dir:0},baseline=newPurpose(cmd,f.event,f.view,0);f.event.responseRequired=false;f.event.responseUnits=[];f.event.privatePopulation=987;assert.equal(newPurpose(cmd,f.event,f.view,0),baseline,'private measurement fields do not drive behavior');}
writeFileSync(process.argv[2],JSON.stringify({schema:'r8-purpose-native-v1',rows},null,2)+'\n');console.log(`${rows.length} native purpose rows PASS`);
