import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {createGame,command,step} from './shared/sim.js';
import {viewFor} from './shared/ai-view.js';
import {perceive} from './shared/ai-perception.js';
import {plan as beforePlan} from './shared/ai-before.js';
import {plan as afterPlan} from './shared/ai.js';
function scene(run,friendNear,level,human=true){
 const save=Math.random;Math.random=()=>.5;
 const g=createGame({w:80,h:80,rows:Array(80).fill('.'.repeat(80)),spawns:[{x:5,y:5},{x:70,y:70}],points:[]},['AI','enemy'],false,[0,1],[0,1],{weather:false});Math.random=save;g.units.clear();
 const buy=(owner,type,x,z)=>{g.players[owner].mp=5000;assert.equal(command(g,owner,{t:'buy',unit:type}),undefined);const u=[...g.units.values()].at(-1);Object.assign(u,{x,z,holdFire:true,auto:false,autoRetreat:false});return u;};
 buy(0,'mg',75,80);const foe=buy(1,'tank',100,80);buy(0,'rifle',friendNear?100:75,friendNear?80:95);
 for(let i=0;i<8;i++)step(g);
 const state={camera:{x:87,z:80,yaw:0,distance:60},hands:{selected:[]},persona:{pressure:1,opening:['rifle','mg','rifle'],economy:'barracks'},startedTick:0,buys:0};
 const view=perceive(viewFor(g,0,{}),0,state),mem={human:state,seen:new Map(),node:new Map()},commands=[];
 assert.ok(view.screenIds.has(foe.id));
 run(view,0,{human,level,seed:27,decisionOnly:!human,concern:{id:'combat-fixture',kind:'combat',x:100,z:80}},mem,cmd=>{commands.push(structuredClone(cmd));return undefined;});
 return {friendNear,level,human,commands,support:commands.filter(cmd=>cmd.t==='support')};
}
const rows=[];
for(const level of ['easy','normal','hard'])for(const friendNear of [false,true]){
 const before=scene(beforePlan,friendNear,level),after=scene(afterPlan,friendNear,level);
 assert.ok(before.support.some(cmd=>cmd.kind==='dive'),'baseline planner proposes dive against actual watched tank');
 if(friendNear)assert.ok(!after.support.some(cmd=>['dive','bombing'].includes(cmd.kind)),'human plan never proposes observed friendly blast/stick hazard');
 else assert.deepEqual(after.commands,before.commands,'safe scene retains complete ordinary plan');
 rows.push({level,friendNear,before,after});
}
const legacyBefore=scene(beforePlan,true,'hard',false),legacyAfter=scene(afterPlan,true,'hard',false);
assert.deepEqual(legacyAfter.commands,legacyBefore.commands,'legacy decision layer is unchanged');rows.push({legacyBefore,legacyAfter});
writeFileSync(process.argv[2],JSON.stringify({schema:'r8-planner-friendly-v1',rows},null,2)+'\n');console.log('7 actual planner scenes PASS');
