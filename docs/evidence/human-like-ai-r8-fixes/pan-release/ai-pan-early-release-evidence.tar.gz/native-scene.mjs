const folder = process.env.AI_RELEASE_BASELINE ? 'baseline' : 'source';
const [sim,perception,hands,viewModule,ai] = await Promise.all(['sim','ai-perception','ai-hands','ai-view','ai'].map(name=>import(`./${folder}/shared/${name}.js`)));
import { createAIcase } from './source/tools/ai-lab-runner.mjs';
import { writeFile } from 'node:fs/promises';
const units = [{ owner: 0, type: 'rifle', x: 78, z: 79, holdFire: true, autoRetreat: false },
  { owner: 0, type: 'mg', x: 160, z: 145, holdFire: true, autoRetreat: false },
  { owner: 1, type: 'mg', x: 96, z: 79, holdFire: true }];
const scene = { units, points: [{ x: 80, z: 80, owner: 0 }, { x: 165, z: 150, owner: -1 }], camera: { x: 80, z: 79, yaw: 0 },
  resources: [{ mp: 20, fuel: 0, mun: 200 }, { mp: 0, fuel: 0, mun: 200 }], cues: [] };
let memory, cue;
const engine = { sim, perception, hands, ai: { ...ai, think(game,slot,opts) { memory = opts.memory; return ai.think(game,slot,opts); } },
 view: { ...viewModule, viewFor(game,slot,cache) {
   const state = memory?.human, active = state?.hands?.active, action = active?.actions[active.index];
   const actor = game.units.get(state?.hands?.selected[0]);
   if (!cue && actor && state.hands.selected.length === 1 && active && !active.reacting && action.mode === 'pan'
     && game.tick >= active.start + action.panPrep && game.tick < active.due
     && perception.onScreen(actor,state.camera)) {
      actor.hp *= .45; game.shots.push({ k: 'hurt', t: actor.id, to: 0, fo: 1, x: actor.x, z: actor.z, kill: false });
      cue = { tick: game.tick, actorId: actor.id, actualSelection: [...state.hands.selected], camera: { ...state.camera },
        active: { start: active.start, due: active.due, prep: action.panPrep, hold: action.panHold },
        note: 'Authored 55% hit at first actual held pan while its actual selected actor remains on screen. Predeclared trigger, no state or plan injection.' };
   }
   return viewModule.viewFor(game,slot,cache);
 } } };
const episode = createAIcase(engine, { scenario: 'guard', level: 'hard', seed: 27, seconds: 30 }, scene);
episode.advance(600);
const result = { scene, cue, trace: episode.record() };
await writeFile(new URL(`./native-${process.env.AI_RELEASE_BASELINE ? 'baseline' : 'candidate'}.json`,import.meta.url),JSON.stringify(result,null,2));
console.log(JSON.stringify({mode:folder,cue,events:result.trace.events.filter(e=>e.kind==='screen-damage'),inputs:result.trace.inputs.map(i=>({tick:i.tick,kind:i.kind,ids:i.ids,release:i.panRelease,command:i.command})),commands:result.trace.commands.map(c=>({tick:c.tick,accepted:c.accepted,command:c.command}))}));
