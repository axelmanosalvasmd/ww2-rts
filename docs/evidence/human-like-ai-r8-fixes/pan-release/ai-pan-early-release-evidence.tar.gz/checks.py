from pathlib import Path
import subprocess,time,json,hashlib
base=Path('/tmp/ai-pan-early-release');results=[]
for name in ['test-engine-ai-hands.js','test-engine-ai-response.js','test-engine-ai-public-alert.js','test-engine-ai-diagonal-pan.js','test-engine-ai-pan-release.js']:
 t=time.monotonic()
 with (base/(name+'.log')).open('w') as out:
  p=subprocess.run(['taskset','-c','3','nice','-n','19','node',str(base/'source'/name)],stdout=out,stderr=subprocess.STDOUT)
 row={'test':name,'exitCode':p.returncode,'elapsedMs':round((time.monotonic()-t)*1000,3),'logSHA256':hashlib.sha256((base/(name+'.log')).read_bytes()).hexdigest()};results.append(row);print(json.dumps(row),flush=True)
(base/'checks.json').write_text(json.dumps({'diagnosticOnly':True,'checks':results},indent=2)+'\n')
raise SystemExit(any(x['exitCode'] for x in results))
