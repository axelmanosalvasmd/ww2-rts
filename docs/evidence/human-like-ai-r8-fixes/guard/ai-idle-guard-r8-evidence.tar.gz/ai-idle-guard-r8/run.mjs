import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const dir='/tmp/ai-idle-guard-r8',d=JSON.parse(await readFile(`${dir}/preregistration.json`));
for(const v of ['baseline','candidate'])for(const [f,h]of Object.entries(d.sourceFiles[v]))assert.equal(createHash('sha256').update(await readFile(`${dir}/${v}/source/${f}`)).digest('hex'),h.sha256);
for(const v of ['baseline','candidate']){
 const {run}=await import(`./${v}/episode-library.mjs`);
 for(const c of d.cases){const raw=await run(c.name,c.level,c.seed);await writeFile(`${dir}/${v}/${c.name}-${c.level}-${c.seed}.json`,JSON.stringify(raw));console.log(JSON.stringify({v,...c,inputs:raw.log.inputs.length,commands:raw.log.commands.map(x=>({tick:x.tick,t:x.command.t,accepted:x.accepted})),alerts:raw.alertScore.samples,screen:raw.manualScore.firstCompletedAction.samples}));}
}
for(const v of ['baseline','candidate'])for(const [f,h]of Object.entries(d.sourceFiles[v]))assert.equal(createHash('sha256').update(await readFile(`${dir}/${v}/source/${f}`)).digest('hex'),h.sha256);
console.log('PASS all preregistered source hashes unchanged');
