import subprocess,os,pathlib,json
p=pathlib.Path('/tmp/ai-idle-guard-r8')
with (p/'engineer-proof.log').open('w') as out:
 for v in ['baseline','candidate']:
  env=os.environ.copy();env['AI_ENGINEER_PROOF']=str(p/v/'engineer-controls.json')
  subprocess.run(['taskset','-c','5','nice','-n','19','node',str(p/v/'source/test-engine-ai-local-engineer.js')],env=env,stdout=out,stderr=out,check=True)
 a=json.loads((p/'baseline/engineer-controls.json').read_text());b=json.loads((p/'candidate/engineer-controls.json').read_text());assert a==b,'all 13 native engineer controls have equal input/command/build histories';out.write('PASS exact native engineer histories across all 13 controls\n')
