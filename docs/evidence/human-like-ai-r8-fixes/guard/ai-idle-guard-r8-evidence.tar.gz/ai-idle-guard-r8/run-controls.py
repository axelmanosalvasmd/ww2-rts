import subprocess,os,pathlib
p=pathlib.Path('/tmp/ai-idle-guard-r8')
with (p/'controls.log').open('w') as out:
 for v in ['baseline','candidate']:
  env=os.environ.copy();env['AI_ENGINEER_PROOF']=str(p/v/'engineer-controls.json')
  subprocess.run(['taskset','-c','5','nice','-n','19','node',str(p/v/'source/test-engine-ai-local-engineer.js')],env=env,stdout=out,stderr=out,check=True)
 env=os.environ.copy();env['AI_IDLE_GUARD_PROOF']=str(p/'portable-fixture-proof.json')
 subprocess.run(['taskset','-c','5','nice','-n','19','node',str(p/'candidate/source/test-engine-ai-idle-guard-attention.js')],env=env,stdout=out,stderr=out,check=True)
