import json,pathlib,hashlib
p=pathlib.Path('/tmp/ai-idle-guard-r8')
base=json.loads(pathlib.Path('/tmp/ai-native-flank-v21/scene.json').read_text())
src=pathlib.Path('/tmp/ai-native-flank-v21/episode-library.mjs').read_text()
flank=json.loads(src.split('const scenes=')[1].split(';\nconst files=')[0])['flank']
quiet=json.loads(json.dumps(flank));quiet['scene']['units']=quiet['scene']['units'][:3];quiet['initialOrders']=[]
late=json.loads(json.dumps(flank));late['scene']['units'][3].update(x=191,z=1)
plain=json.loads(json.dumps(quiet));plain['seconds']=30;plain['scene']['points']=[]
grenade={'seconds':20,'scene':{'units':[{'owner':0,'type':'rifle','x':78,'z':79,'holdFire':False},{'owner':1,'type':'mg','x':88,'z':79,'holdFire':False}],'points':[{'x':80,'z':80,'owner':0}],'camera':{'x':80,'z':79,'yaw':0},'resources':[{'mp':0,'fuel':0,'mun':200},{'mp':0,'fuel':0,'mun':200}]}}
scenes={'flank':flank,'quietguard':quiet,'lateflank':late,'plainidle':plain,'guardgrenade':grenade}
cases=[{'name':'flank','level':l,'seed':1,'seconds':60} for l in ['easy','normal','hard']]+[{'name':n,'level':'hard','seed':1,'seconds':scenes[n]['seconds']} for n in ['quietguard','lateflank','plainidle','guardgrenade']]
files={}
for variant in ['baseline','candidate']:
 d=p/variant
 s=src.replace("const dir='/tmp/ai-native-flank-v21'",f"const dir='{d}'")
 s=s.replace(src.split('const scenes=')[1].split(';\nconst files=')[0],json.dumps(scenes))
 s=s.replace('emptyCombatVisits:structuredClone(h.emptyCombatVisits),','emptyCombatVisits:structuredClone(h.emptyCombatVisits),emptyIdleGuards:structuredClone(h.emptyIdleGuards),camera:structuredClone(h.camera),selected:[...h.hands.selected],motor:structuredClone(h.hands.motor),')
 (d/'episode-library.mjs').write_text(s)
 files[variant]={str(f.relative_to(d/'source')):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in (d/'source').rglob('*') if f.is_file()}
(p/'preregistration.json').write_text(json.dumps({'diagnosticOnly':True,'declaredBeforeExecution':True,'cases':cases,'scenes':scenes,'engineer':'Unchanged native 13-case engineer fixture, including paid assist and depot construction. No source changes outside attention and commander.','invariants':'Same native scene, level, seed and horizon in each pair. Keep every raw input, event, command receipt, censor and private state. Existing frozen baseline flank must reproduce exactly. New damage/contact/objective/position/readiness/affordability releases defer; plain idle and engineers excluded; quiet guards receive bounded 30-second reinspection. No score or timing edits.','sourceFiles':files},indent=2))
