import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
const dir='/tmp/ai-idle-guard-r8',decl=JSON.parse(await readFile(`${dir}/preregistration.json`));
const load=async(v,c)=>JSON.parse(await readFile(`${dir}/${v}/${c.name}-${c.level}-${c.seed}.json`));
const triples=[],eqKeys=['log','nativePhysics','authorFrames','authoritativeEnd','authorOrders','manualScore','alertScore'];
for(const c of decl.cases){
 const b=await load('baseline',c),a=await load('candidate',c);
 if(c.name==='flank'){
  const historical=JSON.parse(await readFile(`/tmp/ai-native-flank-v21/${c.level}-seed1.json`));
  for(const k of eqKeys)assert.deepEqual(b[k],historical[k],`exact immutable historical reproduction ${c.level}/${k}`);
 }
 if(['plainidle','guardgrenade'].includes(c.name)){
  for(const k of eqKeys.filter(k=>k!=='log'))assert.deepEqual(a[k],b[k],`${c.name} native negative control ${k}`);
  for(const k of ['events','inputs','commands'])assert.deepEqual(a.log[k],b.log[k],`${c.name} native negative control ${k}`);
 }
 const cache=a.publicDiagnostics.flatMap(frame=>frame.emptyIdleGuards).sort((x,y)=>x[1].tick-y[1].tick)[0];
 const changedTick=cache?.[1].tick;
 if(changedTick!=null)for(const k of ['nativePhysics','authorFrames','log']){
  if(k==='log')for(const sub of ['events','inputs','commands'])assert.deepEqual(a.log[sub].filter(x=>x.tick<=changedTick),b.log[sub].filter(x=>x.tick<=changedTick),`native prefix ${c.name}/${sub}`);
  else assert.deepEqual(a[k].filter(x=>x.tick<=changedTick),b[k].filter(x=>x.tick<=changedTick),`native prefix ${c.name}/${k}`);
 }
 const trips=r=>r.log.inputs.filter(i=>i.concern==='idle:9'&&i.kind.startsWith('camera-')).map(i=>({tick:i.tick,kind:i.kind}));
 const native=r=>({inputs:r.log.inputs.length,guardTrips:trips(r),alerts:r.alertScore.samples,screen:r.manualScore.firstCompletedAction,originalMG:r.authoritativeEnd.units.find(u=>u.id===9),points:r.authorFrames.at(-1).points,commands:r.log.commands.map(x=>({tick:x.tick,accepted:x.accepted,command:x.command,mpPaid:x.resourcesBefore.mp-x.resourcesAfter.mp}))});
 triples.push({...c,firstEmptyGuardDecisionTick:changedTick??null,nativeHistoryIdenticalThroughThatTick:changedTick!=null,baseline:native(b),candidate:native(a)});
}
await writeFile(`${dir}/focused-evidence.json`,JSON.stringify({diagnosticOnly:true,allRowsRetained:true,baselineHistoricalExact:true,unchangedBoundaryHistories:['plainidle','guardgrenade'],cases:triples},null,2));
console.log('PASS native baseline reproduction, exact unchanged controls and native first-decision prefixes');
