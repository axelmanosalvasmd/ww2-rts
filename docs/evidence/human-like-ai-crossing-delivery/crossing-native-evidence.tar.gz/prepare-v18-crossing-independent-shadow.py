from pathlib import Path
root=Path('/tmp/v18-crossing-candidate');old=(root/'shared/sim.js').read_text();start=old.index('const pathRegions =');end=old.index('// Cells touching a wall',start);region=old[start:end].replace('regionDx','shadowRegionDx').replace('regionDy','shadowRegionDy').replace('pathRegions','shadowPathRegions').replace('regionsFor','shadowRegionsFor').replace('buffersFor(N).freeQueue','new Int32Array(N)');region+='\nconst shadowCounts={infantry:0,vehicle:0,rejections:0};\n'
needle='  // A connected coarse route is contained in full-map connectivity on these internal views.';assert old.count(needle)==1
shadow="""  if (!g.worldKnown && nativeObservedPathViews.has(g) && goal !== start && !(g.flags[start] & block)) {
    shadowCounts[g.vehicleFootprintKnown?'vehicle':'infantry']++;
    const shadowLabels=shadowRegionsFor(g,block);
    if(shadowLabels[goal]<0||shadowLabels[start]!==shadowLabels[goal]){shadowCounts.rejections++;throw new Error(JSON.stringify({kind:'omitted-region-rejection',tick:g.tick,id:from.id,type:from.type,start,goal,block,labels:[shadowLabels[start],shadowLabels[goal]],vehicle:!!g.vehicleFootprintKnown,versions:[g.infantryRegionVersion,g.vehicleRegionVersion,g.obstructionVersion,g.navigationKnowledgeVersion]}));}
  }
"""
s=old[:start]+region+old[start:];s=s.replace(needle,shadow+needle);s+='\nexport {shadowCounts};\n';(root/'shared/sim-independent-region-shadow.js').write_text(s)
server=(root/'server.js').read_text().replace("'./shared/sim.js'","'./shared/sim-independent-region-shadow.js'");(root/'server-independent-region-shadow.js').write_text(server)
t=(root/'test-engine-acceptance.js').read_text().replace("'./shared/sim.js'","'./shared/sim-independent-region-shadow.js'").replace("'./server.js'","'./server-independent-region-shadow.js'");t="import {writeFileSync} from 'node:fs';\n"+t;t=t.replace('} finally {\n  server.clock.setTimeout',"} finally {\n  writeFileSync('/tmp/v18-crossing-independent-shadow-counts.json',JSON.stringify(sim.shadowCounts));\n  server.clock.setTimeout");(root/'test-engine-crossing-independent-shadow.js').write_text(t)
