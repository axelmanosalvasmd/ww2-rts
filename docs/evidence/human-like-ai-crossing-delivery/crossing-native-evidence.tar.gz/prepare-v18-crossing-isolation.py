from pathlib import Path
import shutil,hashlib,json
src=Path('/tmp/human-ai-v18-final-full-source');base=Path('/tmp/v18-crossing-original');cand=Path('/tmp/v18-crossing-candidate')
for dst in [base,cand]:
 assert not dst.exists();dst.mkdir()
 for name in ['shared','client','server','maps']:shutil.copytree(src/name,dst/name,symlinks=True)
 for name in ['server.js','tickmeter.js','package.json','test-engine-acceptance.js']:shutil.copyfile(src/name,dst/name)
 (dst/'node_modules').symlink_to('/home/judiazm/.t3/worktrees/ww2-rts/ai-human-commander/node_modules',target_is_directory=True)
 for p in dst.rglob('*'):
  if p.is_file() and not p.is_symlink():p.chmod(0o644)
 (dst/'shared').chmod(0o755)
shutil.copyfile('/tmp/human-ai-perf-v16-frozen/shared/sim.js',base/'shared/sim.js')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();b={str(p.relative_to(base)):sha(p) for p in base.rglob('*') if p.is_file() and 'node_modules' not in p.parts};c={str(p.relative_to(cand)):sha(p) for p in cand.rglob('*') if p.is_file() and 'node_modules' not in p.parts};changed=[k for k in b if b[k]!=c[k]];assert changed==['shared/sim.js'],changed
Path('/tmp/v18-crossing-isolation-manifest.json').write_text(json.dumps({'source':str(src),'original':str(base),'candidate':str(cand),'filesChecked':len(b),'onlyDifference':changed,'sourceHashes':{'original':b['shared/sim.js'],'candidate':c['shared/sim.js'],'test':b['test-engine-acceptance.js'],'server':b['server.js']},'deadlineAssertionsUnchanged':True,'allOriginal':b,'allCandidate':c},indent=2));print('prepared',len(b),'files sim-only difference')
