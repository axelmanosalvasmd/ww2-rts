from pathlib import Path
for label in ['original','candidate']:
 root=Path('/tmp/v18-crossing-'+label)
 server=(root/'server.js').read_text();needle='      const reason = command(room.game, slot, msg);';assert server.count(needle)==1
 server=server.replace(needle,needle+"\n      if(msg.t==='move')globalThis.__crossingReceipts?.push({tick:room.game.tick,slot,reason:reason??null,orders:msg.orders,units:msg.orders.map(([id])=>{const u=room.game.units.get(id);return{id,worldGoal:u.worldGoal,path:u.path}})});")
 (root/'server-network-receipts.js').write_text(server)
 s=(root/'test-engine-acceptance.js').read_text();s="import {writeFileSync} from 'node:fs';\nconst networkProof={receipts:[]};globalThis.__crossingReceipts=networkProof.receipts;\n"+s;s=s.replace("'./server.js'","'./server-network-receipts.js'")
 needle="    await left.send({ t: 'move', orders: orders[0] }); await right.send({ t: 'move', orders: orders[1] });\n    await tick(800);";assert s.count(needle)==1
 delay="""    const originalRightSend=right.ws.send.bind(right.ws), delayedMessages=[]; let rightDelayed=false;
    right.ws.send=(data,...args)=>{
      if(rightDelayed||JSON.parse(data).t==='move'){
        delayedMessages.push([data,args]);
        if(!rightDelayed){rightDelayed=true;setTimeout(()=>{rightDelayed=false;for(const [message,sendArgs]of delayedMessages.splice(0))originalRightSend(message,...sendArgs);},100);}
        return;
      }
      return originalRightSend(data,...args);
    };
"""
 after="""    networkProof.beforeStepping={tick:g.tick,units:[...targets].map(([id,target])=>{const u=g.units.get(id);return{id,target,position:[u.x,u.z],worldGoal:u.worldGoal,path:u.path}})};
    await tick(800);
    networkProof.afterStepping={tick:g.tick,units:[...targets].map(([id,target])=>{const u=g.units.get(id),client=target.owner===0?left:right;return{id,target,position:[u.x,u.z],worldGoal:u.worldGoal,path:u.path,delivered:row(client,id),plan:client.latest('s').plans.find(p=>p[0]===id)}})};
"""
 barrier="""    for(const client of[left,right]){
      const after=client.messages.length,c=`crossing-command-barrier-${client.token}`;
      await client.send({t:'ping',c});
      assert.equal((await client.wait('pong',after)).c,c,'ordered WebSocket pong confirms the preceding move was handled');
    }
"""
 for kind in ['delayed-no-barrier','delayed-with-barrier']:
  text=s.replace(needle,delay+"    await left.send({ t: 'move', orders: orders[0] }); await right.send({ t: 'move', orders: orders[1] });\n"+(barrier if kind.endswith('with-barrier') else '')+after)
  needle2='} finally {\n  server.clock.setTimeout';assert text.count(needle2)==1
  text=text.replace(needle2,"} finally {\n  writeFileSync('/tmp/v18-crossing-"+label+'-'+kind+"-proof.json',JSON.stringify(networkProof,null,2));\n  server.clock.setTimeout")
  (root/('test-engine-crossing-'+kind+'.js')).write_text(text)
