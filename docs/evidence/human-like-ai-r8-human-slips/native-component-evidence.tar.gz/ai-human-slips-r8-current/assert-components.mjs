import assert from 'node:assert/strict';
export function componentProof(raw) {
 const window = raw.authorFrames.filter(frame => frame.tick <= 120), id=9;
 assert.equal(window.length,12);
 for(const frame of window){const unit=frame.units.find(unit=>unit.id===id);assert.ok(unit&&unit.x===151&&unit.z===139&&unit.path===0&&unit.orders===0&&unit.targetId===0&&!unit.retreating);}
 assert.ok(raw.report.frames.filter(frame=>frame.tick<=120).every(frame=>frame.units.every(unit=>unit.id!==id)), 'the actual initially idle actor is outside the attended camera');
 assert.ok(raw.log.inputs.filter(input=>input.tick<=120).every(input=>!input.ids?.includes(id)), 'the off-screen idle actor receives no paid input in the initial six seconds');
 const at=tick=>raw.authorFrames.find(frame=>frame.tick===tick), start=at(150), end=at(350);
 assert.ok(end.resources[0].mp>start.resources[0].mp+50,'actual native income floats while the flank combat occupies play');
 assert.ok(raw.publicDiagnostics.find(frame=>frame.tick===340).publicMP>=100,'the seat receives its own affordable MP total through the real HUD');
 assert.ok(raw.log.commands.filter(row=>row.tick<=350).every(row=>row.resourcesAfter.mp===row.resourcesBefore.mp),'no MP expense explains away the retained float interval');
 assert.ok(raw.nativePhysics.some(frame=>frame.tick>=330&&frame.tick<=350&&frame.nativeShotRecords.some(shot=>shot.k==='flight'&&shot.f===9)),'ordinary native guard fire continues at the affordable float interval');
 const alert=raw.alertScore.requiredPopulation;
 assert.equal(alert.length,1);assert.equal(alert[0].createdAtTick,162);assert.ok(alert[0].completedTick>162);assert.equal(alert[0].censorTick,null);
 assert.ok(raw.alertScore.samples[0].observed);
 const input=raw.log.inputs.find(input=>input.tick===alert[0].completedTick&&input.kind==='camera-alert');
 assert.ok(input&&input.event?.id==='162:1'&&input.inputStartedTick>162&&input.tick>=input.inputStartedTick+input.motorTicks);
 assert.ok(raw.nativePhysics.some(frame=>frame.tick===162&&frame.nativeShotRecords.some(shot=>shot.k==='contact'&&shot.f===10&&shot.t===9&&shot.hit===true)), 'the later public flank cue comes from a real enemy weapon contact');
 assert.ok(raw.log.commands.some(row=>row.tick>162&&row.accepted&&row.command.t==='ability'&&row.command.ids.includes(id)),'the camera response leads to a paid accepted native guard action');
 assert.ok(raw.authoritativeEnd.units.find(unit=>unit.id===id).hp>0);
 return {level:raw.level,seed:raw.seed,seconds:raw.seconds,unnoticedNativeIdleAtLeastSeconds:6,firstWatchedTick:raw.report.frames.find(frame=>frame.units.some(unit=>unit.id===id)).tick,mpFloat:{startTick:150,startNativeMP:start.resources[0].mp,endTick:350,endNativeMP:end.resources[0].mp,publicMP340:raw.publicDiagnostics.find(frame=>frame.tick===340).publicMP,ongoingNativeFire:true},alert:{created:162,inputStarted:input.inputStartedTick,completed:input.tick,seconds:alert[0].seconds,observed:true,censor:null},manual:{required:raw.manualScore.requiredEvents,monitoring:raw.manualScore.monitoringEvents,censored:raw.manualScore.firstCompletedAction.censored,unknown:raw.manualScore.unknownEvents}};
}
export function quietProof(raw){assert.equal(raw.nativePhysics.length,0);assert.equal(raw.alertScore.samples.length,0);assert.equal(raw.manualScore.requiredEvents,0);assert.ok(raw.report.frames.some(frame=>frame.units.some(unit=>unit.id===9)),'ordinary eventless idle inspection still happens');return {level:raw.level,seed:raw.seed,eventlessAlerts:true,eventlessScreen:true,firstWatchedTick:raw.report.frames.find(frame=>frame.units.some(unit=>unit.id===9)).tick};}
