import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {componentProof,quietProof} from './assert-components.mjs';
const dir='/tmp/ai-human-slips-r8-current',read=async(name)=>JSON.parse(await readFile(`${dir}/${name}.json`));
const rows=[];for(const level of ['easy','normal','hard'])rows.push(componentProof(await read(`flank-${level}-seed1`)));
assert.deepEqual(await read('flank-hard-seed1-repeat'),await read('flank-hard-seed1'),'same authored native scene and seed repeat every complete raw row exactly');
const quiet=quietProof(await read('quiet-hard-seed1'));
await writeFile(`${dir}/component-results.json`,JSON.stringify({diagnosticOnly:true,status:'PASS bounded current-source component examples',campaignAcceptance:false,empiricalSlipFrequencyNotEstablished:true,authoredSlipRates:{easy:.5,normal:.3,hard:.15},rows,quiet,seededFullRawRepeatEqual:true},null,2));
console.log('PASS current native human-slip examples, exact seeded full trace repeat and quiet boundary');
