import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {run} from './source/episode-library.mjs';
const dir='/tmp/ai-human-slips-r8-current',d=JSON.parse(await readFile(`${dir}/preregistration.json`));
for(const [f,h]of Object.entries(d.sourceFiles))assert.equal(createHash('sha256').update(await readFile(`${dir}/source/${f}`)).digest('hex'),h.sha256);
for(const c of d.cases){const raw=await run(c.scene,c.level,c.seed);await writeFile(`${dir}/${c.scene}-${c.level}-seed1${c.repeat?'-repeat':''}.json`,JSON.stringify(raw));console.log(JSON.stringify({case:c,inputs:raw.log.inputs.length,alerts:raw.alertScore.samples,manual:raw.manualScore,commands:raw.log.commands.map(x=>({tick:x.tick,command:x.command,accepted:x.accepted}))}));}
for(const [f,h]of Object.entries(d.sourceFiles))assert.equal(createHash('sha256').update(await readFile(`${dir}/source/${f}`)).digest('hex'),h.sha256);
console.log('PASS exact source before/after bindings');
