import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
const dir=process.argv[2];if(!dir)throw Error('directory needed');
const sim=await import(`${dir}/shared/sim.js`),ai=await import(`${dir}/shared/ai.js`);
const map=JSON.parse(await readFile(`${dir}/maps/six-fronts.json`,'utf8'));
const rand=Math.random;let seed=0x3c1055;Math.random=()=>{let t=seed+=0x6D2B79F5;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296};
const g=sim.createGame(map,Array.from({length:6},(_,i)=>`Bench ${i+1}`),false,[0,1,2,3,4,5],[0,1,2,0,1,2],{mode:'conquest',army:'massive',weather:false,supply:false});
const commandRows=[],inputRows=[],snapshotHashes=[],rngRows=[],eventRows=[];
for(let slot=0;slot<6;slot++)ai.startCommander(g,slot,{w:g.w,h:g.h,spawn:g.players[slot].spawn,level:'normal',seed:g.matchSeed??g.seed});
const humanHashes=[]; const views=[];const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
for(let n=0;n<1000&&g.winner===null;n++){
 sim.step(g);
 if(g.tick%2===0){const cache=sim.snapshotCache(g);for(let i=0;i<6;i++){views[i]=ai.observe(g,i,cache);snapshotHashes.push([g.tick,i,hash(views[i].snapshot),hash([...views[i].units]),hash(views[i].points),hash(views[i].chars),hash(views[i].height)]);}}
 for(let i=0;i<6;i++)if(views[i])ai.think(g,i,{view:views[i],level:'normal',inputLog:row=>inputRows.push([g.tick,i,structuredClone(row)]),submit:cmd=>{const result=sim.command(g,i,cmd);commandRows.push([g.tick,i,structuredClone(cmd),result??null]);return result;}});
 rngRows.push([g.tick,...Array.from({length:6},(_,i)=>ai.aiScratchRng(g,i))]);
 if(g.tick%2===0){for(let i=0;i<6;i++)eventRows.push([g.tick,i,ai.aiDiagnostics(g,i)?.events??[]]);const shots=g.shots,newCells=g.newCells;g.shots=[];g.newCells=[];const cache=sim.snapshotCache(g);for(let i=0;i<6;i++)humanHashes.push([g.tick,i,hash(sim.snapshotFor(g,i,shots,newCells,cache))]);}
}
Math.random=rand;
console.log(JSON.stringify({source:dir,ticks:g.tick,winner:g.winner,commands:commandRows.length,inputs:inputRows.length,snapshots:snapshotHashes.length,events:eventRows.flatMap(r=>r[2]).length,digests:{humanSnapshots:hash(humanHashes),fog:hash([...g.fog]),commands:hash(commandRows),inputs:hash(inputRows),snapshots:hash(snapshotHashes),rng:hash(rngRows),events:hash(eventRows),game:hash({tick:g.tick,units:[...g.units],players:g.players,points:g.points,pathStats:g.pathStats,cellLog:g.cellLog})}}));
