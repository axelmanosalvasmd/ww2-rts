One prospective final R8 performance batch is prepared. Nothing was frozen, paused or timed. V21 and rejected v22 evidence remain unchanged. The final candidate includes actual R8 runtime changes and pending strict-subset selection; root must finish source and review its full manifest before drafting or freezing.

Runner: /tmp/human-ai-final-performance-protocol-r8-perf.py
Wrapper: /tmp/human-ai-r8-perf-quiet-wrapper.py
Pause inventory: /tmp/human-ai-performance-r8-perf-pause-plan.json
AST proof and hashes: /tmp/human-ai-r8-perf-preparation-proof.json
Thin diffs: append .diff to each Python script path.
Source binding: /tmp/human-ai-r8-perf-final-full-source
Final prospective draft: /tmp/human-ai-performance-r8-perf-preregistration-draft.json
Authorization: /tmp/human-ai-performance-r8-perf-authorization.json
Frozen declaration: /tmp/human-ai-performance-r8-perf-predeclared.json
Result: /tmp/human-ai-final-performance-protocol-r8-perf.json

The original fixed order is exact legacy, exact current, counts legacy, counts current. All rows use CPU6, case ai, six-fronts, six Normal seats, seed 0x3c1055, 1000 ticks, 10 excluded warmup ticks and 990 measured samples. AI p95/max allowances remain max(2 ms, 10% baseline); counts full ticks strictly greater than 40 ms cannot increase. Counts instrumentation is unchanged and only computes the final over40 statistic. Startup remains separately reported. Legacy 5293ddb runs on the identical final current engine. There are no extra variants or automatic retries.

Only versioned path strings changed in the runner. The wrapper additionally proposes ROOTS [1951992,1609687,1934835,1936262,1952084]. Its functions are AST-identical to the reviewed V21 guardian. The inventory records eight live owned processes: auxiliary guard; V16 supervisor/controller/merge; V21 balance supervisor/child; V21 humanity controller; lab server. Every identity includes PID, start time, UID, argv, cwd, thread IDs and affinity. Parent PID1028 is not owned or eligible. Future CPU4 full-suite work is not authorized for pause by this inventory.

Pause the auxiliary launch guard first. Its source can spawn a detached auxiliary campaign when current evidence completes. Any launch that races this snapshot requires a fresh reviewed inventory; the benchmark preflight refuses unpaused game workloads. Then stop supervisors before descendants, register each identity with the independent pidfd guardian before STOP, and verify every task is stopped. Unknown descendants abort and all registered jobs resume. The lab server may instead finish naturally before root launch.

The guardian resumes on finally, parent pipe EOF or its 60-second safety deadline. The native benchmark row has no wall-time cancellation. If the deadline or another quiet failure occurs, preserve and finish the current row, mark the attempt invalid and do not start later rows. Run the wrapper in a background session and poll with waits shorter than 60 seconds. Do not kill, trim, reset or modify any original campaign. Elapsed wall time includes pauses; simulation caps, streams and raw results remain unchanged.

Read-only source inspection found campaign 180-second simulation caps and elapsed reporting, a balance supervisor without an outer timeout, and an auxiliary poll/launch guard. The final source and pause identities must be reviewed again before root authorization. Root owns any source freeze and launch.

After final source copy, root may create the prospective declaration:

    python3 /tmp/human-ai-final-performance-protocol-r8-perf.py --draft

After exact source authorization, root may freeze:

    python3 /tmp/human-ai-final-performance-protocol-r8-perf.py --freeze-after-root-approval

Only after fresh identity review and explicit source/quiet/pause authorization bound to the exact runner, wrapper, pause plan and preregistration hashes may root launch:

    python3 /tmp/human-ai-r8-perf-quiet-wrapper.py --run-after-root-authorization

These commands have not been run. Current artifacts are preparation only.
