# Watched risk escalation during an older escape click

This is one short authored native gameplay diagnosis against current ROOT commander 54ac5736, hands d209f686, priority 8bf45be4. No ROOT file was edited. No campaign, full suite, scorer or timing gate was run or changed. All runs used CPU 3 and nice 19. The permanent test is portable through ordinary ROOT-relative imports.

## Actual defect and scope

The emergency filter compares a new event's fixed rank with the active job's stored priority. All screen damage has rank 103. A fresh watched risk crossing can therefore fail to preempt an older non-risk damage response for the same squad. This is distinct from the adopted held-pan release, persistent-selection Shift-click, diagonal pan and public inspection ordering fixes. It does not propose the previously rejected projection/cache optimization or a general equal-rank interrupt policy.

The authored Normal seed 27 scene has a rifle at (78,79), an enemy medium at (110,79), one owned point at (80,80), 20 MP and no munitions. Normal simulation steps, viewFor delivery, perceive, default think, native hands and sim.command run throughout. The first authored 35% hit at tick160 also supplies suppression99 before actual delivery. This is explicit scene authoring, not a claim that a real weapon produced that exact combination. It leaves the squad at 65%, pinned but not retreat-risk. The ordinary planner selects a useful available escape at (67,79).

At the first actual unpressed right-click approach for this damage response, an authored10% hit is delivered at tick168. The actual already selected rifle is now55%, still pinned. Native perception creates observed-screen:168:3 with retreatRisk true, autoRetreatCovered false, onScreen true. The new cue and the old job both rank103.

Baseline completes the older click174 and accepts the move. It then deliberates the new risk175–185. By185 normal suppression decay has dropped below pinned, so no manual retreat is issued during the20s scene. Candidate cancels only the unpressed approach, preserves real selection[7], and begins ordinary five-tick Normal deliberation. The sampled existing reaction deadline and complete existing R-key motor result in an accepted retreat179, eleven ticks or0.55s after creation. Neither canceled approach nor cancellation emits an input. This is useful gameplay, not a claim about V21 campaign medians or passing all acceptance bands.

## Proposed source change

runtime.patch adds a narrow public escalation predicate in ai-commander.js. Equal priority qualifies only when the new delivered on-screen damage explicitly has retreatRisk true, the active command is move/amove with that actual narrowed actor, and its primary older delivered screen-damage event explicitly had retreatRisk false for the same actor. The ordinary screenEventNeedsAttention check still rejects covered/retreating cues. Higher-priority behavior and all other equal-priority work remain unchanged. Existing interruptHands governs cancellation or required held-gesture completion. No motor, reaction, cap, RNG profile, information, economy or capture change is made.

## Proof and qualifications

Baseline test, candidate test and paired deep-comparison test pass. The same positive scene reruns exactly deterministically. Actual native physical starts/completions and command receipts prove real selection, cancellation before press, full key motor, a causal four-tick floor, immutable new creation identity and at most one command per tick. Baseline issues ten actual inputs and three native commands over20s. Candidate issues six actual inputs and three native commands. In the response window each completes one input: the useful R replaces the stale move. Later camera behavior differs because the squad is genuinely retreating. There is no APM increase.

Four full native negative scenes are deeply identical across versions: no risk crossing; a watched risk for a different actor; native automatic-retreat coverage; and a first cue already in retreat risk with an actual started retreat key. The last control checks preservation of the useful started key, not an independent second required risk episode. It deliberately does not claim broader equal-priority scheduling correctness.

Files: runtime.patch, test-engine-ai-risk-escalation.js, baseline-controls.json, candidate-controls.json, paired-summary.json, three test logs, and complete baseline/candidate source copies. The early invalid below-automatic-threshold setup is represented by the genuine automatic-covered negative, rather than claimed as a manual response defect. Baseline and candidate differ only in shared/ai-commander.js among their runtime files.

Reproduce:

    AI_ESCALATION_BASELINE=1 taskset -c 3 nice -n 19 node baseline/test-engine-ai-risk-escalation.js
    taskset -c 3 nice -n 19 node candidate/test-engine-ai-risk-escalation.js
    taskset -c 3 nice -n 19 node paired-proof.mjs

For adoption, apply runtime.patch and add the ordinary-relative test file. ROOT owns registration, docs and any full qualification.
