import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
// Physical contract control: author the earlier local escape as native G attack-move.
// Only its planner-admitted movement subtype changes. Cue creation and runtime modules remain native.
const runs=[];
for(const version of ['baseline','candidate']){
const root=new URL('/tmp/ai-equal-risk-delay/'+version+'/', 'file:///');
const sim=await import(new URL('shared/sim.js',root));
const perception=await import(new URL('shared/ai-perception.js',root));
const hands=await import(new URL('shared/ai-hands.js',root));
const view=await import(new URL('shared/ai-view.js',root));
const {createAIcase}=await import(new URL('tools/ai-lab-runner.mjs',root));
const aiURL=new URL('shared/ai.js',root),source=readFileSync(aiURL,'utf8');
const line='return runCommander(view, slot, { ...opts, tick: g.tick }, mem, send, plan);';
assert.equal(source.split(line).length,2);
const adapted=source.replace(line,`return runCommander(view, slot, { ...opts, tick: g.tick }, mem, send,
 (v,s,o,m,submit)=>plan(v,s,o,m,cmd=>submit(cmd.t==='move' && g.tick>=160 && o.concern?.event==='screen-damage'
   && o.concern?.observedDanger?.retreatRisk===false ? {...cmd,t:'amove'} : cmd)));`)
.replace(/from (['"])(\.[^'"]+)\1/g,(_all,q,p)=>'from '+q+new URL(p,aiURL).href+q);
const ai=await import('data:text/javascript;base64,'+Buffer.from(adapted).toString('base64'));
function nativeEscalation(control = 'risk') {
  const rows = [{ owner: 0, type: 'rifle', x: 78, z: 79, holdFire: true, autoRetreat: false }];
  if (control === 'other-actor') rows.push({ owner: 0, type: 'rifle', x: 84, z: 85, holdFire: true });
  rows.push({ owner: 1, type: 'medium', x: 110, z: 79, holdFire: true });
  const scene = { units: rows, points: [{ x: 80, z: 80, owner: 0 }],
    camera: { x: 80, z: 79, yaw: 0 },
    resources: [{ mp: 20, fuel: 0, mun: 0 }, { mp: 0, fuel: 0, mun: 0 }],
    cues: [{ kind: 'hit', tick: 160, unitId: 7, damage: control === 'already-risk' ? 45 : 35 }] };
  let memory, cue;
  const phases = [];
  const engine = { sim, perception, hands,
    ai: { ...ai, think(game, slot, opts) {
      memory = opts.memory;
      const result = ai.think(game, slot, opts);
      if (game.tick >= 158 && game.tick <= 210) {
        const state = memory.human, active = state.hands.active;
        const action = active?.actions[active.index];
        phases.push({ tick: game.tick, concern: state.concern?.id,
          deliberateUntil: state.deliberateUntil, noWorkUntil: state.noWorkUntil,
          activeKind: action?.kind, reacting: active?.reacting ?? false,
          priority: active?.job.context.priority, selected: [...state.hands.selected],
          dueTick: active?.due, activeCommand: active?.job.command,
          responseEvents: active?.job.context.responseEvents });
      }
      return result;
    } },
    view: { ...view, viewFor(game, slot, cache) {
      if (game.tick === 160) game.units.get(7).supp = 99;
      const state = memory?.human, active = state?.hands?.active;
      const action = active?.actions[active.index];
      const matching = active?.job.command?.t === 'amove' && action?.kind === 'attack-key';
      if (!cue && game.tick > 160 && active && !active.reacting && matching
        && active.job.context.event?.kind === 'screen-damage' && active.due > game.tick) {
        const actor = game.units.get(control === 'other-actor' ? 8 : 7);
        const amount = control === 'not-risk' || control === 'already-risk' ? 5
          : control === 'automatic-covered' ? 45 : control === 'other-actor' ? 45 : 10;
        actor.hp = Math.max(1, actor.hp - amount);
        if (control === 'other-actor') actor.supp = 99;
        game.shots.push({ k: 'hurt', t: actor.id, to: 0, fo: 1, x: actor.x, z: actor.z, kill: false });
        cue = { tick: game.tick, actorId: actor.id, amount, health: actor.hp,
          suppression: actor.supp, selection: [...state.hands.selected],
          activeCommand: structuredClone(active.job.command), activePriority: active.job.context.priority,
          originalDueTick: active.due, pointer: structuredClone(state.hands.pointer),
          authorNote: 'Authored hit at the first uncompleted issuing gesture answering the first damage cue.' };
      }
      return view.viewFor(game, slot, cache);
    } } };
  const lab = createAIcase(engine, { scenario: 'guard', level: 'normal', seed: 27, seconds: 20 }, scene);
  lab.advance(400);
  return { scene, control, cue, phases, trace: lab.record() };
}

const result=nativeEscalation();runs.push({version,result,sourceSHA256:createHash('sha256').update(source).digest('hex')});
}
writeFileSync(new URL('./raw.json',import.meta.url),JSON.stringify(runs,null,2));
for(const row of runs){
const {result}=row;assert.ok(result.cue,'an actual older G-key gesture receives the new risk crossing');
const key=result.trace.inputs.find(i=>i.kind==='attack-key'&&i.tick>=result.cue.tick);
assert.ok(key,'the held actual G completes after delivery');
assert.equal(key.tick,result.cue.originalDueTick,'interruption preserves the existing complete key motor');
assert.ok(!result.trace.commands.some(i=>i.tick===key.tick),'G alone creates no gameplay receipt');
}
const candidate=runs[1].result;
const phase=candidate.phases.find(row=>row.tick===candidate.cue.tick);
assert.equal(phase.activeKind,'attack-key','the new escalation branch preserves the already started key');
assert.ok(!candidate.trace.commands.some(row=>row.tick>=candidate.cue.tick&&row.command.t==='amove'),'the later issuing click is discarded');
const response=candidate.trace.commands.find(row=>row.accepted&&row.command.t==='retreat');
assert.ok(response,'the actual new risk still gets an accepted native retreat');
assert.ok(response.tick>=candidate.cue.tick+4,'the new causal floor is preserved');
assert.ok(candidate.trace.inputs.find(i=>i.tick===response.tick&&i.kind==='retreat-key'));
console.log(JSON.stringify(runs.map(row=>({version:row.version,cue:row.result.cue,inputs:row.result.trace.inputs.filter(i=>i.tick>=160&&i.tick<200),commands:row.result.trace.commands.filter(i=>i.tick>=160&&i.tick<200)})),null,2));
