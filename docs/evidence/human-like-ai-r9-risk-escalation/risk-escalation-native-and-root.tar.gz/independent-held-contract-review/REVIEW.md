# Independent review: equal-rank watched risk escalation

Approve the narrow candidate for a later ROOT slice, subject to the normal focused and full suite gates. No correctness blocker found in the proposed runtime change. ROOT and the candidate artifacts were not edited.

I verified all86 original manifest member hashes, compared both complete native control objects directly, and checked that the only baseline/candidate runtime difference is ai-commander.js. The original four controls are fully identical. The positive native scene preserves the complete pre-escalation input prefix: actual selection116 and stance119. It changes the stale accepted move174 into a real accepted retreat179 after the risk cue168. The full selection, original reaction sampling, Normal five-tick deliberation and complete R-key motor remain paid. This is one authored native scene, not a campaign or acceptance-median result.

Source evidence:

- Candidate ai-commander.js:22–30 requires actual new on-screen screen-damage, explicit public retreatRisk true, an active move/amove whose narrowed actual job.ids contains the same unit, and an older public primary screen-damage descriptor for that unit with retreatRisk false. No responseRequired, responseUnits, manual-policy label, private counterfactual field, raw game state or future event is consulted.
- Commander:264–271 enables this only at equal priority and retains screenEventNeedsAttention. Higher urgency follows the existing path. Attention:52–57 still rejects already-retreating and automatic-covered risk. The new event is recorded in interruptEvents before advanceHands, preventing repeated treatment between deliveries.
- Perception:295–305 emits a watched risk crossing only from actual consecutive delivered own-screen health/suppression; risk uses public fair health and pinned categories. dangerFor at435–437 supplies the same public risk and automatic coverage. The patch does not alter creation, debounce, bands or grading populations.
- Hands:736–740 narrows job.ids, native movement rows and causal context together when selection changes. The candidate checks that current list, not the original queued roster. All actual movement jobs have ids arrays from enqueueOne:328 and373, so includes does not introduce a native undefined-array path.
- Hands:965–997 preserves held keys, drags and modifier bundles through the existing completion path, while updating and canceling unpressed pointer approach without a fabricated input. The patch does not directly clear active jobs or alter reaction/cap/motor functions.

The retained already-risk negative is an active retreat rather than a movement. It therefore does not exercise started-key completion after the new predicate succeeds. I filled that specific gap with one independent physical-contract control, using the same native scene and actual runtime modules. The test-only planner wrapper authors the earlier local escape as native G attack-move instead of move. It changes no candidate file, membership, target geometry, cue criteria, reaction timing or input duration. This is a qualified planner-decision control, not a natural default-planner claim.

That actual new risk cue172 arrives during a G-key motor started170, due173. Candidate preserves G completion173, discards the later issuing click, pays a real Esc cancellation186, then accepts native retreat190 with the new cue identity. Baseline completes G173 and accepted amove181. Thus started motor and targeting cancellation remain physical and the new cue retains its four-tick causal floor. The control retains source/raw/log artifacts in this directory. Its first syntax-only script failure is also retained and is not gameplay evidence.

Qualifications and small optional follow-ups:

- The original not-risk and already-risk controls produce no second public screen-damage event due to existing debounce. They prove full native parity in those authored scenes, not every possible fresh equal-rank non-risk event. The explicit new-risk boolean guard provides the source-level exclusion.
- The escalation only compares the active primary event, and requires its original descriptor still in the bounded public view.events history. A secondary damage link or an evicted older descriptor will conservatively miss this exception. That limits response coverage but does not cause false cancellation. General secondary-link or history changes should be a separate justified proposal.
- Defensive optional-array syntax for job.ids is unnecessary for current native enqueue invariants. No membership robustness edit is required for this patch.
- Independence is verified for the new decision rule and its existing attention filter. This review does not claim every historical commander rule is independent of every diagnostic field, nor does it certify whole-match timing, performance or numeric gates.

Original artifact source: baseline commander54ac5736, candidate03a8b1aa, handsd209f686, priority8bf45be4. Original manifest and both complete controls remain byte-identical after review. Independent control and hash audit finished without a full match or broad test rerun.
