import assert from 'node:assert/strict';import fs from 'node:fs';import {createHash} from 'node:crypto';
const b=JSON.parse(fs.readFileSync(new URL('./baseline-controls.json',import.meta.url))),c=JSON.parse(fs.readFileSync(new URL('./candidate-controls.json',import.meta.url)));
const controls=[];
for(let i=0;i<b.controls.length;i++){
 const x=b.controls[i],y=c.controls[i];
 if(['cooling','light-tank','infantry'].includes(x.control)){assert.deepEqual(x,y);controls.push({name:x.control,scope:'complete native scene',deepEqual:true});}
 else {
  const until=x.control==='offscreen'?x.trace.frames.find(f=>f.units.some(u=>u.id===8)).tick:x.trace.inputs.find(r=>r.kind==='select-click').tick;
  const other=y.control==='offscreen'?y.trace.frames.find(f=>f.units.some(u=>u.id===8)).tick:y.trace.inputs.find(r=>r.kind==='select-click').tick;assert.equal(until,other);
  for(const k of ['inputs','inputStarts','commands','events','frames'])assert.deepEqual(x.trace[k].filter(r=>r.tick<until),y.trace[k].filter(r=>r.tick<until));
  controls.push({name:x.control,scope:'native prefix before actual exposure/selection',until,deepEqual:true});
 }
}
const sha=p=>createHash('sha256').update(fs.readFileSync(new URL(p,import.meta.url))).digest('hex');
const ready=r=>r.phases.find(p=>p.cooldownKnown&&p.cooldown===0).tick;
const outcome=r=>({readyTick:ready(r),acceptedAPTick:r.trace.commands.find(c=>c.command.t==='ability').tick,physicalInputs:r.trace.inputs.length,commands:r.trace.commands.length,publicEnemyHP136:r.trace.frames.find(f=>f.tick===136).units.find(u=>u.id===8)?.hp,nativeAPReceipt:r.receipts[0]});
const summary={diagnosticOnly:true,baseCommander:sha('./baseline/shared/ai-commander.js'),baseAttention:sha('./baseline/shared/ai-attention.js'),candidateAttention:sha('./candidate/shared/ai-attention.js'),baseline:outcome(b.result),candidate:outcome(c.result),controls};
fs.writeFileSync(new URL('./paired-summary.json',import.meta.url),JSON.stringify(summary,null,2));console.log('PASS native parity controls, truthful AP-ready/effect comparison and unchanged useful input counts.');
