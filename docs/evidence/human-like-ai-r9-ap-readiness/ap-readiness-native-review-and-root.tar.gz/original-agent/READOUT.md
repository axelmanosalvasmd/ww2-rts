# Ready AP was omitted from deferred-combat wakeup

This is a bounded authored native gameplay diagnosis, not an acceptance population or reaction score. No ROOT files were edited. All short runs used CPU 3 and nice 19. No match campaign, performance run, scorer change or full suite was started.

The copied source is AI 685c1787, commander 54ac5736, hands d209f686, priority 8bf45be4 and attention a5527224. The source snapshot predates ROOT's independent equal-risk commander adoption. The proposed patch touches only attention and applies cleanly to current ROOT. The positive scene creates no own damage and does not exercise that separate risk change.

## Source defect

The current planner permits AP against an actually watched non-air, non-infantry, non-structure vehicle, respecting naval restrictions. Attention's abilityOpportunity still recognizes only target.type === 'tank'. For a visible medium, emptyCombatFacts therefore keeps both opportunity/ready columns false even when an actually selected gun's HUD changes from cooling to ready. combatWorkAppeared cannot reopen the deferred visit for that readiness change.

runtime.patch replaces this one stale type restriction with the exact existing planner target predicate. The current cooldown-known, munitions, actor occupancy and actual screen-enemy membership checks stay in place. This adds no new planning target, hidden fact, input or resource advantage.

## Native qualifying scene

Hard seed 27, 12 simulated seconds. One authored AT gun at (78,79), AP initially cooling for five seconds, automatic retreat initially disabled. One medium at (106,79), authored held fire. Camera (80,79), no points, zero MP/fuel, 100 munitions. Ordinary engine steps, viewFor delivery, perceive, default think, actual hands and native sim.command run throughout. No planner shortcut or injected event is used.

The commander selects the gun through a paid click at 78, then accepts its genuine automatic-retreat stance at 80. The selected HUD first displays AP ready at 102. An empty combat area recorded at 92 is deferred until 152. Baseline repeatedly selects observe and leaves the ready opportunity unused. An independent native shot changes the enemy's public health band at 136; this eventually reopens combat and AP is accepted at 149.

Candidate recognizes the visible ready opportunity when the existing no-work pause ends at 111. The commander pays ordinary deliberation through 117, dispatches the original full key motor at 118 and accepts AP at 120. The native receipt enables own AP and sets its actual 45-second cooldown. The next real shot leaves the enemy at 180 public HP at 136, compared with baseline 240. Both versions complete exactly three physical inputs and two accepted commands. No APM padding occurs. Conquest AP is actually free, so munitions remain 100 in both receipts.

The 102-to-120 interval is a readiness diagnostic, not an authored manual-response event or accepted reaction sample. It does not pass or replace any Hard reaction/APM gate. Original campaign numbers remain unchanged.

## Proof

Portable test-engine-ai-ap-readiness.js uses ordinary relative ROOT imports. It proves complete native determinism, actual paid selection before cooldown knowledge, a real deferred area at readiness, actual visible target, a native accepted AP effect, full key motor, first-order opening and one command per tick. The same test qualifies the archived baseline under AI_AP_BASELINE=1.

Cooling, infantry and existing light-tank controls are deeply identical over complete native episodes across versions. An adjacent-camera control keeps the gun visible and delivers the medium only as an anonymous minimap dot; all native views, creations, physical starts/inputs and commands are identical until real exposure at 48, with no preceding AP. An unknown-cooldown control changes the author's raw own cooldown from five to zero; both versions preserve identical actual public/actions prefixes until the real selection at 78. Changes after actual exposure or selected HUD knowledge are permitted and are not claimed as invariant.

Exploratory four-second and seven-second cooldown probes are retained. The four-second case became ready at the first selected-HUD reading, so it did not show the deferred-readiness defect. The seven-second case reopened from an independent enemy health change near readiness, masking the additional delay. Neither is counted as a positive timing sample. The final five-second scene isolates the missed wakeup before that independent health change. Initial test packaging omitted the authored false auto-retreat flag; correcting it restores the exact already recorded native scene rather than changing a gameplay expectation. A proposed zero-munition negative was discarded because real Conquest AP costs zero; no fake economy assertion remains.

Files: runtime.patch, the portable test, baseline-controls.json and candidate-controls.json with complete native timelines, paired-summary.json, three passing logs, failed exploratory probe artifacts and complete source copies. Baseline and candidate runtime source differ only in shared/ai-attention.js.

Reproduce:

    AI_AP_BASELINE=1 taskset -c 3 nice -n 19 node baseline/test-engine-ai-ap-readiness.js
    taskset -c 3 nice -n 19 node candidate/test-engine-ai-ap-readiness.js
    taskset -c 3 nice -n 19 node paired-proof.mjs

ROOT owns adoption, registration, docs and current full qualification. No further variants are planned.
