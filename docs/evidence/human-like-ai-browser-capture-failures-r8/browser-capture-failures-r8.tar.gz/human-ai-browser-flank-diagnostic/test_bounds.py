import json,pathlib,subprocess,sys,time,os
base=pathlib.Path(__file__).parent;run=base/('bound-proof-'+str(time.time_ns()));run.mkdir();helper=base/'bounded_process.py';marker=run/'native-start.json'
# A separate supervisor watches a native start marker while the calling CLI blocks.
server=subprocess.Popen([sys.executable,str(helper),'--out',str(run/'server'),'--seconds','.35','--start-marker',str(marker),'--preparation-seconds','2','--',sys.executable,'-c','import signal,time;signal.signal(signal.SIGINT,signal.SIG_IGN);signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(30)'])
time.sleep(.1);marker.write_text('{}')
cli=subprocess.run([sys.executable,str(helper),'--out',str(run/'blocked-cli'),'--seconds','3','--',sys.executable,'-c','import time;time.sleep(30)'])
server.wait(timeout=2)
s=json.loads((run/'server/result.json').read_text());c=json.loads((run/'blocked-cli/result.json').read_text())
assert s['deadline'] and c['deadline'];assert s['elapsed']<2.7 and c['elapsed']<3.5;assert s['elapsed']<c['elapsed'];assert server.returncode==cli.returncode==124
for row in [s,c]:
 try:os.kill(row['pid'],0)
 except ProcessLookupError:pass
 else:raise AssertionError('owned child still exists')
# Positive ordinary completion is not turned into a timeout.
ok=subprocess.run([sys.executable,str(helper),'--out',str(run/'positive'),'--seconds','2','--',sys.executable,'-c','print("ordinary completed")']);assert ok.returncode==0
proof={'test':'independent deadline while CLI blocked; ignored INT/TERM escalates; ordinary completion','server':s,'blockedCLI':c,'path':str(run),'pass':True}
(base/'bound-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
