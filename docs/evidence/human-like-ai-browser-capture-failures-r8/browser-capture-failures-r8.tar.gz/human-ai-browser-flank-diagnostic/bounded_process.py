#!/usr/bin/env python3
"""Own one child process group. Capture directly; never retry an operation."""
import argparse,datetime,json,os,pathlib,signal,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--seconds',type=float,required=True);p.add_argument('--start-marker');p.add_argument('--preparation-seconds',type=float,default=180);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
cmd=a.command[1:] if a.command[:1]==['--'] else a.command
if not cmd: p.error('child command required')
out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=False)
started=time.monotonic(); events=[]
def event(kind,**fields):
 row={'wall':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed':time.monotonic()-started,'kind':kind,**fields};events.append(row)
 with (out/'events.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 child=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True)
 event('started',pid=child.pid,pgid=child.pid,command=cmd)
 marker=pathlib.Path(a.start_marker) if a.start_marker else None
 deadline=started+(a.preparation_seconds if marker else a.seconds);armed=not marker
 try:
  while child.poll() is None:
   if marker and not armed and marker.exists():
    # Marker must be written by native start callback, not a browser poll.
    armed=True;deadline=min(deadline,time.monotonic()+a.seconds);event('match-marker',path=str(marker))
   if time.monotonic()>=deadline:
    event('deadline',armed=armed)
    for sig,grace in [(signal.SIGINT,1),(signal.SIGTERM,1),(signal.SIGKILL,1)]:
     # This group was created by this supervisor. PID is not obtained from a port.
     if child.poll() is not None:break
     os.killpg(child.pid,sig);event('signal',signal=sig.name)
     try:child.wait(timeout=grace)
     except subprocess.TimeoutExpired:pass
    break
   time.sleep(.025)
 finally:
  if child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait()
  event('exited',exit=child.returncode)
summary={'command':cmd,'pid':child.pid,'exit':child.returncode,'deadline':any(e['kind']=='deadline' for e in events),'elapsed':time.monotonic()-started}
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
raise SystemExit(124 if summary['deadline'] else (child.returncode if child.returncode>=0 else 1))
