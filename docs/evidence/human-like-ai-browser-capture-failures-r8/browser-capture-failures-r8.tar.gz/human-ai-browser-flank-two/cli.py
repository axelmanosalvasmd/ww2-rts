import pathlib,subprocess,sys,os,time
b=pathlib.Path(__file__).parent;n=str(time.time_ns());env=os.environ.copy();env['AGENT_BROWSER_DEBUG']='1'
args=['agent-browser','--session','one-native-flank-two','--profile',str(b/'chrome-profile'),*sys.argv[1:]]
seconds='30' if sys.argv[1:2]==['open'] else '15'
r=subprocess.run([sys.executable,str(b/'bounded_process.py'),'--out',str(b/('cli-'+n)),'--seconds',seconds,'--','taskset','-c','5','nice','-n','19',*args],env=env)
for name in ['stdout.log','stderr.log']:print((b/('cli-'+n)/name).read_text(),end='')
if r.returncode:(b/'abort').touch()
raise SystemExit(r.returncode)
