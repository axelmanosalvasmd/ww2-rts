import os,pathlib,json,time,signal,datetime,shlex
base=pathlib.Path('/tmp/human-ai-browser-flank-two');session='one-native-flank-two';profile=str(base/'chrome-profile');own={};started=time.monotonic();deadline=started+180;armed=False
log=(base/'browser-watchdog.jsonl').open('a',buffering=1)
def emit(kind,**kw):log.write(json.dumps({'wall':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':kind,**kw})+'\n')
def read(pid):
 try:
  p=pathlib.Path('/proc')/str(pid);argv=[v for v in (p/'cmdline').read_bytes().decode().split('\0') if v];argv=shlex.split(argv[0]) if len(argv)==1 and ' ' in argv[0] else argv;stat=(p/'stat').read_text().rsplit(')',1)[1].split();return {'pid':pid,'uid':p.stat().st_uid,'start':stat[19],'ppid':int(stat[1]),'argv':argv}
 except (OSError,ValueError):return None
emit('started',uid=os.getuid(),session=session,profile=profile)
while True:
 rows=[r for p in pathlib.Path('/proc').iterdir() if p.name.isdigit() and (r:=read(int(p.name)))]
 for r in rows:
  if r['uid']!=os.getuid():continue
  args=r['argv'];joined=' '.join(args)
  daemon_env=(pathlib.Path('/proc')/str(r['pid'])/'environ').read_bytes().split(b'\0') if args and 'agent-browser' in pathlib.Path(args[0]).name else []
  root=(args and 'chrome' in pathlib.Path(args[0]).name and ('--user-data-dir='+profile in args or any(args[i:i+2]==['--user-data-dir',profile] for i in range(len(args)-1)))) or (args and 'agent-browser' in pathlib.Path(args[0]).name and ('AGENT_BROWSER_SESSION='+session).encode() in daemon_env)
  parent=own.get(r['ppid']);same=own.get(r['pid'])
  if root or parent and read(r['ppid']) and read(r['ppid'])['start']==parent['start']:
   if not same:own[r['pid']]=r;emit('owned',**r);os.sched_setaffinity(r['pid'],{5})
 if own:(base/'browser-owned-ready.json').write_text(json.dumps(list(own.values()),indent=2))
 if not armed and (base/'actual-start.json').exists():armed=True;deadline=min(deadline,time.monotonic()+45);emit('match-armed')
 if (base/'abort').exists() or (base/'done').exists() or time.monotonic()>=deadline:break
 time.sleep(.1)
for sig in [signal.SIGTERM,signal.SIGKILL]:
 for pid,r in reversed(list(own.items())):
  now=read(pid)
  if now and now['uid']==r['uid'] and now['start']==r['start'] and now['argv']==r['argv']:
   try:os.kill(pid,sig);emit('signal',pid=pid,signal=sig.name,verified=now)
   except ProcessLookupError:pass
 time.sleep(.5)
emit('finished',remaining=[r for pid in own if (r:=read(pid)) and r['start']==own[pid]['start']])
