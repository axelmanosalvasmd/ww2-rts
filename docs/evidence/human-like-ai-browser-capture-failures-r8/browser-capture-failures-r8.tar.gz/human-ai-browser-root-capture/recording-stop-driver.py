import pathlib,time,subprocess,json
b=pathlib.Path(__file__).parent
started=time.monotonic()
while not (b/'actual-start.json').exists() and time.monotonic()-started<100:
 time.sleep(.05)
if not (b/'actual-start.json').exists():raise SystemExit(1)
time.sleep(25)
r=subprocess.run(['python3',str(b/'cli.py'),'record','stop'],capture_output=True,text=True)
(b/'scheduled-record-stop.log').write_text(r.stdout+r.stderr)
(b/'scheduled-record-stop-result.json').write_text(json.dumps({'exit':r.returncode,'wall':time.time(),'afterNativeStartSeconds':25,'qualified':'Stop scheduled25s after observing the native start marker; actual wall duration remains in movie/CLI logs.'},indent=2)+'\n')
