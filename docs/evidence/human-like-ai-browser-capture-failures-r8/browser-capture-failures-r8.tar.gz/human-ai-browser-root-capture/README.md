# ROOT recording qualification

The retained movie is570963 bytes. Existing probe and record-stop receipts report58.666667 seconds,352 encoded frames and290 captured frames. Inspected frames33,40 and48 show the lobby; frame55 shows Controls. The video is playable but does not show readable gameplay overlays, a fight and later paid camera arrival. Lobby and static preflight alone do not satisfy that visual requirement.

Recording stop completed2026-10-05T02:03:47.613774Z. The next snapshot began02:03:48.137804Z, so the calls did not overlap. That snapshot hit its15-second deadline and was interrupted by its helper. Earlier watchdog logging ended02:00:15.844105Z with a native ProcessLookupError at sched_setaffinity because the observed process exited. The independently owned close later exited0 and found no remaining profile processes. This does not certify the failed watchdog.

Actual server start was02:03:20.484Z. Its independent supervisor sent owned SIGINT at02:03:51.357621Z and recorded exit0, under the150-second preparation deadline and45-second native cap. The final diagnostic tick was615. A legal human attack-move was sent four seconds after start. The first native weapon contact appeared around8.4 simulation seconds. Those facts come only from authoritative diagnostic logs, not the visible recording.

The eight recorded source components were equal before and after. Their matching physical ROOT copies are retained separately. This binds this failed capture to its recorded source; it is not a visual or population acceptance pass.
