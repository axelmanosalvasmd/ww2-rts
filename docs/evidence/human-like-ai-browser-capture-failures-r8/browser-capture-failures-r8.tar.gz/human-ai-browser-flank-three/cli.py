import pathlib,subprocess,sys,os,time,json,hashlib
b=pathlib.Path(__file__).parent
if (b/'abort').exists():
 print('Aborted attempt: no subsequent CLI command allowed',file=sys.stderr);raise SystemExit(125)
n=str(time.time_ns());cfg=json.loads((b/'immutable-cli-config.json').read_text());env=os.environ.copy();env.update(cfg['environment']);args=cfg['argv']+sys.argv[1:]
seconds='30' if sys.argv[1:2]==['open'] else '15'
out=b/('cli-'+n);r=subprocess.run([sys.executable,str(b/'bounded_process.py'),'--out',str(out),'--seconds',seconds,'--','taskset','-c','5','nice','-n','19',*args],env=env)
(out/'effective-config.json').write_text(json.dumps({'base':cfg,'command':args},indent=2)+'\n')
for name in ['stdout.log','stderr.log']:print((out/name).read_text(),end='')
if r.returncode:(b/'abort').touch()
raise SystemExit(r.returncode)
