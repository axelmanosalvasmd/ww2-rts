import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import * as sim from '../source/shared/sim.js';
import {viewFor} from '../source/shared/ai-view.js';
function run(clear) {
  const originalRandom=Math.random;let state=42;Math.random=()=>{state=Math.imul(state,1664525)+1013904223|0;return(state>>>0)/4294967296;};
  try {
  const map={w:96,h:96,rows:Array(96).fill('.'.repeat(96)),spawns:[{x:20,y:20},{x:85,y:85}],points:[]};
  const g=sim.createGame(map,['Own','Enemy'],false,[0,1],[0,1],{weather:false});g.units.clear();g.seed=42;
  for(const[slot,x]of[[0,78],[1,96]]) {g.players[slot].mp=5000;assert.equal(sim.command(g,slot,{t:'buy',unit:'mg'}),undefined);const u=[...g.units.values()].at(-1);Object.assign(u,{x,z:79,auto:false,autoRetreat:false,holdFire:false});}
  const memory={}, rows=[];
  for(let i=0;i<80;i++) {
    sim.step(g);
    if(g.tick===5)assert(sim.mutateWorldCell(g,40*g.w+41,{object:'T'}),'real authored terrain edit');
    if(g.tick%2!==0)continue;
    const observation=viewFor(g,0,memory,sim.snapshotCache(g));
    rows.push({tick:g.tick,rawShots:g.shots.length,deliveredShots:observation.snapshot.shots.length,rawCells:g.newCells.length,knownTrench:observation.chars[40*g.w+41]==='T',hp:[...g.units.values()].map(u=>[u.id,u.hp])});
    if(clear){g.shots=[];g.newCells=[];}
  }
  return rows;
  } finally {Math.random=originalRandom;}
}
const retained=run(false),batched=run(true);
assert(retained.some(row=>row.deliveredShots>0),'actual native weapon events are delivered');
assert(retained.some((row,i)=>row.deliveredShots>batched[i].deliveredShots),'retained transients replay prior public events');
assert.deepEqual(retained.map(row=>row.hp),batched.map(row=>row.hp),'view buffering does not change authoritative weapon results');
assert.deepEqual(retained.map(row=>row.knownTrench),batched.map(row=>row.knownTrench),'clearing transient cells preserves durable terrain delivery');
assert(batched.find(row=>row.tick===6).knownTrench,'real authored terrain change reaches the next observation');
const summary={retainedDeliveredRows:retained.reduce((n,r)=>n+r.deliveredShots,0),batchedDeliveredRows:batched.reduce((n,r)=>n+r.deliveredShots,0),retainedFinalRawShots:retained.at(-1).rawShots,batchedFinalRawShots:batched.at(-1).rawShots,retainedFinalRawCells:retained.at(-1).rawCells,batchedFinalRawCells:batched.at(-1).rawCells};
await writeFile(new URL('./native-proof.json',import.meta.url),JSON.stringify({diagnosticOnly:true,fixture:'two real MGs, native automatic fire; asserted authored trench edit at tick5; native viewFor each2ticks',retained,batched,summary},null,2));
console.log('Native transient delivery PASS',JSON.stringify(summary));
