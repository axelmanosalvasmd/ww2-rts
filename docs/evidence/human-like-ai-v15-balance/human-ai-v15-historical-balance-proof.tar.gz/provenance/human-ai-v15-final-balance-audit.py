import json,pathlib,hashlib,datetime,importlib.util,tarfile,subprocess,difflib,collections,os
ROOT=pathlib.Path('/tmp/human-ai-v15-final-balance');OUT=pathlib.Path('/tmp/human-ai-v15-historical-balance-audit');OUT.mkdir(exist_ok=False)
SRC=pathlib.Path('/tmp/human-ai-v15-full-source'); WORK=pathlib.Path('/home/judiazm/.t3/worktrees/ww2-rts/ai-human-commander')
spec=importlib.util.spec_from_file_location('supervisor','/tmp/human-ai-v15-balance-supervisor.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=json.loads(pathlib.Path('/tmp/human-ai-prospective-v15-balance.json').read_text());manifest=json.loads(pathlib.Path('/tmp/ai-v15-full-before.json').read_text());s=json.loads((ROOT/'supervision.json').read_text());checks={};jobs={};runtime=set();assert s.get('finishedAtUTC') and not s['sourceChanges'];assert not m.verify(p)['mismatches']
for n,j in p['jobs'].items():
 d=json.loads(pathlib.Path(j['json']).read_text());c=json.loads((ROOT/(n+'-checkpoint.json')).read_text());lines=pathlib.Path(j['log']).read_text().splitlines();logged=[json.loads(x[7:]) for x in lines if x.startswith('RESULT ')]
 assert logged==[d] and c['results']==d['results'] and c['sourceSHA256']==d['sourceSHA256'];m.validate_sources(c,p);r=m.reduce_rows(d['results'],j,True)
 assert s['jobs'][n]['status']=='finished' and s['jobs'][n]['exitCode']==0 and s['jobs'][n]['audit']['independentReduction']==r
 for k in ['mode','map','matches','seed','rotate','army','maxSeconds']:assert d[k]==j.get(k,c['configuration'].get(k)),k
 assert d['workers']==3 and d['players']==(2 if j['seats'] else 3) and d['resumedMatches']==0
 for row in d['results']:
  assert row['winner'] is not None and row['winner'] in range(-1,d['players'])
  assert len(row['spawns'])==d['players'] and len(row['vp'])==d['players']
  if row['winner']>=0:
   assert row['winnerSpawn']==row['spawns'][row['winner']]
   index=row['match']-1;pair=[index%3,index//3%3];order=[1,0] if j['rotate'] and index%2 else list(range(d['players']))
   assert row['winnerSeat']==order[row['winner']]
   faction=pair[row['winnerSeat']] if j['rotate'] else row['winner']%3
   assert row['winnerFaction']==['USA','Germany','USSR'][faction]
  else:assert row['winnerSeat'] is None and row['winnerFaction'] is None and row['endReason']=='draw'
 for path in d['sourceSHA256']:runtime.add(str(pathlib.Path(path).relative_to(SRC)))
 spawn=[{'spawn':i,'x':x['x'],'y':x['y'],'wins':sum(row['winnerSpawn']==i for row in d['results'])} for i,x in enumerate(json.loads((SRC/'maps/default.json').read_text())['spawns'])];assert spawn==d['winsBySpawn']
 for k in ['ended','draws','timeouts','winsByFaction','winsBySeat','medianSeconds','medianEndedSeconds']:assert d[k]==r[k]
 jobs[n]={'metrics':r,'originalRows':d['results'],'maxSeconds':d['maxSeconds'],'elapsedSeconds':d['elapsedSeconds'],'runnerSourceSHA256':d['sourceSHA256'],'checks':{'reportEqualsSingleLogResult':True,'rowsAndSourceEqualCheckpoint':True,'exactUniqueOriginalSeeds':True,'independentReducerMatches':True,'seatFactionAndSpawnRotationVerified':True,'workerAndConfigurationMatchPredeclared':True,'allOutcomesRetained':True}}
comparisons={};baselinepaths={'conquest':'/tmp/human-ai-before-conquest.json','classic':'/tmp/human-ai-before-classic-corrected.json'}
for n,path in baselinepaths.items():
 before=json.loads(pathlib.Path(path).read_text());after=json.loads((ROOT/(n+'.json')).read_text());r=m.reduce_rows(before['results'],p['jobs'][n],True)
 for k in ['mode','map','matches','seed','maxSeconds','players','army','seats','rotate']:assert before[k]==after[k]
 for k in ['ended','draws','timeouts','winsByFaction','winsBySeat','medianSeconds','medianEndedSeconds']:assert before[k]==r[k]
 assert [x['spawns'] for x in before['results']]==[x['spawns'] for x in after['results']]
 comparisons[n]={'baselinePath':path,'metricsBefore':r,'metricsAfter':jobs[n]['metrics'],'winsDelta':{f:after['winsByFaction'][f]-before['winsByFaction'][f] for f in r['winsByFaction']},'medianSecondsDelta':after['medianSeconds']-before['medianSeconds'],'sameOriginalSeedsMapSpawnsArmyFactionsAndLimits':True,'pairedRows':[{'match':a['match'],'seed':a['seed'],'before':b,'after':a} for b,a in zip(before['results'],after['results'])]}
legacy=json.loads((SRC/'tools/legacy-ai/provenance.json').read_text());legacychecks={}
for file,h in legacy['hashes'].items():
 original=subprocess.check_output(['git','show',legacy['commit']+':shared/'+file],cwd=WORK);frozen=(SRC/'tools/legacy-ai'/file).read_bytes();assert hashlib.sha256(original).hexdigest()==h['originalSHA256'] and hashlib.sha256(frozen).hexdigest()==h['frozenSHA256']
 delta=list(difflib.unified_diff(original.decode().splitlines(True),frozen.decode().splitlines(True)));changed=[x for x in delta if x[:1] in '+-' and not x.startswith(('+++','---'))];assert all('import ' in x or ' from ' in x for x in changed)
 legacychecks[file]={'originalAndFrozenHashesVerified':True,'onlyImportLinesDiffer':True}
sharedchanges=[];baseline_tar=pathlib.Path('/tmp/human-ai-classic-baseline-source.tar');before=json.loads(pathlib.Path(baselinepaths['classic']).read_text())
with tarfile.open(baseline_tar) as t:
 for path,digest in before['sourceSHA256'].items():
  rel=path.split('/ai-human-commander/',1)[1];raw=t.extractfile(rel).read();assert hashlib.sha256(raw).hexdigest()==digest
  if rel.startswith('shared/') and manifest['files'][rel]!=digest:sharedchanges.append(rel)
 for rel in sharedchanges+['tools/ai-balance.mjs']:
  old=t.extractfile(rel).read().decode();new=(SRC/rel).read_text();(OUT/(rel.replace('/','-')+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='corrected-before/'+rel,tofile='v15/'+rel)))
assert sharedchanges==['shared/navigation.js','shared/sim.js'],sharedchanges
assert (SRC/'shared/sim.js').read_bytes()==pathlib.Path('/tmp/human-ai-selected-hud-v14-balance-source/shared/sim.js').read_bytes()
engine={'correctedBeforeArchivedRunnerSourcesVerified':len(before['sourceSHA256']),'sharedSourceDifferences':sharedchanges,'unchangedSharedDependencies':[x for x in before['sourceSHA256'] if '/shared/' in x and x.split('/ai-human-commander/',1)[1] not in sharedchanges],'simDiffScope':'Only initial observed-wall dilation implementation. Exact diff retained. Unit definitions, population caps, costs, resource income and authoritative recruitment/economy code unchanged in this before-to-V15 sim diff.','navigationCaveat':'Navigation implementation differs. Exact diff retained; this audit does not independently prove behavioral equivalence or attribute outcome differences solely to AI.','runnerDifference':'Only human public-start initialization and first-view readiness guard differ from corrected Classic baseline. Legacy startup/schedule branch unchanged. Exact diff retained.','conquestBaselineProvenanceLimit':'Original Conquest60 report/log has no runtime source fingerprint or checkpoint. Its row population, result/log identity, seeds/configuration and unchanged1200cap are verifiable; exact original live dependency source cannot be reconstructed from that report alone.','legacy5293Verified':legacychecks,'duelEngineParity':'Both human and frozen legacy seats run the same V15 ordinary simulation, configuration and seeded match stream.'}
for n,path in baselinepaths.items():
 logs=['/tmp/human-ai-before-conquest.log'] if n=='conquest' else ['/tmp/human-ai-before-classic-corrected-resumed6.log','/tmp/human-ai-before-classic-corrected.log']
 d=json.loads(pathlib.Path(path).read_text());found=[]
 for l in logs:
  if pathlib.Path(l).exists():found.extend(json.loads(x[7:]) for x in pathlib.Path(l).read_text().splitlines() if x.startswith('RESULT '))
 assert d in found
checks={'allFiveFinalLogsCheckpointsAndReportsAgree':True,'all150OriginalRowsRetained':sum(j['metrics']['rows'] for j in jobs.values())==150,'all150FinishedWithoutTimeout':sum(j['metrics']['timeouts'] for j in jobs.values())==0,'sourceArchive763FilesVerified':True,'sharedRunnerSourcesCoherentAcrossAllJobs':True,'legacyImportOnlyProvenanceVerified':True,'baselineResultLogIdentityVerified':True,'supervisorFinishedNaturally':True,'allRequiredHistoricalGameplayGatesPass':all(j['metrics']['gatePass'] for j in jobs.values()),'currentReleaseQualification':False}
report={'generatedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':'V15 frozen archive','classification':'Historical V15 evidence. Superseded by current R6 corrections; not current release qualification.','overallHistoricalGameplayGate':'PASS','performanceGate':'Independent root V15 quiet performance gate FAIL, not superseded by gameplay PASS.','completionUTC':s['finishedAtUTC'],'source':p['commonArchive'],'jobs':jobs,'originalPairedBeforeComparisons':comparisons,'engineEconomyAndProvenance':engine,'checks':checks,'progressFlagExplanation':'supervision.jobs.*.progress uses a partial reducer with complete=False even at final count. Authoritative completion for this audit is exact final row population plus independentReduction allFinish=True. Existing raw supervision is retained unchanged.','durablePackagingRecommendation':'Retain a compact historical-V15 evidence bundle with all150after+90before rows, logs/checkpoints, this report, source manifests/predeclared protocol, the35file runtime dependency closure, package metadata, legacy/oracle provenance and corrected-before source tar. Full763file source archive remains the common primary artifact. Publish beside historical evidence only after root review; do not name this current R6 acceptance.'}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
rows=[]
for n,j in jobs.items():
 r=j['metrics'];wins=r['winsBySeat'];result=(', '.join(f'{f} {v}' for f,v in r['winsByFaction'].items())) if wins is None else f'new Hard {wins[0]}/{r["rows"]} ({wins[0]/r["rows"]:.0%})'
 rows.append(f'| {n} | {r["rows"]} | {result} | {r["draws"]} | {r["timeouts"]} | {r["medianSeconds"]} |')
md='Historical V15 gameplay gates passed. These results do not qualify the current R6 source, and the separate V15 quiet-performance gate failed.\n\n| Campaign | Matches | Wins | Draws | Timeouts | Median simulation seconds |\n| --- | ---: | --- | ---: | ---: | ---: |\n'+'\n'.join(rows)+'\n\nClassic decisive shares: USA26.92%, Germany38.46%, USSR34.62%. Conquest shares: USA30.00%, Germany41.67%, USSR28.33%. All150original rows finished.\n\nCorrected Classic baseline: USA12/Germany7/USSR10, draw1, median1600s. V15:7/10/9, draw4, median1600s. Conquest baseline:29/20/11, median596.175s. V15:18/25/17, median636.65s. Seeds, map, spawn rows, army and limits match.\n\nAll763frozen archive files and all32/35runner fingerprints verified. Reports, checkpoints and final log records agree. The original Conquest baseline has no source fingerprint, which limits exact source attribution. Corrected Classic source tar is verified; navigation and initial observed-wall source differ, with exact diffs retained. This sim diff changes no unit, cap, cost or economy code. Legacy5293 source changes are import paths only.\n\nKeep the compact proof bundle as historical V15 evidence. Preserve the full common archive separately. Root should review durable placement before copying it into repository evidence. No matches were rerun and no rows were omitted.\n'
md=md.replace('All150','All 150').replace('All763','All 763').replace('all32/35runner','all 32/35 runner').replace('USA26.92','USA 26.92').replace('Germany38.46','Germany 38.46').replace('USSR34.62','USSR 34.62').replace('USA30.00','USA 30.00').replace('Germany41.67','Germany 41.67').replace('USSR28.33','USSR 28.33').replace('Legacy5293','Legacy 5293')
(OUT/'report.md').write_text(md)
artifacts={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in ROOT.iterdir() if f.is_file()}
for f in ['/tmp/ai-v15-full-before.json','/tmp/human-ai-v15-full-predeclared.json','/tmp/human-ai-prospective-v15-balance.json','/tmp/human-ai-v15-balance-supervisor.py','/tmp/human-ai-v15-balance-launch.json','/tmp/human-ai-v15-balance-supervisor.log','/tmp/human-ai-final-performance-protocol-v15.json','/tmp/human-ai-before-conquest.json','/tmp/human-ai-before-conquest.log','/tmp/human-ai-before-classic-corrected.json','/tmp/human-ai-before-classic-corrected-checkpoint.json','/tmp/human-ai-before-classic-corrected-resumed6.log','/tmp/human-ai-before-classic-corrected.log','/tmp/human-ai-classic-baseline-source.tar']:
 artifacts[f]=hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()
for f in OUT.iterdir():
 if f.is_file():artifacts[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
(OUT/'artifact-hash-index.json').write_text(json.dumps(artifacts,indent=2)+'\n')
bundle=pathlib.Path('/tmp/human-ai-v15-historical-balance-proof.tar.gz')
with tarfile.open(bundle,'w:gz') as t:
 for f in sorted(ROOT.iterdir()):
  if f.is_file():t.add(f,arcname='after/'+f.name)
 for rel in sorted(runtime|{'package.json','tools/legacy-ai/provenance.json','tools/ai-screen-v1-oracle-provenance.json'}):t.add(SRC/rel,arcname='source/'+rel)
 for f in sorted(OUT.iterdir()):t.add(f,arcname='audit/'+f.name)
 for f in artifacts:
  path=pathlib.Path(f)
  if path.parent!=ROOT and path.parent!=OUT:t.add(path,arcname='provenance/'+path.name)
summary={'report':str(OUT/'report.json'),'checks':checks,'bundle':str(bundle),'bundleBytes':bundle.stat().st_size,'bundleSHA256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'reportSHA256':hashlib.sha256((OUT/'report.json').read_bytes()).hexdigest(),'runtimeDependencyFiles':len(runtime)}
(OUT/'bundle-index.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
