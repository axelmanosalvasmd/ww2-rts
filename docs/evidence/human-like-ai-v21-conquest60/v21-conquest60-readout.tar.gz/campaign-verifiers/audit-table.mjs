import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {independentAlertKM} from './alert-result-audit.mjs';
const report=JSON.parse(await readFile(process.argv[2],'utf8'));
const source=process.argv[4],expectedKMHash=process.argv[5];
assert.ok(source&&expectedKMHash,'Frozen V21 source and exact KM helper hash are mandatory');
const km=await import(`${source}/tools/km-median-boundary.mjs`),tool=await import(`${source}/tools/ai-humanity.mjs`),alert=await import(`${source}/tools/ai-public-alert-response.mjs`);
assert.equal(km.KM_MEDIAN_BOUNDARY_VERSION,'km-exact-half-v1');
assert.equal(tool.KM_MEDIAN_BOUNDARY_VERSION,km.KM_MEDIAN_BOUNDARY_VERSION);
assert.equal(createHash('sha256').update(await readFile(`${source}/tools/km-median-boundary.mjs`)).digest('hex'),expectedKMHash);
for(const checkpoint of Object.values(report.sourceCheckpoints??{}))assert.equal(checkpoint.files?.['tools/km-median-boundary.mjs'],expectedKMHash);
assert.deepEqual(Object.keys(report.sourceCheckpoints??{}).length,1);
const round=n=>Math.round(n*1000)/1000;
function independentManualKM(samples){
 const groups=new Map();for(const sample of samples){assert.ok(Number.isFinite(sample.seconds)&&sample.seconds>=0&&typeof sample.observed==='boolean');const row=groups.get(sample.seconds)??{observed:0,censored:0};row[sample.observed?'observed':'censored']++;groups.set(sample.seconds,row);}
 let risk=samples.length,survival=1,medianSeconds=null;const boundary=km.exactHalfBoundary();
 const curve=[...groups].sort(([a],[b])=>a-b).map(([seconds,row])=>{const atRisk=risk;if(row.observed)survival*=1-row.observed/risk;if(medianSeconds===null&&boundary(survival,atRisk,row.observed))medianSeconds=round(seconds);risk-=row.observed+row.censored;return{seconds:round(seconds),atRisk,observed:row.observed,censored:row.censored,survival:round(survival)};});
 return {samples:samples.length,observed:samples.filter(row=>row.observed).length,censored:samples.filter(row=>!row.observed).length,medianSeconds,medianIdentifiable:medianSeconds!==null,curve};
}
const groupSeats=(mode,level)=>report.results.filter(match=>match.mode===mode&&match.level===level).flatMap(match=>match.seats);
const seatSamples=(seats,endpoint)=>seats.flatMap(seat=>(seat.metrics.manualResponsePolicy?.[endpoint]?.survival?.curve??[]).flatMap(row=>[
 ...Array.from({length:row.observed},()=>({seconds:row.seconds,observed:true})),...Array.from({length:row.censored},()=>({seconds:row.seconds,observed:false}))]));
function auditGroupKM(mode,level,group){const seats=groupSeats(mode,level);
 for(const endpoint of ['firstCompletedAction','acceptedCommand']){const actual=group.manualResponsePolicy?.[endpoint]?.survival,independent=independentManualKM(seatSamples(seats,endpoint));assert.ok(actual,`${mode}/${level} ${endpoint} missing`);for(const key of ['samples','observed','censored','medianSeconds','medianIdentifiable','curve'])assert.deepEqual(actual[key],independent[key],`${mode}/${level} ${endpoint} ${key}`);}
 const alertSamples=seats.flatMap(seat=>seat.metrics.publicAlertResponse?.samples??[]),pooled=independentAlertKM(alertSamples,km);
 assert.deepEqual(group.publicAlertResponse?.firstCompletedAction?.survival,pooled,`${mode}/${level} independent public-alert KM`);
 assert.deepEqual(alert.publicAlertKM(alertSamples),pooled,`${mode}/${level} frozen native alert KM`);
 return {version:km.KM_MEDIAN_BOUNDARY_VERSION,helperSHA256:expectedKMHash,manualRequired:group.manualResponsePolicy?.requiredEvents??null,publicAlertRequired:alertSamples.length};
}
assert.equal(report.results.length,120,'Only the original120 acceptance cohort belongs in this audit.');
const bounds={easy:{screen:[.9,1.4],offscreen:[3,6],apm:[20,35],peak:60,opening:[4,8]},normal:{screen:[.5,.8],offscreen:[1.5,3],apm:[40,70],peak:120,opening:[3,6]},hard:{screen:[.3,.45],offscreen:[.8,1.6],apm:[80,120],peak:200,opening:[2,4]}};
const within=(value,range)=>Number.isFinite(value)?value>=range[0]&&value<=range[1]:null;
const rows=[];
for(const mode of ['conquest','classic','world'])for(const level of ['easy','normal','hard']){
 const key=`${mode}/${level}`,g=report.summary[key],b=bounds[level];assert.ok(g,key);
 const kmAudit=auditGroupKM(mode,level,g);
 assert.equal(g.matches,mode==='conquest'?20:10);assert.equal(g.seats,g.matches*3);
 const original=g.measurementPolicyComparison?.originalOracle,manual=g.manualResponsePolicy;
 const manualMedian=manual?.firstCompletedAction?.survival?.medianSeconds??null;
 const offscreenMedian=original?.explicitLinked?.offScreenAlertFirstActionMedianSeconds?.median??null;
 rows.push({group:key,matches:g.matches,seats:g.seats,bounds:b,kmAudit,
  manualScreen:{metric:'firstCompletedAction pooled Kaplan-Meier median',medianSeconds:manualMedian,withinOriginalBounds:within(manualMedian,b.screen),completePopulation:manual??null},
  publicDangerAlerts:{metric:'prospective pooled native event-level Kaplan-Meier',completePopulation:g.publicAlertResponse??null,withinOriginalBounds:within(g.publicAlertResponse?.firstCompletedAction?.survival?.medianSeconds,b.offscreen)},
  originalOffscreen:{metric:'unchanged aggregate of original per-seat first-completed-action medians',medianSeconds:offscreenMedian,withinOriginalBounds:within(offscreenMedian,b.offscreen),primaryOnly:original?.primaryOnly?.reactionEventPopulation?.byType?.offScreenAlert??null,explicitLinked:original?.explicitLinked?.reactionEventPopulation?.byType?.offScreenAlert??null,primaryOnlyTiming:original?.primaryOnly?.offScreenAlertFirstActionMedianSeconds??null,explicitLinkedTiming:original?.explicitLinked?.offScreenAlertFirstActionMedianSeconds??null},
  originalScreenAndAllPopulations:{primaryOnly:original?.primaryOnly??null,explicitLinked:original?.explicitLinked??null,coverage:g.measurementPolicyComparison?.coverage??null,audit:g.measurementPolicyComparison?.audit??null},
  observedDiagnostic:g.measurementPolicyComparison?.observed??null,
  physicalAPM60:{allSeats:g.physicalInputAPM60WindowMean,withinOriginalBounds:within(g.physicalInputAPM60WindowMean?.median,b.apm)},
  peakAPM10:{allSeats:g.physicalInputAPM10WindowPeak,withinOriginalCeiling:Number.isFinite(g.physicalInputAPM10WindowPeak?.max)?g.physicalInputAPM10WindowPeak.max<=b.peak:null},
  firstOrder:{allSeats:g.firstOrderSeconds,withinOriginalBounds:within(g.firstOrderSeconds?.median,b.opening)},
  firstAcceptedOrder:g.firstAcceptedOrderSeconds,maxCommandsPerTick:g.maxCommandsPerTick,locality:g.crossMapPairsWithinOneSecond,openingDiagnostic:g.openingsByFaction});
}
await writeFile(process.argv[3],JSON.stringify({schema:'ww2-final-original120-audit-v2-exact-half',kmMedianBoundaryVersion:km.KM_MEDIAN_BOUNDARY_VERSION,kmMedianBoundaryHelperSHA256:expectedKMHash,automaticAcceptance:false,qualification:'Full original120 cohort only. No favorable endpoint selection. Unknown values and censors retained. Original offscreen scores/populations remain visible; public-danger-alert-v1 adds a separately declared native offscreen stream. Original limits unchanged; all seats and censors remain.',rows},null,2)+'\n',{flag:'wx'});
