import assert from 'node:assert/strict';
import { readFile, lstat, readlink, realpath, readdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join, relative, isAbsolute, sep } from 'node:path';

const canonical = value => Array.isArray(value) ? value.map(canonical)
  : value && typeof value === 'object'
    ? Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])]))
    : value;
const digest = value => createHash('sha256').update(value).digest('hex');

export async function verifyArchive(source, manifestPath, hashFile) {
  const manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
  assert.equal(manifest.archive, source);
  assert.equal((await lstat(manifestPath)).mode & 0o222, 0, 'Manifest remains writable');
  assert.equal(manifest.bytes, Object.values(manifest.files).reduce((sum, entry) => sum + (entry.kind === 'file' ? entry.bytes : 0), 0));
  assert.equal(digest(JSON.stringify(canonical(manifest.files))), manifest.fileManifestDigest);
  const actual = [];
  async function walk(directory, prefix = '') {
    assert.equal((await lstat(directory)).mode & 0o222, 0, `Writable source directory: ${prefix}`);
    for (const row of await readdir(directory, { withFileTypes: true })) {
      const name = prefix ? `${prefix}/${row.name}` : row.name, path = join(directory, row.name);
      if (name === 'node_modules') continue;
      if (row.isSymbolicLink() || row.isFile()) actual.push(name);
      else if (row.isDirectory()) await walk(path, name);
      else throw Error(`Unsupported source member: ${name}`);
    }
  }
  await walk(source);
  assert.deepEqual(actual.sort(), Object.keys(manifest.files).sort(), 'Frozen archive member set differs');
  const sourceReal = await realpath(source), sourceLinkTargets = {};
  for (const [file, entry] of Object.entries(manifest.files)) {
    assert.ok(file && !isAbsolute(file) && !file.split('/').includes('..')
      && file !== 'node_modules' && !file.startsWith('node_modules/'), file);
    const path = join(source, file), meta = await lstat(path);
    if (entry.kind === 'file') {
      assert.ok(meta.isFile(), file);
      assert.equal(meta.size, entry.bytes, file);
      assert.equal((await hashFile(path)).sha256, entry.sha256, file);
      assert.equal(meta.mode & 0o222, 0, file);
    } else if (entry.kind === 'symlink') {
      assert.ok(meta.isSymbolicLink(), file);
      assert.equal(await readlink(path), entry.target, file);
      assert.equal(digest(Buffer.from(entry.target)), entry.sha256, file);
      const target = await realpath(path), relativeTarget = relative(sourceReal, target);
      assert.ok(relativeTarget && !isAbsolute(relativeTarget) && relativeTarget !== '..'
        && !relativeTarget.startsWith(`..${sep}`), file);
      const targetMeta = await lstat(target);
      if (targetMeta.isFile()) {
        assert.equal(manifest.files[relativeTarget]?.kind, 'file', file);
        sourceLinkTargets[file] = { kind: 'file', path: relativeTarget };
      } else if (targetMeta.isDirectory()) {
        const members = Object.keys(manifest.files).filter(name => name.startsWith(`${relativeTarget}/`)).sort();
        assert.ok(members.length && members.some(name => manifest.files[name].kind === 'file'), `Uncaptured or empty directory alias: ${file}`);
        sourceLinkTargets[file] = { kind: 'directory', path: relativeTarget, members };
      } else throw Error(`Unsupported source symlink target: ${file}`);
    } else throw Error(`Unsupported frozen source kind: ${file}`);
  }
  assert.deepEqual(sourceLinkTargets, manifest.sourceLinkTargets, 'Source link target declarations differ');
  assert.equal(await readlink(join(source, 'node_modules')), manifest.dependencyLink, 'Dependency link identity changed');
  return { members: actual.length, sourceSymlinks: Object.values(manifest.files).filter(entry => entry.kind === 'symlink').length };
}
