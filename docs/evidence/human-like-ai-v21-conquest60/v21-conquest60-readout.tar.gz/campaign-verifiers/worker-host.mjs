import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { Worker } from 'node:worker_threads';

const configPath = process.argv[2];
assert.ok(configPath, 'A frozen worker configuration path is required.');
const config = JSON.parse(await readFile(configPath, 'utf8'));
assert.ok([6, 10].includes(config.cpu));
assert.ok(typeof config.source==='string'&&config.source.startsWith('/'));assert.equal(config.options.alertPolicy,'public-danger-alert-v1');
assert.equal(config.options.seconds, 180);
assert.equal(config.options.workers, 2);
assert.equal(config.options.screenSpan, 113);
assert.equal(config.options.manualPolicy, 'screen-manual-v3');
assert.equal(config.options.logs, true);
assert.ok(Array.isArray(config.tasks));
await mkdir(config.compactDirectory, { recursive: true });

const worker = new Worker(`${config.source}/tools/ai-humanity.mjs`, {
  workerData: { options: config.options, tasks: config.tasks, spoolDirectory: config.spoolDirectory },
});
let pending = Promise.resolve();
worker.on('message', value => {
  pending = pending.then(async () => {
    if (value.type === 'sourceCheckpoint') {
      assert.equal(value.checkpoint.sha256, config.expectedRuntimeCheckpointSHA256);
      process.stdout.write(JSON.stringify({ type: 'sourceCheckpoint', checkpoint: value.checkpoint }) + '\n');
      return;
    }
    assert.equal(value.sourceCheckpointSHA256, config.expectedRuntimeCheckpointSHA256);
    const { spoolFile, ...result } = value;
    assert.ok(spoolFile);
    const compactFile = `${config.compactDirectory}/${result.mode}-${result.level}-${result.seed}.json`;
    await writeFile(compactFile, JSON.stringify(result) + '\n', { flag: 'wx' });
    process.stdout.write(JSON.stringify({ type: 'match', compactFile, spoolFile, mode: result.mode, level: result.level, seed: result.seed }) + '\n');
  });
  pending.catch(error => { process.stderr.write(String(error.stack ?? error) + '\n'); process.exitCode = 1; worker.terminate(); });
});
worker.on('error', error => { process.stderr.write(String(error.stack ?? error) + '\n'); process.exitCode = 1; });
worker.on('exit', async code => {
  try { await pending; }
  catch (error) { process.stderr.write(String(error.stack ?? error) + '\n'); process.exitCode = 1; }
  if (code !== 0) process.exitCode = 1;
});
