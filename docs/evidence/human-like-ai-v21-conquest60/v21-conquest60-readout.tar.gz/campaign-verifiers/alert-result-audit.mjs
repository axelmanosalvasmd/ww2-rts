import assert from 'node:assert/strict';
// Readback audits an already collected native score. It never recreates a live capture or grants provenance.
export function independentAlertKM(samples, km) {
 assert.equal(km.KM_MEDIAN_BOUNDARY_VERSION,'km-exact-half-v1');
 const groups=new Map();
 for(const sample of samples){
  assert.ok(Number.isFinite(sample.seconds)&&sample.seconds>=0&&typeof sample.observed==='boolean');
  const row=groups.get(sample.seconds)??{observed:0,censored:0};row[sample.observed?'observed':'censored']++;groups.set(sample.seconds,row);
 }
 let risk=samples.length,survival=1,medianSeconds=null;
 const medianBoundary=km.exactHalfBoundary();
 const curve=[...groups].sort(([a],[b])=>a-b).map(([seconds,row])=>{
  const atRisk=risk;if(row.observed)survival*=1-row.observed/risk;
  if(medianSeconds===null&&medianBoundary(survival,atRisk,row.observed))medianSeconds=seconds;
  risk-=row.observed+row.censored;return {seconds,atRisk,...row,survival};
 });
 return {samples:samples.length,medianSeconds,medianIdentifiable:medianSeconds!==null,curve};
}
export function auditNativeAlertResult(score,log,seconds,alert,km) {
 assert.equal(km.KM_MEDIAN_BOUNDARY_VERSION,'km-exact-half-v1');
 const stream=log.alertMeasurements,issues=[];
 if(score?.policy!=='public-danger-alert-v1'||stream?.policy!==score.policy||stream?.schema!=='ww2-public-alert-response-v1')return ['missing-public-alert-policy-or-stream'];
 assert.deepEqual(score.rawAlerts,log.events.filter(e=>e.source==='alert'),'Live native alert result must preserve the complete original alert population');
 if(!score.recorded)return ['native-alert-capture-not-recorded'];
 assert.deepEqual(score.decisions,score.rawAlerts.map(e=>({event:`${e.id}/${e.tick}`,decision:alert.classifyPublicAlert(e)})));
 assert.deepEqual(score.coverage,stream.coverage);
 assert.equal(stream.endedTick,Math.round(seconds*20));
 if(stream.startedTick!==0||!score.evaluable)issues.push('alert-seat-coverage-unknown');
 if(Object.values(stream.coverage).some(n=>n!==0))issues.push('alert-native-capture-incomplete');
 const required=score.rawAlerts.filter(e=>alert.classifyPublicAlert(e)==='required');
 assert.equal(score.requiredEvents,required.length);assert.equal(score.requiredPopulation.length,required.length);
 for(const [index,e]of required.entries()){
  const row=score.requiredPopulation[index],creation=stream.creations.find(r=>JSON.stringify(r.creation)===JSON.stringify(e));assert.deepEqual(row.creation,e);
  assert.equal(row.createdAtTick,creation?.createdAtTick??null);
  if(creation){if(creation.capturedAtTick!==creation.createdAtTick||creation.observationTick!==e.tick||alert.publicAlertOnScreen(creation.geometry)!==false)issues.push('invalid-alert-creation-proof');}
  if(row.completedTick===null)assert.equal(row.censorTick,stream.endedTick);else{
   assert.equal(row.censorTick,null);assert.ok(stream.completions.some(r=>r.completedTick===row.completedTick&&r.applied&&r.geometry.some(g=>g.event===`${e.id}/${e.tick}`&&alert.publicAlertOnScreen(g.proof)===true)),'A recorded answer must remain backed by its native receipt and public geometry');
  }
  const end=row.completedTick??row.censorTick;assert.equal(row.seconds,row.createdAtTick===null?null:(end-row.createdAtTick)/20);
 }
 assert.deepEqual(score.samples,score.requiredPopulation.filter(r=>r.seconds!==null).map(r=>({event:`${r.creation.id}/${r.creation.tick}`,seconds:r.seconds,observed:r.completedTick!==null})));
 assert.deepEqual(score.survival,independentAlertKM(score.samples,km));
 assert.deepEqual(score.survival,alert.publicAlertKM(score.samples));
 if(score.audit.unknownCreations||score.audit.invalidCreationProof||score.audit.unsupportedCausalInputs)issues.push('unknown-alert-creation-or-causal-endpoint');
 return [...new Set(issues)];
}
