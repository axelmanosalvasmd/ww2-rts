import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {aggregate} from '/tmp/human-ai-v21-final-full-source/tools/ai-humanity.mjs';
import * as km from '/tmp/human-ai-v21-final-full-source/tools/km-median-boundary.mjs';
import {independentAlertKM} from '/tmp/human-ai-v21-campaign-preparation/alert-result-audit.mjs';

const dir='/tmp/human-ai-final-v21',source='/tmp/human-ai-v21-final-full-source';
const protocol=JSON.parse(await readFile('/tmp/human-ai-v21-campaign-predeclared.json'));
const checkpoint=protocol.expectedRuntimeCheckpointSHA256;
const levels=['easy','normal','hard'];
const bounds={easy:{screen:[.9,1.4],offscreen:[3,6],apm:[20,35],peak:60,first:[4,8]},normal:{screen:[.5,.8],offscreen:[1.5,3],apm:[40,70],peak:120,first:[3,6]},hard:{screen:[.3,.45],offscreen:[.8,1.6],apm:[80,120],peak:200,first:[2,4]}};
const sha=b=>createHash('sha256').update(b).digest('hex');
const within=(n,[lo,hi])=>Number.isFinite(n)?n>=lo&&n<=hi:null;
const sum=(xs,f)=>xs.reduce((n,x)=>n+f(x),0);
const group={};const sourceReadout={sourceArchive:source,sourceCheckpointSHA256:checkpoint,manifestSHA256:null,compactSHA256:[],rawReceipts:[]};
const progress=JSON.parse(await readFile(`${dir}/progress-conquest.json`));
assert.equal(progress.completed,60);assert.equal(progress.total,60);assert.equal(progress.sourceCheckpointSHA256,checkpoint);
const manifestBytes=await readFile(`${dir}/conquest-raw-manifest.json`),manifest=JSON.parse(manifestBytes);
assert.equal(manifest.length,60);sourceReadout.manifestSHA256=sha(manifestBytes);
const manifestMap=new Map(manifest.map(x=>[`${x.level}/${x.seed}`,x]));assert.equal(manifestMap.size,60);
for(const level of levels){
 const matches=[];
 for(let seed=1;seed<=20;seed++){
  const row=manifestMap.get(`${level}/${seed}`);assert.ok(row);assert.equal(row.mode,'conquest');
  assert.ok(row.raw.sha256&&row.raw.bytes>0&&row.gzip.sha256&&row.gzip.bytes>0);
  assert.equal(row.timelineDigests.length,3);
  sourceReadout.rawReceipts.push({level,seed,rawSHA256:row.raw.sha256,rawBytes:row.raw.bytes,gzipSHA256:row.gzip.sha256,gzipBytes:row.gzip.bytes});
  const path=`${dir}/compact-spool/conquest-${level}-${seed}.json`,bytes=await readFile(path),match=JSON.parse(bytes);
  assert.equal(match.mode,'conquest');assert.equal(match.level,level);assert.equal(match.seed,seed);assert.equal(match.sourceCheckpointSHA256,checkpoint);assert.equal(match.seats.length,3);
  sourceReadout.compactSHA256.push({level,seed,path,sha256:sha(bytes),bytes:bytes.length});matches.push(match);
 }
 const g=aggregate(matches)[`conquest/${level}`];assert.equal(g.matches,20);assert.equal(g.seats,60);
 const seats=matches.flatMap(m=>m.seats.map(s=>({seed:m.seed,slot:s.slot,faction:s.faction,metrics:s.metrics})));
 const manualSamples=seats.flatMap(s=>(s.metrics.manualResponsePolicy?.firstCompletedAction?.survival?.curve??[]).flatMap(r=>[
  ...Array.from({length:r.observed},()=>({seconds:r.seconds,observed:true})),...Array.from({length:r.censored},()=>({seconds:r.seconds,observed:false}))]));
 const manualCurve=independentAlertKM(manualSamples,km);
 const manual=g.manualResponsePolicy?.firstCompletedAction?.survival;
 assert.ok(manual);for(const k of ['samples','observed','censored','medianSeconds','medianIdentifiable']){
  if(k==='observed'||k==='censored')assert.equal(manual[k],sum(manualCurve.curve,r=>r[k]));else assert.equal(manual[k],manualCurve[k]);
 }
 assert.equal(manual.samples,g.manualResponsePolicy.requiredEvents);
 const alertSamples=seats.flatMap(s=>s.metrics.publicAlertResponse?.samples??[]);
 const alertCurve=independentAlertKM(alertSamples,km);
 assert.deepEqual(g.publicAlertResponse?.firstCompletedAction?.survival,alertCurve);
 const firsts=seats.map(s=>s.metrics.firstOrderSeconds),nativeFloor=seats.map(s=>s.metrics.nativeReactionEvents?.onScreen?.firstAction?.seconds?.min).filter(Number.isFinite),
  manualFloor=manualCurve.curve.filter(r=>r.observed).map(r=>r.seconds);
 const alertAudit={unsupportedCausalInputs:sum(seats,s=>s.metrics.publicAlertResponse?.audit?.unsupportedCausalInputs??0),unknownCreations:sum(seats,s=>s.metrics.publicAlertResponse?.audit?.unknownCreations??0),invalidCreationProof:sum(seats,s=>s.metrics.publicAlertResponse?.audit?.invalidCreationProof??0),rejectedReceipts:sum(seats,s=>s.metrics.publicAlertResponse?.audit?.rejectedReceipts??0),unevaluableSeats:seats.filter(s=>!s.metrics.publicAlertResponse?.evaluable).map(s=>({seed:s.seed,slot:s.slot,faction:s.faction,required:s.metrics.publicAlertResponse?.requiredEvents??null,audit:s.metrics.publicAlertResponse?.audit??null,coverage:s.metrics.publicAlertResponse?.coverage??null}))};
 group[level]={population:{matches:20,seats:60,seeds:Array.from({length:20},(_,i)=>i+1),sourceCheckpointSHA256:checkpoint},bounds:bounds[level],
  screenManualV3:{full:g.manualResponsePolicy,independentExactHalf:{samples:manualCurve.samples,answered:sum(manualCurve.curve,r=>r.observed),censored:sum(manualCurve.curve,r=>r.censored),medianSeconds:manualCurve.medianSeconds,medianIdentifiable:manualCurve.medianIdentifiable},medianWithinOriginalBand:within(manualCurve.medianSeconds,bounds[level].screen),minimumCompletedSeconds:manualFloor.length?Math.min(...manualFloor):null},
  publicDangerAlertV1:{full:g.publicAlertResponse,fullSeatAudit:alertAudit,numericMedianWithinOriginalBand:within(alertCurve.medianSeconds,bounds[level].offscreen),certifiable:g.publicAlertResponse.coverageComplete&&alertCurve.medianIdentifiable},
  originalOracle:g.measurementPolicyComparison?.originalOracle??null,observedDiagnostic:g.measurementPolicyComparison?.observed??null,
  physicalAPM60:{full:g.physicalInputAPM60WindowMean,medianWithinBand:within(g.physicalInputAPM60WindowMean?.median,bounds[level].apm),seatMeans:seats.map(s=>({seed:s.seed,slot:s.slot,value:s.metrics.physicalInputAPM?.windows60?.mean??null}))},
  peakAPM10:{full:g.physicalInputAPM10WindowPeak,maximumWithinCap:g.physicalInputAPM10WindowPeak?.max<=bounds[level].peak},
  firstOrder:{full:g.firstOrderSeconds,medianWithinBand:within(g.firstOrderSeconds?.median,bounds[level].first),minimum:Math.min(...firsts),maximum:Math.max(...firsts),outsideSeatCount:firsts.filter(n=>!within(n,bounds[level].first)).length,seatSeconds:seats.map((s,i)=>({seed:s.seed,slot:s.slot,value:firsts[i]}))},
  floorsAndLocality:{minimumNativeOnScreenCompletedSeconds:nativeFloor.length?Math.min(...nativeFloor):null,minimumManualCompletedSeconds:manualFloor.length?Math.min(...manualFloor):null,minimumAtLeastPointTwo:nativeFloor.length&&manualFloor.length?Math.min(...nativeFloor,...manualFloor)>=.2:null,maxCommandsPerTick:g.maxCommandsPerTick?.max??null,ticksOverOne:sum(seats,s=>s.metrics.commandsPerTick?.ticksOverOne??0),crossScreenPairsWithinQuarterSecond:sum(seats,s=>s.metrics.crossMap?.commandPairsWithinQuarterSecond??0),crossScreenPairsWithinOneSecond:sum(seats,s=>s.metrics.crossMap?.commandPairsWithinOneSecond??0)}};
}
assert.equal(sourceReadout.rawReceipts.length,60);assert.equal(sourceReadout.compactSHA256.length,60);
const result={schema:'ww2-v21-conquest60-partial-diagnostic-v1',qualification:'All fixed Conquest 20 seeds per level and 180 seats are receiver-verified. Full original120 packaging and independent full-campaign verification are pending. No release acceptance or waiver.',sourceReadout,groups:group};
await writeFile('/tmp/human-ai-v21-conquest60-diagnostic.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({sourceCheckpointSHA256:checkpoint,manifestSHA256:sourceReadout.manifestSHA256,groups:Object.fromEntries(levels.map(l=>{const x=group[l];return[l,{manual:{required:x.screenManualV3.full.requiredEvents,unknown:x.screenManualV3.full.unknownEvents,answered:x.screenManualV3.independentExactHalf.answered,censored:x.screenManualV3.independentExactHalf.censored,median:x.screenManualV3.independentExactHalf.medianSeconds,band:x.screenManualV3.medianWithinOriginalBand},alert:{samples:x.publicDangerAlertV1.full.firstCompletedAction.survival.samples,median:x.publicDangerAlertV1.full.firstCompletedAction.survival.medianSeconds,coverage:x.publicDangerAlertV1.full.coverageComplete,unsupported:x.publicDangerAlertV1.fullSeatAudit.unsupportedCausalInputs},apm60:x.physicalAPM60.full.median,apmPass:x.physicalAPM60.medianWithinBand,peak10:x.peakAPM10.full.max,peakPass:x.peakAPM10.maximumWithinCap,firstOrder:x.firstOrder.full.median,firstPass:x.firstOrder.medianWithinBand,floor:x.floorsAndLocality.minimumManualCompletedSeconds,commandsMax:x.floorsAndLocality.maxCommandsPerTick,quarterCross:x.floorsAndLocality.crossScreenPairsWithinQuarterSecond}]}))}));
