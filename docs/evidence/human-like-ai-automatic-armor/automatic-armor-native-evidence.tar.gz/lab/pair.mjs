import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createAIcase} from './captured-candidate.mjs';
const [sim,ai,perception,hands,view]=await Promise.all(['sim','ai','ai-perception','ai-hands','ai-view'].map(n=>import(`./candidate/shared/${n}.js`)));
const rows=[];
for(const level of ['easy','normal','hard']){
 const before=JSON.parse(await readFile(`/tmp/ai-lab-typical-response/${level}-ordinary-medium.json`));
 const lab=createAIcase({sim,ai,perception,hands,view},{scenario:'guard',level,seed:1,seconds:30,collectPolicy:true},before.authoredScene),after=lab.advance(600);
 after.authoredScene=before.authoredScene;after.authorEnd=lab.authorView();await writeFile(`/tmp/ai-lab-typical-response/${level}-candidate.json`,JSON.stringify(after));
 for(const field of ['events','inputs','inputStarts','commands'])assert.deepEqual(before[field].filter(r=>r.tick<244),after[field].filter(r=>r.tick<244),level+' exact full native prefix');
 const response=after.commands.find(c=>c.accepted&&c.command.t==='retreat'&&c.command.ids.includes(8)&&c.tick>=244);
 assert.ok(response,level+' actual ordinary retreat replaces ineffective automatic target fire');
 const paid=after.inputs.filter(i=>i.tick>=244&&i.tick<=response.tick);assert.ok(paid.some(i=>i.input?.code==='KeyR'));assert.ok(paid.every(i=>i.tick-i.inputStartedTick>=i.motorTicks));
 rows.push({level,event:244,response,paid,beforeRows:before.policies.manual.rows.map(r=>({creation:r.creation,decision:r.decision,reason:r.reason,answer:r.answer})),afterRows:after.policies.manual.rows.map(r=>({creation:r.creation,decision:r.decision,reason:r.reason,answer:r.answer}))});
}
await writeFile('/tmp/ai-lab-typical-response/pair-results.json',JSON.stringify({status:'PASS',rows},null,2));console.log(JSON.stringify(rows.map(r=>({level:r.level,accepted:r.response.tick,first:r.paid[0].tick}))));
