import {readFile,writeFile} from 'node:fs/promises';
import {createAIcase} from '/tmp/ai-lab-stationary-armor-fallback/captured-combined.mjs';
const path='/tmp/ai-lab-stationary-armor-fallback/current-combined';
const [sim,ai,perception,hands,view]=await Promise.all(['sim','ai','ai-perception','ai-hands','ai-view'].map(n=>import(`${path}/shared/${n}.js`)));
const engine={sim,ai,perception,hands,view},base=JSON.parse(await readFile('/tmp/ai-lab-response-current/episodes/hard-1-native-weapon-240.json')).authoredScene;
for(const level of ['easy','normal','hard']){
 const scene=structuredClone(base);for(const u of scene.units.filter(u=>u.owner===0)){delete u.holdFire;delete u.cooldown;}
 const r=createAIcase(engine,{scenario:'guard',level,seed:1,seconds:30,collectPolicy:true},scene).advance(600);r.authoredScene=scene;
 await writeFile(`/tmp/ai-lab-typical-response/${level}-ordinary-medium.json`,JSON.stringify(r));
 console.log(JSON.stringify({level,rows:r.policies.manual.rows.map(x=>({event:x.creation,decision:x.decision,reason:x.reason,answer:x.answer})),commands:r.commands.map(c=>({tick:c.tick,command:c.command,rejection:c.rejection}))}));
}
