from pathlib import Path
import hashlib,json,tarfile,gzip,shutil
OUT=Path('/tmp/ai-lab-automatic-armor-evidence');LAB=Path('/tmp/ai-lab-typical-response');REPO=Path('/home/judiazm/.t3/worktrees/ww2-rts/ai-human-commander')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def source(tree):return {f.relative_to(tree).as_posix():{'bytes':f.stat().st_size,'sha256':sha(f)}for top in ['shared','client','tools']for f in sorted((tree/top).rglob('*'))if f.is_file()}
base=Path('/tmp/ai-lab-stationary-armor-fallback/current-combined');candidate=LAB/'candidate'
root_manifest=source(REPO);candidate_manifest=source(candidate);differences={k:{'candidate':v,'root':root_manifest.get(k)}for k,v in candidate_manifest.items()if root_manifest.get(k)!=v}
write(OUT/'source-declarations.json',{'schema':'ww2-ai-lab-source-bindings-v1','base':{'pathAtCapture':str(base),'files':source(base)},'candidate':{'pathAtCapture':str(candidate),'files':candidate_manifest},'ROOTAtProofPackaging':{'path':str(REPO),'files':root_manifest},'candidateVsROOTDependencyDifferences':differences,'sourceScope':'Dependency hashes bind captured native lab, reviewed candidate and independent ROOT fixture proofs. No whole-source tree is duplicated in the archive.'})
assert sha(REPO/'shared/ai.js')==sha(candidate/'shared/ai.js')=='bc677b3d7b2771941e6242f9c598084f04710dad944bdc54db24ef93ac354457'
shutil.copyfile(LAB/'REPORT.md',OUT/'readout.md')
(OUT/'README.md').write_text('''# Automatic armor-fire retreat evidence

This archive packages existing bounded authored-lab evidence. No new game, scoring run or campaign was launched. The adopted gameplay source is AI bc677b3d; the control is AI84e5d86a. Exact dependency hashes and any candidate-to-ROOT file differences appear in source-declarations.json.

The six full Easy/Normal/Hard native JSON files contain three complete ordinary-fire timeline pairs, including every input, command, public frame and required/monitoring/censored scoring row. The portable fixture log documents six native pairs (12 native runs): three positive difficulty pairs and three protected-hold/paid-attack/paid-move pairs. It records exact prefix/full-trace assertions and the protected operations' physical inputs and receipts. The portable fixture does not persist every temporary full-state graph. Its source and independent ROOT log are retained. The90 prior stationary controls are retained through their source-bound fixture and both lab/ROOT PASS logs.

ROOT and captured-driver timing differences are preserved in timing-readout.json and appendix-prose.md. Neither driver was selected as acceptance evidence. The original limits and all recorded failures remain unchanged. readout.md explains the ordinary automatic-target omission and separately records the unchanged public classifier's opening-contact eligibility.

Every archived member was checked against original file bytes by SHA256 and size after decompression. package-manifest.json lists exact source paths and hashes. The external byte manifest, verification and copy map identify durable files for ROOT review. Whole-source copies are excluded; only reviewed source excerpts, fixtures and the patch are included.
'''.replace('AI84e5','AI 84e5').replace('The90','The 90'))
lab_pairs=json.loads((LAB/'pair-results.json').read_text());root_proof=json.loads(Path('/tmp/human-ai-root-automatic-armor-test.log').read_text())
write(OUT/'timing-readout.json',{'scope':'Existing individual authored diagnostic episodes, not reaction-population acceptance. Full first physical completion and accepted-command endpoints retained separately.','capturedDriver':[{'level':r['level'],'creationTick':r['event'],'firstPhysicalTick':r['paid'][0]['tick'],'acceptedTick':r['response']['tick']}for r in lab_pairs['rows']],'ROOTPortableDriver':[{'level':r['level'],'creationTick':r['hit']['tick'],'firstPhysicalTick':r['paid'][0]['tick'],'acceptedTick':r['response']['tick']}for r in root_proof['reports']if 'hit'in r],'note':'Drivers have different setup and random-consumption paths. Both exact source-bound proofs are retained; no result replaces another.'})
members={f.name:f for f in OUT.iterdir()if f.is_file()and f.suffix in ['.md','.json','.py']}
for f in ['integration.patch','adoption-manifest.json','evidence-manifest.json','REPORT.md','probe.mjs','probe.log','pair.mjs','pair.log','pair-results.json','captured-candidate.mjs','portable.log','portable-final.log','existing-portable.log']+[f'{l}-{t}.json'for l in ['easy','normal','hard']for t in ['ordinary-medium','candidate']]:members['lab/'+f]=LAB/f
for f in ['test-engine-ai-automatic-armor-hit.js','test-engine-ai-stationary-armor-hit.js']:members['fixtures/'+f]=candidate/f
members['source-excerpts/base-ai.js']=base/'shared/ai.js';members['source-excerpts/candidate-ai.js']=candidate/'shared/ai.js'
for f in ['ai-humanity.mjs','ai-manual-response-capture-v3.mjs','ai-manual-response-policy-v3.mjs','ai-public-alert-response.mjs']:members['source-excerpts/tools/'+f]=candidate/'tools'/f
for name in ['automatic-armor','stationary-combined']:members['ROOT/human-ai-root-'+name+'-test.log']=Path('/tmp/human-ai-root-'+name+'-test.log')
entries={k:{'source':str(v),'bytes':v.stat().st_size,'sha256':sha(v)}for k,v in sorted(members.items())};manifest=OUT/'automatic-armor-byte-manifest.json';write(manifest,{'schema':'ww2-ai-lab-byte-manifest-v1','members':entries});members['package-manifest.json']=manifest
archive=OUT/'automatic-armor-native-evidence.tar.gz'
with archive.open('wb')as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=6)as gz,tarfile.open(fileobj=gz,mode='w|')as tar:
 for k,v in sorted(members.items()):
  info=tar.gettarinfo(str(v),arcname=k);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644
  with v.open('rb')as f:tar.addfile(info,f)
expected={k:{'bytes':v.stat().st_size,'sha256':sha(v)}for k,v in members.items()};seen=set()
with tarfile.open(archive,'r|gz')as tar:
 for m in tar:
  assert m.isfile()and m.name in expected and m.name not in seen
  h=hashlib.sha256();count=0
  with tar.extractfile(m)as f:
   for b in iter(lambda:f.read(1024*1024),b''):h.update(b);count+=len(b)
  assert {'bytes':count,'sha256':h.hexdigest()}==expected[m.name],m.name
  seen.add(m.name)
assert seen==set(members)
for k,v in members.items():assert sha(v)==expected[k]['sha256'],'changed source '+k
populations=[]
for level in ['easy','normal','hard']:
 for t in ['ordinary-medium','candidate']:
  r=json.loads((LAB/f'{level}-{t}.json').read_text());m=r['policies']['manual'];a=m['firstCompletedAction'];assert len(m['rows'])==m['creationEvents'];assert m['requiredEvents']==a['required']==a['answered']+a['censored'];populations.append({'level':level,'treatment':t,'creations':m['creationEvents'],'required':m['requiredEvents'],'monitoring':m['monitoringEvents'],'unknown':m['unknownEvents'],'answered':a['answered'],'censored':a['censored']})
result={'status':'PASS','archive':str(archive),'archiveBytes':archive.stat().st_size,'archiveSHA256':sha(archive),'manifestSHA256':sha(manifest),'members':len(members),'completeNativeJSONTimelines':6,'portableNativePairs':root_proof['nativePairs'],'portableNativeRuns':root_proof['nativeRuns'],'priorNeighborControls':90,'ROOTNativeProof':root_proof['status'],'ROOTPriorProof':json.loads(Path('/tmp/human-ai-root-stationary-combined-test.log').read_text())['status'],'recordedPopulations':populations,'verification':'Exact decompressed bytes, size and member set match originals; all original files unchanged before/after packaging. Recorded creation and required/answered/censored accounting preserved. No rescoring or experiment.'}
write(OUT/'independent-verification.json',result);print(json.dumps(result,indent=2))
