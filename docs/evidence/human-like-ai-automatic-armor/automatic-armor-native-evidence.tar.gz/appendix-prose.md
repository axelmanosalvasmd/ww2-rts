# Suggested changelog entry

- Infantry can retreat after a heavy visible armor hit when its automatic small-arms fire cannot answer the threat and nearby ground offers no safe escape. Paid attacks, useful counterfire, grenades and protected holds remain intact. No unit stats, economy rules or reaction limits changed.

# Suggested design note

A target acquired by automatic fire does not always mean the squad is fighting a useful engagement. After a recent heavy public hit from watched armor, idle infantry with weak automatic fire may use the existing ordinary retreat when the bounded local search finds no safe destination and its known home is safe. An explicit attack order, useful armor counter, protected hold or active task still takes precedence. The commander uses current public weapon and target facts and pays the normal selection and retreat inputs.

# Suggested spec evidence appendix

The frozen combined-source lab reproduced an ordinary tactical omission without authored held fire, cooling abilities or health subtraction. A real medium projectile at tick 244 left a stationary rifle at 65% health. The previous blanket target-ID guard treated weak automatic small-arms fire as a protected fight and produced no manual response. The narrow gameplay correction retains the existing public heavy-hit and safe-retreat conditions while distinguishing that automatic target from a paid attack or useful counterfire.

Three complete Easy/Normal/Hard native timeline pairs preserve all pre-hit events, input starts, physical inputs and command receipts. The portable fixture also passes six native pairs, including actual paid attack/move and protected-hold controls, and all 90 prior stationary-response controls pass. All required, monitoring and censored rows remain recorded. These authored episodes establish a concrete behavior correction; they do not establish campaign acceptance.

The captured lab driver completes its first physical input and accepted retreat at Easy 268/272, Normal 259/262 and Hard 252/255 after creation 244. ROOT's portable driver records Easy 272/276, Normal 258/261 and Hard 251/253. Both sets are retained. Their setup and random-consumption paths differ; the selected endpoint or driver was not changed to favor a result. The original reaction timing limits, physical input model, scoring policy and population rules remain unchanged.
